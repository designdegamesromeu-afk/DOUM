// DOUM - Particle Effects Engine
// Features: Chocolate fountain splatters, bouncy rainbow sprinkles, expanding rainbow rings,
// floating confetti, sugar crystal wall demolition debris, and magic weapon trails.

class ParticleSystem {
  constructor(scene) {
    this.scene = scene;
    this.particles = [];
    this.decals = []; // Chocolate splats on surfaces
    this.maxDecals = 60;

    // Shared geometries and materials for performance
    this.sprinkleGeom = new THREE.CylinderGeometry(0.04, 0.04, 0.22, 5);
    this.chocolateGeom = new THREE.SphereGeometry(0.12, 6, 6);
    this.debrisGeom = new THREE.BoxGeometry(0.25, 0.25, 0.25);
    this.starGeom = new THREE.ConeGeometry(0.1, 0.2, 4);

    // Rainbow sprinkle color palette
    this.sprinkleColors = [
      0xff6b8b, // Candy Pink
      0xfeca57, // Bright Yellow
      0x48dbfb, // Sky Cyan
      0x1dd1a1, // Mint Lime
      0xff9ff3, // Pastel Violet
      0xff9f43  // Tangerine Orange
    ];

    // Chocolate materials
    this.chocolateMat = new THREE.MeshLambertMaterial({
      color: 0x4a2211,
      roughness: 0.2,
      metalness: 0.1
    });

    // Rainbow ring geometry
    this.ringGeom = new THREE.RingGeometry(0.2, 0.5, 24);
  }

  // ==================== SPECIAL ENEMY DEFEAT EFFECT ====================
  // "Quando um inimigo for derrotado, não deve existir sangue, gore ou violência gráfica.
  // Em vez disso, o inimigo deve desaparecer ou explodir de maneira cartunesca, liberando
  // um grande efeito visual de arco-íris, acompanhado por uma quantidade exagerada de chocolate
  // e granulado."
  spawnEnemyDefeat(pos) {
    // 1. Expanding Rainbow Shockwave Rings (Torus/Rings)
    for (let r = 0; r < 2; r++) {
      const ringMat = new THREE.MeshBasicMaterial({
        color: this.sprinkleColors[Math.floor(Math.random() * this.sprinkleColors.length)],
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95
      });
      const ring = new THREE.Mesh(this.ringGeom, ringMat);
      ring.position.copy(pos);
      ring.position.y += 0.8;
      ring.rotation.x = Math.PI / 2;
      this.scene.add(ring);

      this.particles.push({
        mesh: ring,
        type: 'ring',
        scaleSpeed: 9.0 + r * 3.0,
        fadeSpeed: 2.2,
        life: 0.6
      });
    }

    // 2. Giant Fountain of Melted Chocolate (Exaggerated & Hilarious)
    const chocCount = 38;
    for (let i = 0; i < chocCount; i++) {
      const scale = 0.6 + Math.random() * 0.9;
      const mesh = new THREE.Mesh(this.chocolateGeom, this.chocolateMat);
      mesh.scale.set(scale, scale * (1 + Math.random() * 0.6), scale);
      mesh.position.set(
        pos.x + (Math.random() - 0.5) * 0.6,
        pos.y + 0.5 + Math.random() * 0.8,
        pos.z + (Math.random() - 0.5) * 0.6
      );

      const angle = Math.random() * Math.PI * 2;
      const hSpeed = 2.5 + Math.random() * 6.0;
      const vSpeed = 5.5 + Math.random() * 8.0;

      const vel = new THREE.Vector3(
        Math.cos(angle) * hSpeed,
        vSpeed,
        Math.sin(angle) * hSpeed
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh: mesh,
        type: 'chocolate',
        vel: vel,
        gravity: 16.0,
        life: 2.5,
        bounces: 0
      });
    }

    // 3. Deluge of Rainbow Sprinkles (Granulados Coloridos)
    const sprinkleCount = 65;
    for (let i = 0; i < sprinkleCount; i++) {
      const col = this.sprinkleColors[i % this.sprinkleColors.length];
      const mat = new THREE.MeshLambertMaterial({ color: col });
      const mesh = new THREE.Mesh(this.sprinkleGeom, mat);

      mesh.position.set(
        pos.x + (Math.random() - 0.5) * 0.8,
        pos.y + 0.4 + Math.random() * 1.0,
        pos.z + (Math.random() - 0.5) * 0.8
      );
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);

      const angle = Math.random() * Math.PI * 2;
      const hSpeed = 3.0 + Math.random() * 8.0;
      const vSpeed = 6.0 + Math.random() * 10.0;

      const vel = new THREE.Vector3(
        Math.cos(angle) * hSpeed,
        vSpeed,
        Math.sin(angle) * hSpeed
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh: mesh,
        type: 'sprinkle',
        vel: vel,
        rotSpeed: new THREE.Vector3(
          (Math.random() - 0.5) * 15,
          (Math.random() - 0.5) * 15,
          (Math.random() - 0.5) * 15
        ),
        gravity: 18.0,
        life: 3.5,
        bounces: 0
      });
    }

    // 4. Floating Stars & Confetti
    for (let i = 0; i < 20; i++) {
      const col = this.sprinkleColors[Math.floor(Math.random() * this.sprinkleColors.length)];
      const mat = new THREE.MeshBasicMaterial({ color: col });
      const star = new THREE.Mesh(this.starGeom, mat);
      star.position.copy(pos);
      star.position.y += 1.0;

      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 4,
        2.5 + Math.random() * 4,
        (Math.random() - 0.5) * 4
      );

      this.scene.add(star);
      this.particles.push({
        mesh: star,
        type: 'star',
        vel: vel,
        gravity: 2.5,
        life: 1.8
      });
    }

    // Splat decals onto nearby floor
    this.addChocolateSplatDecal(pos);
  }

  // Adds a permanent/lingering cartoon chocolate puddle onto the ground
  addChocolateSplatDecal(pos) {
    const splatGeom = new THREE.CircleGeometry(0.6 + Math.random() * 0.8, 12);
    const splatMat = new THREE.MeshBasicMaterial({
      color: 0x3d1b0d,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9
    });
    const splat = new THREE.Mesh(splatGeom, splatMat);
    splat.rotation.x = -Math.PI / 2;
    splat.position.set(
      pos.x + (Math.random() - 0.5) * 0.5,
      0.03, // Just above the floor
      pos.z + (Math.random() - 0.5) * 0.5
    );

    this.scene.add(splat);
    this.decals.push(splat);

    // Limit maximum decals to keep performance crisp
    if (this.decals.length > this.maxDecals) {
      const old = this.decals.shift();
      this.scene.remove(old);
      if (old.geometry) old.geometry.dispose();
      if (old.material) old.material.dispose();
    }
  }

  // ==================== DESTRUCTIBLE WALL BREAK FX ====================
  spawnWallBreak(pos, normal = new THREE.Vector3(0, 0, 1)) {
    const debrisCount = 28;
    for (let i = 0; i < debrisCount; i++) {
      const col = [0xff9ff3, 0xfeca57, 0x48dbfb, 0xffffff][i % 4];
      const mat = new THREE.MeshLambertMaterial({ color: col });
      const mesh = new THREE.Mesh(this.debrisGeom, mat);

      const scale = 0.4 + Math.random() * 0.8;
      mesh.scale.set(scale, scale, scale);
      mesh.position.set(
        pos.x + (Math.random() - 0.5) * 1.5,
        pos.y + (Math.random() - 0.5) * 1.5,
        pos.z + (Math.random() - 0.5) * 1.5
      );

      const vel = new THREE.Vector3(
        normal.x * 5 + (Math.random() - 0.5) * 8,
        4 + Math.random() * 6,
        normal.z * 5 + (Math.random() - 0.5) * 8
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh: mesh,
        type: 'debris',
        vel: vel,
        gravity: 20.0,
        life: 2.0,
        rotSpeed: new THREE.Vector3(Math.random() * 8, Math.random() * 8, Math.random() * 8)
      });
    }

    // Confetti burst
    this.spawnConfettiBurst(pos, 15);
  }

  // ==================== WEAPON HIT & EXPLOSION FX ====================
  spawnHitSparks(pos, normal, color = 0xfeca57) {
    const count = 10;
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: color });
      const p = new THREE.Mesh(this.starGeom, mat);
      p.scale.set(0.4, 0.4, 0.4);
      p.position.copy(pos);

      const vel = new THREE.Vector3(
        normal.x * 3 + (Math.random() - 0.5) * 4,
        normal.y * 3 + (Math.random() - 0.5) * 4,
        normal.z * 3 + (Math.random() - 0.5) * 4
      );

      this.scene.add(p);
      this.particles.push({
        mesh: p,
        type: 'spark',
        vel: vel,
        gravity: 12.0,
        life: 0.4
      });
    }
  }

  spawnExplosion(pos, radius = 3.5) {
    // Colorful rainbow sphere flash
    const flashGeom = new THREE.SphereGeometry(radius * 0.8, 12, 12);
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xff6b8b,
      transparent: true,
      opacity: 0.9
    });
    const flash = new THREE.Mesh(flashGeom, flashMat);
    flash.position.copy(pos);
    this.scene.add(flash);

    this.particles.push({
      mesh: flash,
      type: 'flash',
      scaleSpeed: 8.0,
      fadeSpeed: 3.5,
      life: 0.3
    });

    // Expanding rainbow ring
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xfeca57,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.95
    });
    const ring = new THREE.Mesh(this.ringGeom, ringMat);
    ring.position.copy(pos);
    ring.rotation.x = Math.PI / 2;
    this.scene.add(ring);

    this.particles.push({
      mesh: ring,
      type: 'ring',
      scaleSpeed: 14.0,
      fadeSpeed: 2.0,
      life: 0.5
    });

    // Sprinkles and chocolate mini-burst
    this.spawnConfettiBurst(pos, 25);
  }

  spawnConfettiBurst(pos, count = 20) {
    for (let i = 0; i < count; i++) {
      const col = this.sprinkleColors[i % this.sprinkleColors.length];
      const mat = new THREE.MeshBasicMaterial({ color: col });
      const star = new THREE.Mesh(this.starGeom, mat);
      star.position.copy(pos);

      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 6,
        2.5 + Math.random() * 6,
        (Math.random() - 0.5) * 6
      );

      this.scene.add(star);
      this.particles.push({
        mesh: star,
        type: 'star',
        vel: vel,
        gravity: 8.0,
        life: 1.2
      });
    }
  }

  // Gravity boots shift effect
  spawnGravityRing(pos, normal = new THREE.Vector3(0, 1, 0)) {
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x00d2d3,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.95
    });
    const ring = new THREE.Mesh(this.ringGeom, ringMat);
    ring.position.copy(pos);
    ring.lookAt(pos.clone().add(normal));
    this.scene.add(ring);

    this.particles.push({
      mesh: ring,
      type: 'ring',
      scaleSpeed: 12.0,
      fadeSpeed: 2.5,
      life: 0.4
    });
  }

  // ==================== UPDATE LOOP ====================
  update(delta) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= delta;

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        if (p.mesh.geometry) p.mesh.geometry.dispose();
        if (p.mesh.material) p.mesh.material.dispose();
        this.particles.splice(i, 1);
        continue;
      }

      if (p.type === 'ring') {
        p.mesh.scale.multiplyScalar(1 + p.scaleSpeed * delta);
        p.mesh.material.opacity -= p.fadeSpeed * delta;
        if (p.mesh.material.opacity <= 0) p.life = 0;
      } else if (p.type === 'flash') {
        p.mesh.scale.multiplyScalar(1 + p.scaleSpeed * delta);
        p.mesh.material.opacity -= p.fadeSpeed * delta;
        if (p.mesh.material.opacity <= 0) p.life = 0;
      } else if (p.type === 'chocolate' || p.type === 'sprinkle' || p.type === 'debris') {
        // Physics movement
        p.vel.y -= p.gravity * delta;
        p.mesh.position.addScaledVector(p.vel, delta);

        if (p.rotSpeed) {
          p.mesh.rotation.x += p.rotSpeed.x * delta;
          p.mesh.rotation.y += p.rotSpeed.y * delta;
          p.mesh.rotation.z += p.rotSpeed.z * delta;
        }

        // Bounce on floor (floor level approx y = 0)
        if (p.mesh.position.y <= 0.05) {
          p.mesh.position.y = 0.05;
          if (p.type === 'sprinkle' && p.bounces < 2) {
            p.vel.y = -p.vel.y * 0.45; // Bouncy sprinkle
            p.vel.x *= 0.7;
            p.vel.z *= 0.7;
            p.bounces++;
          } else {
            // Stick to ground
            p.vel.set(0, 0, 0);
          }
        }
      } else if (p.type === 'star' || p.type === 'spark') {
        p.vel.y -= p.gravity * delta;
        p.mesh.position.addScaledVector(p.vel, delta);
        p.mesh.rotation.y += 8.0 * delta;
      }
    }
  }

  clearAll() {
    this.particles.forEach(p => {
      this.scene.remove(p.mesh);
      if (p.mesh.geometry) p.mesh.geometry.dispose();
      if (p.mesh.material) p.mesh.material.dispose();
    });
    this.particles = [];

    this.decals.forEach(d => {
      this.scene.remove(d);
      if (d.geometry) d.geometry.dispose();
      if (d.material) d.material.dispose();
    });
    this.decals = [];
  }
}
