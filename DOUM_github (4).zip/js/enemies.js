// DOUM - Enemies Engine: Furry & Unicorn Fantasy Opponents
// Featuring 3D Origami Cat (Image 2), 3D Voxel Rainbow Unicorn (Image 3),
// Chonky Honey Bear, and Sky Pegasus, with balanced health and explosive chocolate/sprinkle defeat!

class EnemiesManager {
  constructor(scene, particleSystem, camera) {
    this.scene = scene;
    this.particles = particleSystem;
    this.camera = camera;
    this.enemies = [];
    this.enemyProjectiles = [];
    this.killsCount = 0;
    this.totalSpawned = 0;

    this.spawnAllEnemies();
  }

  // ==================== 1. 3D ORIGAMI CAT (Baseado na Imagem 2 - "GATO") ====================
  createOrigamiCatModel() {
    const group = new THREE.Group();
    const paperMat = new THREE.MeshLambertMaterial({ color: 0xf5f6fa }); // Origami paper
    const inkMat = new THREE.LineBasicMaterial({ color: 0x1e272e, linewidth: 2 }); // Hand-drawn pen outline

    const addOutlinedMesh = (geom, mat, parent = group) => {
      const mesh = new THREE.Mesh(geom, mat);
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(geom), inkMat);
      mesh.add(edges);
      parent.add(mesh);
      return mesh;
    };

    // Faceted Angular Head
    const headGeom = new THREE.CylinderGeometry(0.5, 0.4, 0.55, 6);
    const head = addOutlinedMesh(headGeom, paperMat);
    head.position.set(0, 1.35, 0.1);

    // Sharp Triangular Origami Ears
    const earGeom = new THREE.ConeGeometry(0.18, 0.45, 4);
    const earL = addOutlinedMesh(earGeom, paperMat, head);
    const earR = addOutlinedMesh(earGeom, paperMat, head);
    earL.position.set(-0.25, 0.42, 0);
    earR.position.set(0.25, 0.42, 0);
    earL.rotation.z = 0.15;
    earR.rotation.z = -0.15;

    // Cat Face: Eyes & Whiskers (Matching Image 2)
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1e272e });
    const eyeGeom = new THREE.SphereGeometry(0.08, 6, 6);
    const eyeL = new THREE.Mesh(eyeGeom, eyeMat);
    const eyeR = eyeL.clone();
    eyeL.position.set(-0.16, 0.05, 0.38);
    eyeR.position.set(0.16, 0.05, 0.38);
    head.add(eyeL, eyeR);

    // Triangular Origami Nose / Mouth
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.08, 3), new THREE.MeshBasicMaterial({ color: 0xff6b8b }));
    nose.rotation.x = -Math.PI / 2;
    nose.position.set(0, -0.05, 0.42);
    head.add(nose);

    // 3 Whiskers on Each Cheek
    [-0.04, 0, 0.04].forEach((yOff, i) => {
      const wGeom = new THREE.CylinderGeometry(0.012, 0.012, 0.35, 4);
      const wL = new THREE.Mesh(wGeom, eyeMat);
      const wR = wL.clone();
      wL.rotation.z = Math.PI / 2 + (i - 1) * 0.18;
      wR.rotation.z = -Math.PI / 2 - (i - 1) * 0.18;
      wL.position.set(-0.35, -0.05 + yOff, 0.3);
      wR.position.set(0.35, -0.05 + yOff, 0.3);
      head.add(wL, wR);
    });

    // Angular Origami Torso / Body (Matching Image 2 chest facets)
    const bodyGeom = new THREE.CylinderGeometry(0.45, 0.65, 0.9, 6);
    const body = addOutlinedMesh(bodyGeom, paperMat);
    body.position.y = 0.7;

    // Origami Legs / Paws
    const legGeom = new THREE.BoxGeometry(0.2, 0.45, 0.25);
    const legL = addOutlinedMesh(legGeom, paperMat);
    const legR = addOutlinedMesh(legGeom, paperMat);
    legL.position.set(-0.24, 0.25, 0.2);
    legR.position.set(0.24, 0.25, 0.2);

    // Sharp Angled Origami Tail (Iconic Zigzag Tail from Image 2!)
    const tailGroup = new THREE.Group();
    const tailSeg1 = addOutlinedMesh(new THREE.BoxGeometry(0.14, 0.6, 0.14), paperMat, tailGroup);
    tailSeg1.rotation.z = -Math.PI / 4;
    tailSeg1.position.set(0.2, 0.25, 0);

    const tailSeg2 = addOutlinedMesh(new THREE.BoxGeometry(0.14, 0.55, 0.14), paperMat, tailGroup);
    tailSeg2.rotation.z = Math.PI / 3;
    tailSeg2.position.set(0.45, 0.65, 0);

    tailGroup.position.set(0, 0.5, -0.35);
    group.add(tailGroup);

    group.scale.set(1.1, 1.1, 1.1);
    return group;
  }

  // ==================== 2. 3D VOXEL RAINBOW UNICORN (Baseado na Imagem 3) ====================
  createVoxelUnicornModel() {
    const group = new THREE.Group();
    const whiteMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const cyanMat = new THREE.MeshLambertMaterial({ color: 0x48dbfb }); // Cyan hooves & mane block
    const yellowMat = new THREE.MeshLambertMaterial({ color: 0xfeca57 }); // Gold horn & mane block
    const redMat = new THREE.MeshLambertMaterial({ color: 0xff4757 }); // Crimson mane block
    const purpleMat = new THREE.MeshLambertMaterial({ color: 0x9b59b6 }); // Purple mane block

    // White Voxel Body
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.85, 1.3), whiteMat);
    body.position.y = 0.85;
    group.add(body);

    // White Voxel Head & Snout
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.7, 0.75), whiteMat);
    head.position.set(0, 1.45, 0.5);

    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.45, 0.35), whiteMat);
    snout.position.set(0, -0.12, 0.45);
    head.add(snout);

    // Black Nostril & Pixel Eye with White Shine (Matching Image 3)
    const nostrilGeom = new THREE.BoxGeometry(0.08, 0.08, 0.05);
    const blackMat = new THREE.MeshBasicMaterial({ color: 0x1e272e });
    const n1 = new THREE.Mesh(nostrilGeom, blackMat);
    const n2 = n1.clone();
    n1.position.set(-0.14, 0, 0.18);
    n2.position.set(0.14, 0, 0.18);
    snout.add(n1, n2);

    const eyeGeom = new THREE.BoxGeometry(0.15, 0.18, 0.06);
    const eyeL = new THREE.Mesh(eyeGeom, blackMat);
    const eyeR = eyeL.clone();
    eyeL.position.set(-0.33, 0.06, 0.1);
    eyeR.position.set(0.33, 0.06, 0.1);
    // White shine pixel
    const shineL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.07), whiteMat);
    const shineR = shineL.clone();
    shineL.position.set(0.03, 0.04, 0);
    shineR.position.set(0.03, 0.04, 0);
    eyeL.add(shineL);
    eyeR.add(shineR);
    head.add(eyeL, eyeR);

    // Golden Spiral Unicorn Horn (Angled forward 45° like in Image 3)
    const hornGroup = new THREE.Group();
    const hornBase = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.22, 0.18), purpleMat);
    const hornMain = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.7, 0.15), yellowMat);
    hornMain.position.y = 0.4;
    hornGroup.add(hornBase, hornMain);
    hornGroup.rotation.x = Math.PI / 4;
    hornGroup.position.set(0, 0.4, 0.35);
    head.add(hornGroup);

    // SEGMENTED RAINBOW MANE BLOCKS (Yellow, Red, Purple, Cyan - Exactly Image 3!)
    const maneYellow = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.32, 0.35), yellowMat);
    maneYellow.position.set(0, 0.42, -0.15);

    const maneRed = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.35, 0.35), redMat);
    maneRed.position.set(0, 0.25, -0.4);

    const manePurple = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.35), purpleMat);
    manePurple.position.set(0, -0.05, -0.45);

    head.add(maneYellow, maneRed, manePurple);
    group.add(head);

    // 4 Voxel Legs with Cyan Blue Hooves (Exactly Image 3!)
    const legPositions = [
      [-0.28, 0.38, 0.45],
      [0.28, 0.38, 0.45],
      [-0.28, 0.38, -0.45],
      [0.28, 0.38, -0.45]
    ];

    legPositions.forEach(pos => {
      const legGroup = new THREE.Group();
      const legUpper = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.55, 0.24), whiteMat);
      legUpper.position.y = 0.2;
      const hoof = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.25, 0.26), cyanMat);
      hoof.position.y = -0.15;
      legGroup.add(legUpper, hoof);
      legGroup.position.set(pos[0], pos[1], pos[2]);
      group.add(legGroup);
    });

    // SEGMENTED BLOCKY RAINBOW TAIL (Yellow, Red, Purple, Cyan)
    const tailGroup = new THREE.Group();
    const tYellow = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.35), yellowMat);
    tYellow.position.set(0, 0.3, -0.2);

    const tRed = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.35), redMat);
    tRed.position.set(0, 0.15, -0.45);

    const tCyan = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 0.35), cyanMat);
    tCyan.position.set(0, -0.1, -0.55);

    const tPurple = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 0.3), purpleMat);
    tPurple.position.set(0, -0.3, -0.4);

    tailGroup.add(tYellow, tRed, tCyan, tPurple);
    tailGroup.position.set(0, 0.8, -0.6);
    group.add(tailGroup);

    group.scale.set(1.05, 1.05, 1.05);
    return group;
  }

  // 3. Chonky Honey Bear
  createBearModel() {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.6, 1.3), new THREE.MeshLambertMaterial({ color: 0x48dbfb }));
    body.position.y = 1.1;

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.65, 8, 8), new THREE.MeshLambertMaterial({ color: 0x54a0ff }));
    head.position.set(0, 1.9, 0.3);

    const earGeom = new THREE.SphereGeometry(0.22, 6, 6);
    const earMat = new THREE.MeshLambertMaterial({ color: 0xfeca57 });
    const ear1 = new THREE.Mesh(earGeom, earMat);
    const ear2 = ear1.clone();
    ear1.position.set(-0.45, 2.3, 0.3);
    ear2.position.set(0.45, 2.3, 0.3);

    // Honeycomb Cannon Arm
    const cannon = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 0.8, 8), new THREE.MeshLambertMaterial({ color: 0xff9f43 }));
    cannon.rotation.x = Math.PI / 2;
    cannon.position.set(0.85, 1.2, 0.55);

    group.add(body, head, ear1, ear2, cannon);
    return group;
  }

  // 4. Sky Pegasus
  createPegasusModel() {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.85, 1.3), new THREE.MeshLambertMaterial({ color: 0x00d2d3 }));
    body.position.y = 0.8;

    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.7, 6), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    horn.rotation.x = Math.PI / 4;
    horn.position.set(0, 1.7, 0.75);

    const wingGeom = new THREE.BoxGeometry(1.3, 0.08, 0.55);
    const wingMat = new THREE.MeshLambertMaterial({ color: 0xff9ff3, transparent: true, opacity: 0.9 });
    const leftWing = new THREE.Mesh(wingGeom, wingMat);
    const rightWing = leftWing.clone();
    leftWing.position.set(-1.0, 1.1, 0);
    rightWing.position.set(1.0, 1.1, 0);

    group.add(body, horn, leftWing, rightWing);
    group.userData = { leftWing: leftWing, rightWing: rightWing };
    return group;
  }

  // ==================== ENEMY SPAWNING WITH BALANCED (LOWER) HEALTH ====================
  // "os inimigos tem muita vida" -> Enemies now pop much faster in satisfying DOOM bursts!
  //
  // HITBOX: instead of one generic sphere for every enemy, each type gets a bounding-box
  // sized to actually cover its physical 3D model (width/depth/height + vertical center
  // offset), taken straight from the geometry used to build that model. This makes hits
  // register reliably across the whole silhouette instead of just a small sphere near the torso.
  static HITBOX_BY_TYPE = {
    cat:     { halfWidth: 0.85, halfDepth: 0.95, halfHeight: 1.05, centerY: 0.95 },
    unicorn: { halfWidth: 0.75, halfDepth: 0.95, halfHeight: 1.05, centerY: 0.95 },
    bear:    { halfWidth: 1.20, halfDepth: 0.95, halfHeight: 1.50, centerY: 1.25 },
    pegasus: { halfWidth: 1.20, halfDepth: 0.95, halfHeight: 1.25, centerY: 1.05 },
    boss:    { halfWidth: 2.9,  halfDepth: 1.9,  halfHeight: 3.9,  centerY: 3.7 }
  };

  // ==================== FINAL BOSS: THE FURIOUS CHOCOLATE BAR ====================
  // Big segmented chocolate bar with an angry face, based on the reference mascot image.
  createChocolateBossModel() {
    const group = new THREE.Group();
    const chocoColor = 0x5c3a21;
    const chocoDark = 0x3d2614;

    const body = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 4.2, 1.0),
      new THREE.MeshLambertMaterial({ color: chocoColor })
    );
    body.position.y = 2.4;
    group.add(body);

    // Segmented chocolate-square grooves
    const grooveMat = new THREE.MeshBasicMaterial({ color: chocoDark });
    for (let col = 1; col < 3; col++) {
      const vGroove = new THREE.Mesh(new THREE.BoxGeometry(0.05, 4.2, 1.02), grooveMat);
      vGroove.position.set(-3.2 / 2 + col * (3.2 / 3), 2.4, 0);
      group.add(vGroove);
    }
    for (let row = 1; row < 4; row++) {
      const hGroove = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.05, 1.02), grooveMat);
      hGroove.position.set(0, 2.4 - 4.2 / 2 + row * (4.2 / 4), 0);
      group.add(hGroove);
    }

    // Angry face
    const faceZ = 0.53;
    const browGeom = new THREE.BoxGeometry(0.9, 0.2, 0.12);
    const browMat = new THREE.MeshBasicMaterial({ color: 0x1a0d05 });
    const browL = new THREE.Mesh(browGeom, browMat);
    browL.position.set(-0.62, 3.35, faceZ);
    browL.rotation.z = 0.4;
    group.add(browL);
    const browR = new THREE.Mesh(browGeom, browMat);
    browR.position.set(0.62, 3.35, faceZ);
    browR.rotation.z = -0.4;
    group.add(browR);

    [-0.62, 0.62].forEach(ex => {
      const eyeWhite = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      eyeWhite.position.set(ex, 2.95, faceZ);
      group.add(eyeWhite);
      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), new THREE.MeshBasicMaterial({ color: 0x1a0d05 }));
      pupil.position.set(ex, 2.88, faceZ + 0.24);
      group.add(pupil);
    });

    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.28, 8), new THREE.MeshLambertMaterial({ color: chocoColor }));
    nose.position.set(0, 2.55, faceZ + 0.15);
    nose.rotation.x = Math.PI / 2;
    group.add(nose);

    const mouth = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.45, 0.16), new THREE.MeshBasicMaterial({ color: 0x1a0d05 }));
    mouth.position.set(0, 2.05, faceZ);
    group.add(mouth);
    for (let t = 0; t < 5; t++) {
      const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.16, 4), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      tooth.position.set(-0.5 + t * 0.25, 2.24, faceZ + 0.09);
      tooth.rotation.x = Math.PI;
      group.add(tooth);
    }

    group.scale.set(1.6, 1.6, 1.6);
    return group;
  }

  spawnBoss(pos) {
    const mesh = this.createChocolateBossModel();
    mesh.position.copy(pos);
    this.scene.add(mesh);

    const hitbox = EnemiesManager.HITBOX_BY_TYPE.boss;
    const barW = 3.6;
    const barGroup = new THREE.Group();
    const barBg = new THREE.Mesh(
      new THREE.PlaneGeometry(barW, 0.22),
      new THREE.MeshBasicMaterial({ color: 0x1a0d2e, side: THREE.DoubleSide, depthTest: false, transparent: true, opacity: 0.85 })
    );
    const barFg = new THREE.Mesh(
      new THREE.PlaneGeometry(barW, 0.22),
      new THREE.MeshBasicMaterial({ color: 0x2ecc71, side: THREE.DoubleSide, depthTest: false })
    );
    barFg.position.z = 0.002;
    barGroup.add(barBg, barFg);
    const offsetY = hitbox.centerY + hitbox.halfHeight + 0.6;
    barGroup.position.set(pos.x, pos.y + offsetY, pos.z);
    barGroup.renderOrder = 999;
    barBg.renderOrder = 999;
    barFg.renderOrder = 1000;
    this.scene.add(barGroup);

    const boss = {
      type: 'boss',
      area: 'bossArena',
      mesh: mesh,
      pos: mesh.position,
      health: 1000,
      maxHealth: 1000,
      speed: 0,
      attackRange: 0,
      attackCooldown: 999,
      lastAttackTime: 0,
      state: 'boss',
      alive: true,
      hitFlashTimer: 0,
      hitbox: hitbox,
      healthBarGroup: barGroup,
      healthBarFg: barFg,
      healthBarW: barW,
      healthBarOffsetY: offsetY,
      immuneWeaponTypes: ['rocket', 'bfg'],
      baseY: pos.y,
      bobPhase: 0,
      active: false, // Stays fully dormant — no attacks at all — until the Porta Rosquinha opens
      bossState: 'idle',
      bossTimer: 2.0,
      bossAttackCooldown: 2.0,
      lightningTarget: null,
      telegraphMesh: null
    };

    this.enemies.push(boss);
    this.totalSpawned++;
    return boss;
  }

  // Called once the Porta Rosquinha (Bridge -> Boss Arena) opens. Before this, the boss
  // just stands there, fully dormant — this is what stops its lightning/earthquake attacks
  // from ever triggering while the player is still elsewhere on the map.
  activateBoss() {
    const boss = this.enemies.find(e => e.type === 'boss' && e.alive);
    if (!boss || boss.active) return;
    boss.active = true;
    boss.bossTimer = 2.5;
    window.soundEngine.playTone(100, 0.5, 'sawtooth', 0.4);
    window.game.showMessage("🍫 O CHOCOLATE FURIOSO DESPERTOU!");
  }

  updateBossAI(boss, player, delta, mapManager) {
    // Always face the player, gentle menacing float
    boss.mesh.lookAt(new THREE.Vector3(player.position.x, boss.pos.y, player.position.z));
    boss.bobPhase += delta * 1.1;
    boss.pos.y = boss.baseY + Math.sin(boss.bobPhase) * 0.35;

    // Fully dormant until the Boss Arena door opens — and, as a second safety net, only
    // ever attacks while the player is actually near the arena (never leaks into other areas).
    if (!boss.active) return;
    const distToPlayer = boss.pos.distanceTo(player.position);
    if (distToPlayer > 40) return;

    boss.bossTimer -= delta;
    if (boss.bossTimer > 0) return;

    if (boss.bossState === 'idle') {
      // Lightning is the frequent bread-and-butter attack; earthquake is the rarer big one.
      if (Math.random() < 0.7) {
        this.startBossLightning(boss, player);
      } else {
        this.startBossEarthquake(boss);
      }
    } else if (boss.bossState === 'lightning_telegraph') {
      this.resolveBossLightning(boss, player);
    } else if (boss.bossState === 'earthquake_telegraph') {
      this.resolveBossEarthquake(boss, player);
    }
  }

  startBossLightning(boss, player) {
    boss.bossState = 'lightning_telegraph';
    boss.bossTimer = 1.0;
    boss.lightningTarget = player.position.clone();
    boss.lightningTarget.y = 0;

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(1.6, 2.1, 24),
      new THREE.MeshBasicMaterial({ color: 0xfeca57, side: THREE.DoubleSide, transparent: true, opacity: 0.85 })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.copy(boss.lightningTarget);
    ring.position.y = 0.06;
    this.scene.add(ring);
    boss.telegraphMesh = ring;

    window.soundEngine.playTone(900, 0.15, 'sawtooth', 0.3);
    window.game.showMessage("⚡ O Chocolate Furioso vai atirar um RAIO! Saia do círculo!");
  }

  resolveBossLightning(boss, player) {
    if (boss.telegraphMesh) {
      this.scene.remove(boss.telegraphMesh);
      boss.telegraphMesh = null;
    }

    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.6, 14, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 })
    );
    beam.position.copy(boss.lightningTarget);
    beam.position.y = 7;
    this.scene.add(beam);
    window.soundEngine.playExplosion();
    this.particles.spawnHitSparks(boss.lightningTarget, new THREE.Vector3(0, 1, 0), 0xfeca57);
    setTimeout(() => this.scene.remove(beam), 300);

    const dist = Math.sqrt((player.position.x - boss.lightningTarget.x) ** 2 + (player.position.z - boss.lightningTarget.z) ** 2);
    if (dist < 2.3) {
      player.takeBossDamage(0.2);
      window.game.showMessage("⚡ O raio te atingiu!");
    } else {
      window.game.showMessage("✨ Você desviou do raio!");
    }

    boss.bossState = 'idle';
    boss.bossTimer = boss.bossAttackCooldown;
  }

  startBossEarthquake(boss) {
    boss.bossState = 'earthquake_telegraph';
    boss.bossTimer = 1.8;

    window.soundEngine.playTone(80, 0.4, 'sawtooth', 0.4);
    window.game.showMessage("🌎 TERREMOTO! Corra pra longe do Chocolate Furioso!");
  }

  resolveBossEarthquake(boss, player) {
    for (let i = 0; i < 4; i++) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.5 + i * 4.5, 1 + i * 4.5, 32),
        new THREE.MeshBasicMaterial({ color: 0x9b59b6, side: THREE.DoubleSide, transparent: true, opacity: 0.55 })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(boss.pos.x, 0.06, boss.pos.z);
      this.scene.add(ring);
      setTimeout(() => this.scene.remove(ring), 600);
    }
    window.soundEngine.playExplosion();

    const dist = Math.sqrt((player.position.x - boss.pos.x) ** 2 + (player.position.z - boss.pos.z) ** 2);
    const EARTHQUAKE_RADIUS = 15;
    if (dist < EARTHQUAKE_RADIUS) {
      player.takeBossDamage(0.2);
      window.game.showMessage("🌎 O terremoto te atingiu!");
    } else {
      window.game.showMessage("✨ Você escapou do terremoto!");
    }

    boss.bossState = 'idle';
    boss.bossTimer = boss.bossAttackCooldown;
  }

  spawnEnemy(type, pos, area = 'default', hpMultiplier = 1.0) {
    let mesh = null;
    let hp = 100;
    let speed = 9.0;
    let attackRange = 12.0;
    let attackCooldown = 1.6;

    if (type === 'cat') {
      // 3D Origami Cat (Image 2)
      mesh = this.createOrigamiCatModel();
      hp = 100; // Fast & agile rusher
      speed = 11.5;
      attackRange = 3.2;
      attackCooldown = 0.9;
    } else if (type === 'unicorn') {
      // 3D Voxel Rainbow Unicorn (Image 3)
      mesh = this.createVoxelUnicornModel();
      hp = 100;
      speed = 9.0;
      attackRange = 14.0;
      attackCooldown = 1.3;
    } else if (type === 'bear') {
      // Chonky Honey Bear
      mesh = this.createBearModel();
      hp = 100;
      speed = 5.0;
      attackRange = 18.0;
      attackCooldown = 2.2;
    } else if (type === 'pegasus') {
      // Sky Pegasus
      mesh = this.createPegasusModel();
      hp = 100;
      speed = 7.5;
      attackRange = 20.0;
      attackCooldown = 1.5;
    }

    hp = Math.round(hp * hpMultiplier);

    mesh.position.copy(pos);
    this.scene.add(mesh);

    const hitbox = EnemiesManager.HITBOX_BY_TYPE[type] || { halfWidth: 0.7, halfDepth: 0.7, halfHeight: 0.9, centerY: 0.9 };

    // Floating HP bar above the enemy's head — real-time, visible proof that hits are
    // registering (and how close the enemy is to dying), independent of the 3D model.
    const barW = 0.9;
    const barGroup = new THREE.Group();
    const barBg = new THREE.Mesh(
      new THREE.PlaneGeometry(barW, 0.12),
      new THREE.MeshBasicMaterial({ color: 0x1a0d2e, side: THREE.DoubleSide, depthTest: false, transparent: true, opacity: 0.85 })
    );
    const barFg = new THREE.Mesh(
      new THREE.PlaneGeometry(barW, 0.12),
      new THREE.MeshBasicMaterial({ color: 0x2ecc71, side: THREE.DoubleSide, depthTest: false })
    );
    barFg.position.z = 0.002;
    barGroup.add(barBg, barFg);
    barGroup.position.set(0, hitbox.centerY + hitbox.halfHeight + 0.45, 0);
    barGroup.renderOrder = 999;
    barBg.renderOrder = 999;
    barFg.renderOrder = 1000;
    this.scene.add(barGroup); // Added directly to scene (not as a child) so it never inherits the enemy's own rotation

    const enemy = {
      type: type,
      area: area,
      mesh: mesh,
      pos: mesh.position,
      health: hp,
      maxHealth: hp,
      speed: speed,
      attackRange: attackRange,
      attackCooldown: attackCooldown,
      lastAttackTime: 0,
      state: 'patrol',
      patrolTimer: Math.random() * 3,
      patrolDir: new THREE.Vector3((Math.random() - 0.5), 0, (Math.random() - 0.5)).normalize(),
      alive: true,
      hitFlashTimer: 0,
      hitbox: hitbox,
      healthBarGroup: barGroup,
      healthBarFg: barFg,
      healthBarW: barW,
      healthBarOffsetY: hitbox.centerY + hitbox.halfHeight + 0.45
    };

    this.enemies.push(enemy);
    this.totalSpawned++;
    return enemy;
  }

  // Builds a THREE.Box3 that fully covers the enemy's physical model, following its
  // current position. This is what every damage/hit check below tests against.
  getEnemyBox(e) {
    const hb = e.hitbox;
    return new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(e.pos.x, e.pos.y + hb.centerY, e.pos.z),
      new THREE.Vector3(hb.halfWidth * 2, hb.halfHeight * 2, hb.halfDepth * 2)
    );
  }

  spawnAllEnemies() {
    // Courtyard (Origami Cats & Voxel Unicorns) — clearing this opens "Porta do Pátio"
    this.spawnEnemy('cat', new THREE.Vector3(-8, 0, 5), 'courtyard');
    this.spawnEnemy('cat', new THREE.Vector3(8, 0, 5), 'courtyard');
    this.spawnEnemy('unicorn', new THREE.Vector3(0, 0, -8), 'courtyard');

    // Donut Hall (Origami Cats, Voxel Unicorns & Honey Bear) — clearing opens "Porta Arco-Íris"
    this.spawnEnemy('cat', new THREE.Vector3(-10, 0, 36), 'donutHall');
    this.spawnEnemy('unicorn', new THREE.Vector3(10, 0, 36), 'donutHall');
    this.spawnEnemy('cat', new THREE.Vector3(0, 0, 48), 'donutHall');
    this.spawnEnemy('bear', new THREE.Vector3(0, 0, 56), 'donutHall'); // Guards Rainbow Key!

    // Inverted Gravity Vault (Pegasus, Voxel Unicorn & Origami Cats) — clearing opens "Porta Estelar"
    this.spawnEnemy('pegasus', new THREE.Vector3(0, 6, 80), 'vault');
    this.spawnEnemy('pegasus', new THREE.Vector3(-10, 8, 90), 'vault');
    this.spawnEnemy('unicorn', new THREE.Vector3(14, 0, 90), 'vault');
    this.spawnEnemy('cat', new THREE.Vector3(-8, 0, 96), 'vault');

    // Secret Armory Guards (side room, no gating door)
    this.spawnEnemy('cat', new THREE.Vector3(-29, 0, 38), 'secretArmory');
    this.spawnEnemy('bear', new THREE.Vector3(-29, 0, 48), 'secretArmory');

    // Rainbow Bridge Aerial Patrol — clearing opens "Porta Rosquinha"
    this.spawnEnemy('pegasus', new THREE.Vector3(32, 6, 84), 'bridge');
    this.spawnEnemy('pegasus', new THREE.Vector3(48, 7, 84), 'bridge');

    // Boss / Guardian Sanctuary (Bears, Pegasus & Voxel Unicorns) — final area
    this.spawnEnemy('bear', new THREE.Vector3(84, 1, 78), 'bossArena');
    this.spawnEnemy('bear', new THREE.Vector3(84, 1, 90), 'bossArena');
    this.spawnEnemy('pegasus', new THREE.Vector3(88, 8, 84), 'bossArena');
    this.spawnEnemy('unicorn', new THREE.Vector3(92, 1, 76), 'bossArena');
    this.spawnEnemy('cat', new THREE.Vector3(92, 1, 92), 'bossArena');

    // THE FINAL BOSS: a furious, giant chocolate bar guarding the sanctuary's center!
    this.spawnBoss(new THREE.Vector3(88, 0, 84));

    // Frozen Crystal Tower (bonus phase) — another +20% HP on top of the previous bump
    // (1.2 -> 1.44 total), as a proper difficulty step up. Tagged per-room so each door
    // opens once its room clears.
    this.spawnEnemy('cat', new THREE.Vector3(130, 0, 74), 'iceHall', 1.44);
    this.spawnEnemy('unicorn', new THREE.Vector3(146, 0, 96), 'iceHall', 1.44);

    this.spawnEnemy('bear', new THREE.Vector3(172, 0, 72), 'iceCavern', 1.44);
    this.spawnEnemy('pegasus', new THREE.Vector3(190, 7, 96), 'iceCavern', 1.44);
    this.spawnEnemy('unicorn', new THREE.Vector3(208, 0, 70), 'iceCavern', 1.44);
    this.spawnEnemy('cat', new THREE.Vector3(202, 0, 98), 'iceCavern', 1.44);
    // 3 extra bears in the Ice Cavern (around the unicorn statue, clear of its plinth)
    this.spawnEnemy('bear', new THREE.Vector3(165, 0, 96), 'iceCavern', 1.44);
    this.spawnEnemy('bear', new THREE.Vector3(216, 0, 96), 'iceCavern', 1.44);
    this.spawnEnemy('bear', new THREE.Vector3(195, 0, 70), 'iceCavern', 1.44);

    this.spawnEnemy('bear', new THREE.Vector3(238, 0, 94), 'crystalThrone', 1.44);
    this.spawnEnemy('cat', new THREE.Vector3(252, 0, 72), 'crystalThrone', 1.44);

    // Aurora Bridge (newest phase) — aerial patrol, same 1.44x HP treatment, plus 3 new
    // bears patrolling the bridge itself
    this.spawnEnemy('pegasus', new THREE.Vector3(298, 6, 84), 'auroraBridge', 1.2);
    this.spawnEnemy('pegasus', new THREE.Vector3(322, 7, 84), 'auroraBridge', 1.2);
    this.spawnEnemy('bear', new THREE.Vector3(290, 0, 72), 'auroraBridge', 1.44);
    this.spawnEnemy('bear', new THREE.Vector3(310, 0, 96), 'auroraBridge', 1.44);
    this.spawnEnemy('bear', new THREE.Vector3(330, 0, 72), 'auroraBridge', 1.44);
  }

  // ==================== AI BEHAVIOR & LOOP ====================
  // Tries to move an enemy to a candidate world position; refuses the move if it would
  // intersect a solid map collider (wall, pillar, closed door, undestroyed secret wall...).
  // This is what stops enemies from walking straight through walls into rooms/phases
  // they have no business being in.
  canEnemyMoveTo(e, testX, testZ, mapManager) {
    const hb = e.hitbox;
    // Slightly slimmer than the actual hit-box so enemies don't snag on corners while sliding
    const box = new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(testX, e.pos.y + hb.centerY, testZ),
      new THREE.Vector3(hb.halfWidth * 1.5, hb.halfHeight * 1.8, hb.halfDepth * 1.5)
    );
    for (let i = 0; i < mapManager.colliders.length; i++) {
      if (box.intersectsBox(mapManager.colliders[i])) return false;
    }
    return true;
  }

  update(delta, player, mapManager) {
    const nowSec = performance.now() / 1000;
    const playerPos = player.position;

    // Update enemies
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (!e.alive) continue;

      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= delta;
        if (e.hitFlashTimer <= 0) {
          e.mesh.traverse(child => {
            if (child.isMesh && child.material && child.userData.origHex !== undefined) {
              child.material.color.setHex(child.userData.origHex);
            }
          });
        }
      }

      if (e.type === 'boss') {
        this.updateBossAI(e, player, delta, mapManager);
        e.healthBarGroup.position.set(e.pos.x, e.pos.y + e.healthBarOffsetY, e.pos.z);
        if (this.camera) {
          e.healthBarGroup.quaternion.copy(this.camera.quaternion);
        }
        continue;
      }

      const distToPlayer = e.pos.distanceTo(playerPos);

      // AI Line-of-sight awareness
      if (distToPlayer < 30.0) {
        e.state = 'chase';
      }

      if (e.state === 'chase') {
        const lookTarget = new THREE.Vector3(playerPos.x, e.pos.y, playerPos.z);
        e.mesh.lookAt(lookTarget);

        // Move towards player (X and Z checked independently so enemies slide along walls
        // instead of getting fully stuck, but can never pass through a solid collider)
        const isMelee = (e.type === 'cat');
        if (distToPlayer > (isMelee ? 1.6 : 6.0)) {
          const moveDir = playerPos.clone().sub(e.pos).normalize();
          const stepX = moveDir.x * e.speed * delta;
          const stepZ = moveDir.z * e.speed * delta;

          if (this.canEnemyMoveTo(e, e.pos.x + stepX, e.pos.z, mapManager)) {
            e.pos.x += stepX;
          }
          if (this.canEnemyMoveTo(e, e.pos.x, e.pos.z + stepZ, mapManager)) {
            e.pos.z += stepZ;
          }

          // Flying hover for pegasus
          if (e.type === 'pegasus') {
            const targetY = 5.5 + Math.sin(nowSec * 3) * 1.5;
            e.pos.y = THREE.MathUtils.lerp(e.pos.y, targetY, delta * 2.5);
            if (e.mesh.userData.leftWing) {
              e.mesh.userData.leftWing.rotation.z = Math.sin(nowSec * 14) * 0.4;
              e.mesh.userData.rightWing.rotation.z = -Math.sin(nowSec * 14) * 0.4;
            }
          }
        }

        // Attack Trigger
        if (distToPlayer <= e.attackRange && (nowSec - e.lastAttackTime > e.attackCooldown)) {
          e.lastAttackTime = nowSec;
          this.executeEnemyAttack(e, playerPos);
        }
      } else {
        // Patrol wander
        e.patrolTimer -= delta;
        if (e.patrolTimer <= 0) {
          e.patrolTimer = 2 + Math.random() * 3;
          e.patrolDir.set((Math.random() - 0.5), 0, (Math.random() - 0.5)).normalize();
        }
        const pStepX = e.patrolDir.x * 2.5 * delta;
        const pStepZ = e.patrolDir.z * 2.5 * delta;
        let moved = false;
        if (this.canEnemyMoveTo(e, e.pos.x + pStepX, e.pos.z, mapManager)) {
          e.pos.x += pStepX;
          moved = true;
        }
        if (this.canEnemyMoveTo(e, e.pos.x, e.pos.z + pStepZ, mapManager)) {
          e.pos.z += pStepZ;
          moved = true;
        }
        // Bumped into a wall while patrolling — pick a new random direction next tick
        if (!moved) {
          e.patrolTimer = 0;
        }
        e.mesh.lookAt(e.pos.clone().add(e.patrolDir));
      }

      if (e.type !== 'pegasus') {
        e.pos.y = 0.0;
      }

      // Keep the floating HP bar above the enemy's head, always facing the camera
      e.healthBarGroup.position.set(e.pos.x, e.pos.y + e.healthBarOffsetY, e.pos.z);
      if (this.camera) {
        e.healthBarGroup.quaternion.copy(this.camera.quaternion);
      }
    }

    // Update enemy projectiles
    for (let pIdx = this.enemyProjectiles.length - 1; pIdx >= 0; pIdx--) {
      const proj = this.enemyProjectiles[pIdx];
      proj.life -= delta;

      if (proj.life <= 0) {
        this.destroyEnemyProjectile(pIdx);
        continue;
      }

      proj.mesh.position.addScaledVector(proj.dir, proj.speed * delta);

      // Check collision with player
      if (proj.mesh.position.distanceTo(player.position) < 1.4) {
        player.takeDamage(proj.damage);
        this.particles.spawnHitSparks(proj.mesh.position, proj.dir.clone().negate(), 0xff6b8b);
        this.destroyEnemyProjectile(pIdx);
        continue;
      }
    }
  }

  executeEnemyAttack(enemy, playerPos) {
    const origin = enemy.pos.clone();
    origin.y += 1.0;
    const dir = playerPos.clone().sub(origin).normalize();

    if (enemy.type === 'cat') {
      // Fast Origami Cat Melee Claw Swipe
      window.soundEngine.playTone(550, 0.08, 'sawtooth', 0.3);
      if (enemy.pos.distanceTo(playerPos) < 2.5) {
        window.player.takeDamage(12);
      }
    } else if (enemy.type === 'unicorn') {
      // Voxel Unicorn: Rainbow Star Blast
      window.soundEngine.playLaser(700, 0.1, 'triangle');
      this.spawnEnemyBullet(origin, dir, 24.0, 12, 0xfeca57);
    } else if (enemy.type === 'bear') {
      // Honey Cannon: Explosive Honey Ball
      window.soundEngine.playTone(180, 0.25, 'sine', 0.4);
      this.spawnEnemyBullet(origin, dir, 16.0, 20, 0xff9f43, 0.35);
    } else if (enemy.type === 'pegasus') {
      // Sky Pegasus: Triple Rainbow Spark Spread
      window.soundEngine.playTone(900, 0.15, 'triangle', 0.35);
      [-0.15, 0, 0.15].forEach(ang => {
        const spread = dir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), ang);
        this.spawnEnemyBullet(origin, spread, 22.0, 12, 0x00d2d3);
      });
    }
  }

  spawnEnemyBullet(pos, dir, speed, damage, color, radius = 0.18) {
    const geom = new THREE.SphereGeometry(radius, 8, 8);
    const mat = new THREE.MeshBasicMaterial({ color: color });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(pos);
    this.scene.add(mesh);

    this.enemyProjectiles.push({
      mesh: mesh,
      dir: dir,
      speed: speed,
      damage: damage,
      life: 3.5
    });
  }

  destroyEnemyProjectile(idx) {
    const p = this.enemyProjectiles[idx];
    this.scene.remove(p.mesh);
    if (p.mesh.geometry) p.mesh.geometry.dispose();
    if (p.mesh.material) p.mesh.material.dispose();
    this.enemyProjectiles.splice(idx, 1);
  }

  // ==================== HIT DETECTION & CARTOON DEFEAT ====================
  // Every check below tests against the enemy's full physical bounding box (see
  // getEnemyBox), not a single point/sphere — so a shot that clips a wing, a paw,
  // or the top of a head registers just as reliably as a dead-center hit.
  checkProjectileHit(startPos, endPos, damage, weaponType) {
    const segment = endPos.clone().sub(startPos);
    const segLen = segment.length();

    for (let e of this.enemies) {
      if (!e.alive) continue;

      const box = this.getEnemyBox(e);

      // Fast path: either endpoint already inside the box (very close range / point-blank).
      if (box.containsPoint(startPos) || box.containsPoint(endPos)) {
        this.damageEnemy(e, damage, weaponType);
        return true;
      }

      if (segLen > 0) {
        const dir = segment.clone().divideScalar(segLen);
        const ray = new THREE.Ray(startPos, dir);
        const hitPoint = new THREE.Vector3();
        if (ray.intersectBox(box, hitPoint) && startPos.distanceTo(hitPoint) <= segLen) {
          this.damageEnemy(e, damage, weaponType);
          return true;
        }
      }
    }
    return false;
  }

  checkMeleeHit(origin, dir, range, damage, weaponType) {
    for (let e of this.enemies) {
      if (!e.alive) continue;
      const box = this.getEnemyBox(e);

      // Distance from the player to the nearest surface point of the enemy's actual body.
      const dist = box.distanceToPoint(origin);
      if (dist > range) continue;

      // Cone check still uses the enemy's center so the swing has to roughly face them.
      const center = box.getCenter(new THREE.Vector3());
      const toEnemy = center.clone().sub(origin);
      if (toEnemy.lengthSq() === 0 || toEnemy.normalize().dot(dir) > 0.35) {
        this.damageEnemy(e, damage, weaponType);
      }
    }
  }

  zapNearbyEnemies(center, radius, damage, weaponType) {
    for (let e of this.enemies) {
      if (!e.alive) continue;
      const box = this.getEnemyBox(e);
      if (box.distanceToPoint(center) <= radius) {
        this.damageEnemy(e, damage, weaponType);
        this.particles.spawnHitSparks(e.pos, new THREE.Vector3(0, 1, 0), 0xff9ff3);
      }
    }
  }

  dealSplashDamage(center, radius, damage, weaponType) {
    for (let e of this.enemies) {
      if (!e.alive) continue;
      const box = this.getEnemyBox(e);
      const d = box.distanceToPoint(center);
      if (d <= radius) {
        const falloff = 1 - Math.max(0, d / radius);
        this.damageEnemy(e, Math.round(damage * falloff), weaponType);
      }
    }
  }

  damageEnemy(enemy, damage, weaponType) {
    if (enemy.immuneWeaponTypes && weaponType && enemy.immuneWeaponTypes.includes(weaponType)) {
      // Immune hit: clear feedback so it doesn't read as a bug, but zero damage applied.
      this.particles.spawnHitSparks(enemy.pos, new THREE.Vector3(0, 1, 0), 0xffffff);
      window.soundEngine.playTone(150, 0.08, 'square', 0.18);
      window.game.showMessage("🍫 O Chocolate Furioso é imune a essa arma!");
      return;
    }

    enemy.health -= damage;
    window.soundEngine.playEnemyHit();
    this.particles.spawnHitSparks(enemy.pos, new THREE.Vector3(0, 1, 0), 0xfeca57);

    // Update the floating HP bar: shrinks + shifts from green -> yellow -> red as it empties.
    const frac = Math.max(0, enemy.health / enemy.maxHealth);
    enemy.healthBarFg.scale.x = frac;
    enemy.healthBarFg.position.x = -(enemy.healthBarW * (1 - frac)) / 2;
    const barColor = frac > 0.5 ? 0x2ecc71 : (frac > 0.2 ? 0xfeca57 : 0xff4757);
    enemy.healthBarFg.material.color.setHex(barColor);

    // Visual Flash on Hit: Flash white/red so player immediately SEES damage registration!
    enemy.mesh.traverse(child => {
      if (child.isMesh && child.material) {
        if (child.userData.origHex === undefined && child.material.color) {
          child.userData.origHex = child.material.color.getHex();
        }
        if (child.material.color) {
          child.material.color.setHex(0xffffff); // Flash bright white
        }
      }
    });

    enemy.hitFlashTimer = 0.14;
    window.game.onEnemyHit();

    if (enemy.health <= 0) {
      this.defeatEnemy(enemy);
    }
  }

  // True once every enemy tagged with this area is dead — used to auto-open the door
  // leading to the next phase (see MapManager.onAreaCleared).
  isAreaCleared(area) {
    return !this.enemies.some(e => e.area === area && e.alive);
  }

  defeatEnemy(enemy) {
    enemy.alive = false;
    this.killsCount++;

    // CARTOON EXPLOSION OF CHOCOLATE, SPRINKLES & RAINBOWS (NO GORE!)
    this.particles.spawnEnemyDefeat(enemy.pos);
    window.soundEngine.playEnemyDefeat();

    // Remove 3D model + floating HP bar — the enemy fully disappears from the game.
    this.scene.remove(enemy.mesh);
    this.scene.remove(enemy.healthBarGroup);

    // If this was the last enemy standing in its area, open the door(s) to the next phase!
    if (this.isAreaCleared(enemy.area) && window.mapManager && window.mapManager.onAreaCleared) {
      window.mapManager.onAreaCleared(enemy.area);
    }

    // HUD notification
    const nameMap = {
      cat: "Gato Origami",
      unicorn: "Unicórnio Voxel",
      bear: "Urso de Mel",
      pegasus: "Pégaso Celestial"
    };
    window.game.onEnemyDefeated(nameMap[enemy.type] || enemy.type);
  }

  clearAll() {
    this.enemies.forEach(e => {
      this.scene.remove(e.mesh);
      if (e.healthBarGroup) this.scene.remove(e.healthBarGroup);
    });
    this.enemies = [];

    this.enemyProjectiles.forEach(p => {
      this.scene.remove(p.mesh);
    });
    this.enemyProjectiles = [];
  }
}
