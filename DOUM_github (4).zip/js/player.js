// DOUM - Player Controller: 1st/3rd Person Camera, Gravity Boots & Movement
// Features: Dynamic camera switching, surface/ceiling gravity shift, double jump,
// collision detection with platform landing, and procedural 3D Furry Unicorn Hero model.

class PlayerController {
  constructor(camera, scene, domElement) {
    this.camera = camera;
    this.scene = scene;
    this.domElement = domElement;

    // Transform & Physics
    this.position = new THREE.Vector3(0, 0.95, -10);
    this.velocity = new THREE.Vector3();
    this.moveSpeed = 16.0;
    this.jumpForce = 13.5;
    this.gravity = -34.0;
    this.isGrounded = false;
    this.jumpCount = 0;
    this.maxJumps = 2; // Double jump!

    // Player bounding dimensions
    this.radius = 0.45;
    this.halfHeight = 0.9;

    // Gravity Boots System: Up Vector & Mode
    // Modes: 'floor' (normal, up = 0,1,0), 'ceiling' (inverted, up = 0,-1,0)
    // The boots are now a dropped item hidden behind a destructible wall (Secret 3) —
    // the player starts WITHOUT them and can't use the mechanic until they're found!
    this.hasGravityBoots = false;
    this.gravityMode = 'floor';
    this.gravityUp = new THREE.Vector3(0, 1, 0);
    this.targetCameraUp = new THREE.Vector3(0, 1, 0);

    // Camera Switch System (1st Person <-> 3rd Person)
    this.isFirstPerson = true;
    this.thirdPersonDist = 3.6;
    this.thirdPersonHeight = 1.6;

    // Mouse Look Orientation & Sensitivity
    this.yaw = 0;
    this.pitch = 0;
    this.baseMouseSensitivity = 0.0028;
    this.sensitivityMultiplier = 1.6; // Higher responsive default
    this.mouseSensitivity = this.baseMouseSensitivity * this.sensitivityMultiplier;

    // Keys & Input state
    this.keysPressed = {};
    this.mouseButtons = {};

    // Gameplay Stats
    this.health = 100;
    this.maxHealth = 100;
    this.armor = 50;
    this.maxArmor = 100;
    this.ammo = 100;
    this.maxAmmo = 200;
    this.keys = { rainbow: false, star: false, donut: false };

    // Create 3D Human Hero Model for 3rd Person
    this.avatarModel = this.createHumanHeroModel();
    this.scene.add(this.avatarModel);
    this.avatarModel.visible = !this.isFirstPerson;

    // Input listeners
    this.setupInputs();
  }

  setSensitivity(mult) {
    this.sensitivityMultiplier = mult;
    this.mouseSensitivity = this.baseMouseSensitivity * this.sensitivityMultiplier;
  }

  // ==================== 3D HUMAN HERO AVATAR ====================
  createHumanHeroModel() {
    const hero = new THREE.Group();

    // 1. Human Head & Face
    const headGeom = new THREE.BoxGeometry(0.5, 0.55, 0.5);
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xffdfba }); // Human skin tone
    const head = new THREE.Mesh(headGeom, skinMat);
    head.position.set(0, 1.65, 0.02);

    // Stylish Anime / Hero Hair (Vibrant Electric Turquoise/Pink)
    const hairGroup = new THREE.Group();
    const hairMain = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.28, 0.56), new THREE.MeshLambertMaterial({ color: 0x48dbfb }));
    hairMain.position.set(0, 0.22, -0.02);
    // Spiky bangs
    const bang = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.28, 4), new THREE.MeshLambertMaterial({ color: 0x0abde3 }));
    bang.rotation.x = Math.PI / 3;
    bang.position.set(0, 0.12, 0.26);
    hairGroup.add(hairMain, bang);
    head.add(hairGroup);

    // Expressive Cartoon Eyes
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x222f3e });
    const eyeGeom = new THREE.BoxGeometry(0.1, 0.12, 0.05);
    const eyeL = new THREE.Mesh(eyeGeom, eyeMat);
    const eyeR = eyeL.clone();
    eyeL.position.set(-0.14, 0.02, 0.26);
    eyeR.position.set(0.14, 0.02, 0.26);
    head.add(eyeL, eyeR);

    // 2. Human Torso / Cool Hero Jacket
    const torsoGeom = new THREE.BoxGeometry(0.65, 0.85, 0.42);
    const jacketMat = new THREE.MeshLambertMaterial({ color: 0x341f97 }); // Stylish royal violet hero jacket
    const torso = new THREE.Mesh(torsoGeom, jacketMat);
    torso.position.y = 1.0;

    // Neon trim / shirt emblem
    const emblem = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.05), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    emblem.position.set(0, 0.08, 0.2);
    torso.add(emblem);

    // 3. Human Arms & Hands
    const armGeom = new THREE.BoxGeometry(0.18, 0.65, 0.2);
    const armMat = new THREE.MeshLambertMaterial({ color: 0x5f27cd });
    const armL = new THREE.Mesh(armGeom, armMat);
    const armR = armL.clone();
    armL.position.set(-0.45, 0.95, 0);
    armR.position.set(0.45, 0.95, 0.15); // Forward holding gun

    // Hand holding weapon
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.18, 0.55), new THREE.MeshLambertMaterial({ color: 0xff9f43 }));
    gun.position.set(0.45, 0.85, 0.38);

    // 4. Human Legs & Pants
    const legGeom = new THREE.BoxGeometry(0.24, 0.65, 0.26);
    const pantsMat = new THREE.MeshLambertMaterial({ color: 0x222f3e });
    const legL = new THREE.Mesh(legGeom, pantsMat);
    const legR = legL.clone();
    legL.position.set(-0.18, 0.45, 0);
    legR.position.set(0.18, 0.45, 0);

    // 5. Boots on Human Feet — dull grey until the Gravity Boots are actually found!
    const bootGeom = new THREE.BoxGeometry(0.26, 0.22, 0.36);
    const bootMat = new THREE.MeshLambertMaterial({
      color: 0x888888,
      emissive: 0x888888,
      emissiveIntensity: 0.15
    });
    const bootL = new THREE.Mesh(bootGeom, bootMat);
    const bootR = bootL.clone();
    bootL.position.set(-0.18, 0.11, 0.04);
    bootR.position.set(0.18, 0.11, 0.04);

    hero.add(head, torso, armL, armR, legL, legR, bootL, bootR, gun);
    hero.userData = { head: head, armL: armL, armR: armR, legL: legL, legR: legR, bootL: bootL, bootR: bootR };
    return hero;
  }

  // ==================== INPUT SETUP ====================
  setupInputs() {
    window.addEventListener('keydown', (e) => {
      this.keysPressed[e.code] = true;

      // Camera switch hotkey [V]
      if (e.code === 'KeyV') {
        this.toggleCameraMode();
      }

      // Gravity Boots hotkey [G]
      if (e.code === 'KeyG') {
        this.toggleGravityBoots();
      }

      // Interaction [E]
      if (e.code === 'KeyE') {
        if (window.mapManager) window.mapManager.interact(this);
      }

      // Weapons 1-6
      if (e.code.startsWith('Digit')) {
        const slot = parseInt(e.code.replace('Digit', '')) - 1;
        if (window.weapons) window.weapons.selectWeapon(slot);
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keysPressed[e.code] = false;
    });

    window.addEventListener('mousedown', (e) => {
      if (document.pointerLockElement !== this.domElement) {
        this.domElement.requestPointerLock();
        return;
      }

      if (e.button === 0) {
        // Left click = Shoot
        this.mouseButtons[0] = true;
      } else if (e.button === 2) {
        // Right click = Quick Camera Toggle!
        this.toggleCameraMode();
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.mouseButtons[0] = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (document.pointerLockElement === this.domElement) {
        this.yaw -= e.movementX * this.mouseSensitivity;
        this.pitch -= e.movementY * this.mouseSensitivity;
        this.pitch = Math.max(-Math.PI / 2.1, Math.min(Math.PI / 2.1, this.pitch));
      }
    });

    // Prevent right-click context menu
    window.addEventListener('contextmenu', e => e.preventDefault());

    // Connect HUD Button clicks
    document.getElementById('btn-camera-toggle').addEventListener('click', () => this.toggleCameraMode());
    document.getElementById('btn-gravity-toggle').addEventListener('click', () => this.toggleGravityBoots());
  }

  // ==================== SPECIAL MECHANIC 1: CAMERA TOGGLE ====================
  toggleCameraMode() {
    this.isFirstPerson = !this.isFirstPerson;
    this.avatarModel.visible = !this.isFirstPerson;

    if (window.weapons) {
      window.weapons.updateViewModelVisibility(this.isFirstPerson);
    }

    const camText = document.getElementById('camera-mode-text');
    if (camText) {
      camText.textContent = this.isFirstPerson ? "1ª PESSOA" : "3ª PESSOA";
    }

    window.soundEngine.playTone(520, 0.1, 'sine', 0.25);
    window.game.showMessage(this.isFirstPerson ? "📷 Câmera em 1ª Pessoa (Foco em Precisão)" : "📷 Câmera em 3ª Pessoa (Visão Ampla do Herói Furry)");
  }

  // ==================== SPECIAL MECHANIC 2: GRAVITY BOOTS ====================
  // Called once when the player picks up the Gravity Boots pickup (hidden behind the
  // Secret 3 destructible wall). Before this runs, toggleGravityBoots() always refuses.
  unlockGravityBoots() {
    if (this.hasGravityBoots) return;
    this.hasGravityBoots = true;

    // Boots light up on the 3rd-person avatar to reflect the unlock
    const u = this.avatarModel.userData;
    [u.bootL, u.bootR].forEach(b => {
      if (b && b.material) {
        b.material.color.setHex(0x00d2d3);
        b.material.emissive.setHex(0x00d2d3);
        b.material.emissiveIntensity = 0.6;
      }
    });

    const gravBtn = document.getElementById('btn-gravity-toggle');
    if (gravBtn) {
      gravBtn.classList.remove('locked');
      gravBtn.title = "Ativar Botas de Gravidade";
    }
    const gravText = document.getElementById('gravity-mode-text');
    if (gravText) gravText.textContent = "GRAV: CHÃO 🥾";

    window.soundEngine.playPickup('weapon');
    window.particleSystem.spawnConfettiBurst(this.position, 20);
    window.game.showMessage("🥾 BOTAS DE GRAVIDADE ENCONTRADAS! Pressione [G] para andar no teto!");
  }

  toggleGravityBoots() {
    const gravBtn = document.getElementById('btn-gravity-toggle');
    const gravText = document.getElementById('gravity-mode-text');

    if (!this.hasGravityBoots) {
      window.soundEngine.playTone(150, 0.15, 'sawtooth', 0.3);
      window.game.showMessage("🔒 Botas de Gravidade ainda não encontradas! Procure atrás de uma parede destrutível...");
      return;
    }

    if (this.gravityMode === 'floor') {
      // Shift to Ceiling Inversion!
      this.gravityMode = 'ceiling';
      this.gravityUp.set(0, -1, 0);
      this.targetCameraUp.set(0, -1, 0);

      window.soundEngine.playGravityShift(true);
      window.particleSystem.spawnGravityRing(this.position, new THREE.Vector3(0, 1, 0));
      window.game.showMessage("🥾 Botas de Gravidade: TETO ATIVADO! (Gravidade Invertida)");

      gravBtn.classList.add('gravity-active');
      gravText.textContent = "GRAV: TETO 🥾";
    } else {
      // Return to Floor!
      this.gravityMode = 'floor';
      this.gravityUp.set(0, 1, 0);
      this.targetCameraUp.set(0, 1, 0);

      window.soundEngine.playGravityShift(false);
      window.particleSystem.spawnGravityRing(this.position, new THREE.Vector3(0, -1, 0));
      window.game.showMessage("🥾 Botas de Gravidade: CHÃO (Gravidade Normal)");

      gravBtn.classList.remove('gravity-active');
      gravText.textContent = "GRAV: CHÃO 🥾";
    }
  }

  // ==================== MOVEMENT, JUMP & COLLISION ====================
  update(delta, mapManager) {
    // 1. Direction vectors relative to yaw
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    // Desired horizontal movement
    const moveInput = new THREE.Vector3();
    if (this.keysPressed['KeyW']) moveInput.add(forward);
    if (this.keysPressed['KeyS']) moveInput.sub(forward);
    if (this.keysPressed['KeyD']) moveInput.add(right);
    if (this.keysPressed['KeyA']) moveInput.sub(right);

    if (moveInput.lengthSq() > 0) {
      moveInput.normalize().multiplyScalar(this.moveSpeed);
    }

    // Smooth horizontal acceleration
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, moveInput.x, delta * 14);
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, moveInput.z, delta * 14);

    // 2. Jump Handling (Double Jump)
    if (this.keysPressed['Space']) {
      if (!this.spaceDown) {
        this.spaceDown = true;
        if (this.isGrounded || this.jumpCount < this.maxJumps) {
          const jumpDir = this.gravityMode === 'floor' ? 1 : -1;
          this.velocity.y = this.jumpForce * jumpDir;
          this.jumpCount++;
          this.isGrounded = false;
          window.soundEngine.playTone(450 + this.jumpCount * 120, 0.12, 'sine', 0.3);
          window.particleSystem.spawnConfettiBurst(this.position, 6);
        }
      }
    } else {
      this.spaceDown = false;
    }

    // 3. Gravity Application (Inverted in ceiling mode)
    const gravDir = this.gravityMode === 'floor' ? this.gravity : -this.gravity;
    this.velocity.y += gravDir * delta;

    // 4. Sub-Stepped Physics (4 sub-steps per frame - 100% eliminates wall tunneling!)
    const substeps = 4;
    const subDelta = delta / substeps;
    for (let s = 0; s < substeps; s++) {
      this.physicsSubStep(subDelta, mapManager);
    }

    // 5. Hard Map Safety Clamp (Never fall into void or pass through outer perimeter)
    this.clampToWorld();

    // 6. Update Camera Position and Slerp Orientation
    this.updateCamera(delta);

    // 7. Update 3D Avatar (Animations for 3rd Person)
    this.updateAvatar(delta);

    // 8. Continuous firing if mouse is held down
    if (this.mouseButtons[0] && window.weapons) {
      window.weapons.fire(this, window.enemiesManager, window.mapManager);
    }
  }

  physicsSubStep(subDelta, mapManager) {
    const deltaMove = this.velocity.clone().multiplyScalar(subDelta);

    // Test X with collision
    const prevX = this.position.x;
    this.position.x += deltaMove.x;
    if (this.getIntersectingCollider(mapManager)) {
      this.position.x = prevX;
      this.velocity.x = 0;
    }

    // Test Z with collision
    const prevZ = this.position.z;
    this.position.z += deltaMove.z;
    if (this.getIntersectingCollider(mapManager)) {
      this.position.z = prevZ;
      this.velocity.z = 0;
    }

    // Test Y with collision & platform landing
    this.position.y += deltaMove.y;
    const colY = this.getIntersectingCollider(mapManager);

    if (this.gravityMode === 'floor') {
      // Base ground floor y = 0
      if (this.position.y - this.halfHeight <= 0) {
        this.position.y = this.halfHeight;
        this.velocity.y = 0;
        this.isGrounded = true;
        this.jumpCount = 0;
      } else if (colY) {
        if (deltaMove.y <= 0) {
          // Landed on platform / catwalk / box
          this.position.y = colY.max.y + this.halfHeight + 0.001;
          this.velocity.y = 0;
          this.isGrounded = true;
          this.jumpCount = 0;

          // Check if it's a Jump Pad!
          if (this.isNearJumpPad(mapManager)) {
            this.velocity.y = 20.0;
            this.isGrounded = false;
            window.soundEngine.playTone(750, 0.25, 'triangle', 0.5);
            window.particleSystem.spawnConfettiBurst(this.position, 14);
            window.game.showMessage("🚀 SUPER PULO MÁGICO!");
          }
        } else {
          // Bumped ceiling
          this.position.y = colY.min.y - this.halfHeight - 0.001;
          this.velocity.y = 0;
        }
      } else {
        this.isGrounded = false;
      }
    } else {
      // Ceiling gravity mode (inverted)
      if (this.position.y + this.halfHeight >= 14.5) {
        this.position.y = 14.5 - this.halfHeight;
        this.velocity.y = 0;
        this.isGrounded = true;
        this.jumpCount = 0;
      } else if (colY) {
        if (deltaMove.y >= 0) {
          this.position.y = colY.min.y - this.halfHeight - 0.001;
          this.velocity.y = 0;
          this.isGrounded = true;
          this.jumpCount = 0;
        } else {
          this.position.y = colY.max.y + this.halfHeight + 0.001;
          this.velocity.y = 0;
        }
      } else {
        this.isGrounded = false;
      }
    }
  }

  clampToWorld() {
    this.position.x = Math.max(-37.5, Math.min(341.5, this.position.x));
    this.position.z = Math.max(-17.5, Math.min(103.5, this.position.z));
    this.position.y = Math.max(this.halfHeight, Math.min(13.6, this.position.y));
  }

  getIntersectingCollider(mapManager) {
    const pBox = new THREE.Box3().setFromCenterAndSize(
      this.position,
      new THREE.Vector3(this.radius * 2, this.halfHeight * 2, this.radius * 2)
    );

    // Static Colliders
    for (let c of mapManager.colliders) {
      if (pBox.intersectsBox(c)) return c;
    }

    // Destructible Walls
    for (let dw of mapManager.destructibleWalls) {
      if (!dw.destroyed && pBox.intersectsBox(dw.collider)) return dw.collider;
    }

    return null;
  }

  isNearJumpPad(mapManager) {
    for (let c of mapManager.colliders) {
      // Center in jump pad bounds
      if (Math.abs(this.position.x - 78) < 2.0 && (Math.abs(this.position.z - 74) < 2.0 || Math.abs(this.position.z - 94) < 2.0)) {
        return true;
      }
    }
    return false;
  }

  updateCamera(delta) {
    // Smoothly interpolate camera Up-Vector for Gravity Boots
    this.camera.up.lerp(this.targetCameraUp, delta * 8.0).normalize();

    if (this.isFirstPerson) {
      // 1st Person: Camera directly at eye level
      this.camera.position.copy(this.position);
      this.camera.position.y += 0.5 * (this.gravityMode === 'floor' ? 1 : -1);

      // Look rotation
      const euler = new THREE.Euler(0, 0, 0, 'YXZ');
      euler.x = this.pitch;
      euler.y = this.yaw;
      this.camera.quaternion.setFromEuler(euler);
    } else {
      // 3rd Person: Camera placed behind player looking towards avatar
      const euler = new THREE.Euler(0, 0, 0, 'YXZ');
      euler.x = this.pitch;
      euler.y = this.yaw;

      const camRot = new THREE.Quaternion().setFromEuler(euler);
      const offset = new THREE.Vector3(0, this.thirdPersonHeight, this.thirdPersonDist);
      offset.applyQuaternion(camRot);

      this.camera.position.copy(this.position).add(offset);
      this.camera.quaternion.copy(camRot);
    }
  }

  updateAvatar(delta) {
    if (!this.avatarModel.visible) return;

    this.avatarModel.position.copy(this.position);
    this.avatarModel.position.y -= (this.gravityMode === 'floor' ? 0.9 : -0.9);
    this.avatarModel.rotation.y = this.yaw + Math.PI;

    // Flip avatar upside down if in ceiling gravity mode!
    if (this.gravityMode === 'ceiling') {
      this.avatarModel.rotation.z = THREE.MathUtils.lerp(this.avatarModel.rotation.z, Math.PI, delta * 10);
    } else {
      this.avatarModel.rotation.z = THREE.MathUtils.lerp(this.avatarModel.rotation.z, 0, delta * 10);
    }

    // Human running animation (arms & legs swinging)
    const speed = new THREE.Vector2(this.velocity.x, this.velocity.z).length();
    const time = performance.now() * 0.008;

    const u = this.avatarModel.userData;
    if (u.legL && u.legR && u.bootL && u.bootR) {
      if (speed > 1.0) {
        const swing = Math.sin(time * 12);
        u.legL.rotation.x = swing * 0.5;
        u.legR.rotation.x = -swing * 0.5;
        u.bootL.position.z = 0.04 + swing * 0.2;
        u.bootR.position.z = 0.04 - swing * 0.2;

        if (u.armL) u.armL.rotation.x = -swing * 0.4;
      } else {
        u.legL.rotation.x = 0;
        u.legR.rotation.x = 0;
        u.bootL.position.z = 0.04;
        u.bootR.position.z = 0.04;
        if (u.armL) u.armL.rotation.x = 0;
      }
    }
  }

  // ==================== HEALTH & DAMAGE ====================
  takeDamage(amount) {
    if (this.health <= 0) return;

    // Armor absorbs 50%
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, Math.round(amount * 0.5));
      this.armor -= absorbed;
      this.health -= (amount - absorbed);
    } else {
      this.health -= amount;
    }

    window.soundEngine.playHurt();
    window.game.onPlayerHurt();

    if (this.health <= 0) {
      this.health = 0;
      window.game.triggerGameOver();
    }
  }

  // Used by the Chocolate Boss's big attacks (lightning / earthquake): a flat 20% of max
  // armor while any armor remains, then 20% of max health once armor is fully depleted —
  // distinct from normal enemy takeDamage's 50/50 split.
  takeBossDamage(percentOfMax = 0.2) {
    if (this.health <= 0) return;

    if (this.armor > 0) {
      this.armor = Math.max(0, this.armor - Math.round(this.maxArmor * percentOfMax));
    } else {
      this.health = Math.max(0, this.health - Math.round(this.maxHealth * percentOfMax));
    }

    window.soundEngine.playHurt();
    window.game.onPlayerHurt();

    if (this.health <= 0) {
      this.health = 0;
      window.game.triggerGameOver();
    }
  }
}
