// DOUM - Weapons Arsenal & Projectile Engine
// Features 6 colorful fantasy weapons, 1st-person viewmodels, projectile physics,
// recoil animations, and wall-piercing/demolition mechanics.

class WeaponSystem {
  constructor(scene, camera, particleSystem) {
    this.scene = scene;
    this.camera = camera;
    this.particles = particleSystem;

    this.weapons = [
      {
        id: 1,
        name: "Chifre Mágico",
        type: "melee",
        damage: 50,
        fireRate: 0.3,
        ammoCost: 0,
        unlocked: true,
        icon: "🦄"
      },
      {
        id: 2,
        name: "Pistola Estelar",
        type: "projectile",
        damage: 20,
        fireRate: 0.18,
        ammoCost: 1,
        unlocked: true,
        icon: "⭐"
      },
      {
        id: 3,
        name: "Espingarda Confeitos",
        type: "shotgun",
        damage: 4, // 10 pellets x 4 = 40 total damage se todas acertarem
        pellets: 10,
        fireRate: 0.65,
        ammoCost: 2,
        unlocked: true,
        canBreakWalls: true,
        icon: "🍧"
      },
      {
        id: 4,
        name: "Metralhadora Goma",
        type: "rapid",
        damage: 10,
        fireRate: 0.08,
        ammoCost: 1,
        unlocked: true,
        icon: "🍬"
      },
      {
        id: 5,
        name: "Lança-Cupcake",
        type: "rocket",
        damage: 450,
        radius: 5.5,
        fireRate: 0.8,
        ammoCost: 5,
        unlocked: false,
        canBreakWalls: true,
        icon: "🧁"
      },
      {
        id: 6,
        name: "RAINBOW-9999",
        type: "bfg",
        damage: 1000,
        radius: 9.0,
        fireRate: 1.4,
        ammoCost: 20,
        unlocked: false,
        canBreakWalls: true,
        icon: "🌈"
      }
    ];

    this.currentWeaponIndex = 1; // Start with Star Blaster
    this.lastFireTime = 0;
    this.projectiles = [];
    this.recoil = { x: 0, y: 0, z: 0 };

    // Viewmodel container attached to camera
    this.viewmodelHolder = new THREE.Group();
    this.camera.add(this.viewmodelHolder);
    this.viewmodels = [];

    this.initViewModels();
  }

  // ==================== PROCEDURAL 3D VIEWMODELS ====================
  // Simple cartoon hand+forearm pair, reused on every weapon so it actually looks like the
  // hero is holding something instead of a gun floating in space. front=true sits further
  // out along the barrel (the support hand); front=false sits back near the grip/trigger.
  createFPHand(x, y, z, front = false) {
    const group = new THREE.Group();
    const skin = new THREE.MeshLambertMaterial({ color: 0xffdfba });
    const sleeve = new THREE.MeshLambertMaterial({ color: 0x54236e });

    const fist = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.09, front ? 0.13 : 0.16), skin);
    group.add(fist);

    for (let f = 0; f < 3; f++) {
      const finger = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.03, 0.09), skin);
      finger.position.set(-0.03 + f * 0.03, 0.03, -0.1);
      group.add(finger);
    }

    const thumb = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.06), skin);
    thumb.position.set(0.06, 0.01, -0.03);
    thumb.rotation.y = 0.5;
    group.add(thumb);

    const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.085, 0.16, 8), sleeve);
    cuff.rotation.x = Math.PI / 2;
    cuff.position.z = 0.13;
    group.add(cuff);

    group.position.set(x, y, z);
    return group;
  }

  initViewModels() {
    // 1. Magic Horn — spiral ridge rings, a base guard where the hand grips it, and a
    // bright glowing tip so it doesn't read as a single plain cone up close.
    const hornGroup = new THREE.Group();
    const hornMat = new THREE.MeshLambertMaterial({ color: 0xfeca57, emissive: 0xff9f43, emissiveIntensity: 0.4 });
    const hornMesh = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.7, 8), hornMat);
    hornMesh.rotation.x = Math.PI / 3;
    hornMesh.position.set(0.3, -0.3, -0.6);
    hornGroup.add(hornMesh);
    for (let i = 0; i < 4; i++) {
      const ridge = new THREE.Mesh(new THREE.TorusGeometry(0.12 - i * 0.022, 0.013, 6, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      ridge.rotation.x = Math.PI / 2;
      const t = i * 0.15;
      ridge.position.set(0.3 + Math.sin(Math.PI / 3) * t * 0, -0.3 + 0.1 + t * 0.55, -0.6 - t * 0.35);
      ridge.rotation.x = Math.PI / 3;
      hornGroup.add(ridge);
    }
    const hornGuard = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.08, 10), new THREE.MeshLambertMaterial({ color: 0xff9ff3 }));
    hornGuard.rotation.x = Math.PI / 3;
    hornGuard.position.set(0.3, -0.42, -0.42);
    hornGroup.add(hornGuard);
    const hornTip = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    hornTip.position.set(0.3 + Math.sin(Math.PI / 3) * 0.33, -0.3 + Math.cos(Math.PI / 3) * 0.33, -0.6 - 0.33 * 0.5);
    hornGroup.add(hornTip);
    hornGroup.add(this.createFPHand(0.28, -0.42, -0.35, false));
    this.viewmodels.push(hornGroup);

    // 2. Star Blaster — trigger guard, front sight, grip ridges & a muzzle cap.
    const pistolGroup = new THREE.Group();
    const pBodyMat = new THREE.MeshLambertMaterial({ color: 0xff6b8b });
    const pBody = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.22, 0.45), pBodyMat);
    const pBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.35, 10), new THREE.MeshLambertMaterial({ color: 0x48dbfb }));
    pBarrel.rotation.x = Math.PI / 2;
    pBarrel.position.set(0, 0.05, -0.3);
    const pMuzzle = new THREE.Mesh(new THREE.TorusGeometry(0.062, 0.018, 8, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    pMuzzle.position.set(0, 0.05, -0.47);
    const pSight = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.05, 0.03), new THREE.MeshLambertMaterial({ color: 0x222f3e }));
    pSight.position.set(0, 0.16, -0.45);
    const pGuard = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.015, 6, 12), new THREE.MeshLambertMaterial({ color: 0x222f3e }));
    pGuard.position.set(0, -0.14, 0.02);
    for (let i = 0; i < 3; i++) {
      const groove = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.015, 0.02), new THREE.MeshBasicMaterial({ color: 0xc44569 }));
      groove.position.set(0, -0.05 - i * 0.05, 0.12);
      pistolGroup.add(groove);
    }
    pistolGroup.add(pBody, pBarrel, pMuzzle, pSight, pGuard);
    pistolGroup.add(this.createFPHand(0, -0.18, 0.05, false));
    pistolGroup.position.set(0.32, -0.28, -0.5);
    this.viewmodels.push(pistolGroup);

    // 3. Sprinkle Super-Shotgun (SSG) — double-barrel, pump foregrip, angled stock, plus
    // a trigger guard, hinge pin, sight bead and buttplate for close-up detail.
    const ssgGroup = new THREE.Group();
    const ssgMat = new THREE.MeshLambertMaterial({ color: 0x9b59b6 });
    const ssgBarrelMat = new THREE.MeshLambertMaterial({ color: 0xfeca57 });
    const ssgReceiver = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.2, 0.28), ssgMat);
    ssgReceiver.position.z = -0.1;
    const b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.62, 10), ssgBarrelMat);
    const b2 = b1.clone();
    b1.rotation.x = Math.PI / 2;
    b2.rotation.x = Math.PI / 2;
    b1.position.set(-0.065, 0.04, -0.42);
    b2.position.set(0.065, 0.04, -0.42);
    const hinge = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.24, 8), new THREE.MeshLambertMaterial({ color: 0x2c1b47 }));
    hinge.rotation.z = Math.PI / 2;
    hinge.position.set(0, 0.04, -0.22);
    const sightBead = new THREE.Mesh(new THREE.SphereGeometry(0.018, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff4757 }));
    sightBead.position.set(0, 0.11, -0.72);
    const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.24, 10), ssgMat);
    pump.rotation.x = Math.PI / 2;
    pump.position.set(0, -0.02, -0.5);
    for (let i = 0; i < 5; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.092, 0.01, 6, 10), new THREE.MeshBasicMaterial({ color: 0x7d3c98 }));
      ring.rotation.x = Math.PI / 2;
      ring.position.set(0, -0.02, -0.59 + i * 0.045);
      ssgGroup.add(ring);
    }
    const trigGuard = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.013, 6, 10), new THREE.MeshLambertMaterial({ color: 0x2c1b47 }));
    trigGuard.position.set(0, -0.1, 0.0);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.22, 0.32), ssgMat);
    stock.position.set(0, -0.04, 0.28);
    stock.rotation.x = -0.15;
    const buttplate = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.23, 0.025), new THREE.MeshLambertMaterial({ color: 0x2c1b47 }));
    buttplate.position.set(0, -0.015, 0.44);
    buttplate.rotation.x = -0.15;
    ssgGroup.add(ssgReceiver, b1, b2, hinge, sightBead, pump, trigGuard, stock, buttplate);
    ssgGroup.add(this.createFPHand(0, -0.14, 0.1, false));  // trigger hand
    ssgGroup.add(this.createFPHand(0, -0.1, -0.48, true));   // support hand on the pump
    ssgGroup.position.set(0.35, -0.3, -0.55);
    this.viewmodels.push(ssgGroup);

    // 4. Bubble Chaingun — elongated body, underslung drum magazine & stock, plus a
    // vertical grip, top sight and barrel-shroud vents for a more automatic-rifle look.
    const chainGroup = new THREE.Group();
    const chainMat = new THREE.MeshLambertMaterial({ color: 0x00d2d3 });
    const cBody = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.18, 0.7), chainMat);
    cBody.position.z = -0.15;
    const cBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.35, 10), new THREE.MeshLambertMaterial({ color: 0xff9ff3 }));
    cBarrel.rotation.x = Math.PI / 2;
    cBarrel.position.z = -0.6;
    for (let i = 0; i < 3; i++) {
      const vent = new THREE.Mesh(new THREE.TorusGeometry(0.063, 0.012, 6, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      vent.rotation.x = Math.PI / 2;
      vent.position.set(0, 0, -0.46 - i * 0.07);
      chainGroup.add(vent);
    }
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.12, 14), new THREE.MeshLambertMaterial({ color: 0xfeca57 }));
    drum.position.set(0, -0.16, -0.1);
    const drumBand = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.012, 6, 14), new THREE.MeshBasicMaterial({ color: 0xff9f43 }));
    drumBand.rotation.x = Math.PI / 2;
    drumBand.position.set(0, -0.16, -0.1);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.2, 0.09), chainMat);
    grip.position.set(0, -0.18, 0.12);
    grip.rotation.x = 0.25;
    const topSight = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.06, 0.25), new THREE.MeshLambertMaterial({ color: 0x222f3e }));
    topSight.position.set(0, 0.12, -0.15);
    const cStock = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.16, 0.28), chainMat);
    cStock.position.set(0, -0.02, 0.32);
    chainGroup.add(cBody, cBarrel, drum, drumBand, grip, topSight, cStock);
    chainGroup.add(this.createFPHand(0, -0.12, 0.15, false));
    chainGroup.add(this.createFPHand(0, -0.12, -0.35, true));
    chainGroup.position.set(0.35, -0.32, -0.55);
    this.viewmodels.push(chainGroup);

    // 5. Cupcake Rocket Launcher — underslung grip, muzzle rim, rear cap & a candy-stripe
    // warning band so the tube doesn't read as a single plain cylinder.
    const rocketGroup = new THREE.Group();
    const rTubeMat = new THREE.MeshLambertMaterial({ color: 0xff9f43 });
    const rTube = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.8, 14), rTubeMat);
    rTube.rotation.x = Math.PI / 2;
    const rRing = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.04, 8, 16), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    rRing.position.z = -0.25;
    const rMuzzleRim = new THREE.Mesh(new THREE.TorusGeometry(0.165, 0.025, 8, 16), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    rMuzzleRim.position.z = -0.4;
    const rRearCap = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.08, 14), new THREE.MeshLambertMaterial({ color: 0xc0392b }));
    rRearCap.rotation.x = Math.PI / 2;
    rRearCap.position.z = 0.42;
    for (let i = 0; i < 6; i++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.012, 0.33), new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0xffffff : 0xff4757 }));
      const ang = (i / 6) * Math.PI * 2;
      stripe.position.set(Math.cos(ang) * 0.163, Math.sin(ang) * 0.163, 0.05);
      stripe.rotation.z = ang;
      rocketGroup.add(stripe);
    }
    const rGrip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.2, 0.1), rTubeMat);
    rGrip.position.set(0, -0.23, 0.15);
    rGrip.rotation.x = 0.2;
    rocketGroup.add(rTube, rRing, rMuzzleRim, rRearCap, rGrip);
    rocketGroup.add(this.createFPHand(0, -0.05, 0.1, false));
    rocketGroup.add(this.createFPHand(0, -0.2, -0.25, true));
    rocketGroup.position.set(0.38, -0.26, -0.6);
    this.viewmodels.push(rocketGroup);

    // 6. RAINBOW-9999 — side vents/fins, a grip, and extra glowing accent rings around
    // the core so it reads as a real weapon rather than a box with a ball in it.
    const bfgGroup = new THREE.Group();
    const bfgBodyMat = new THREE.MeshLambertMaterial({ color: 0x222f3e });
    const bfgBody = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.35, 0.7), bfgBodyMat);
    const bfgCore = new THREE.Mesh(new THREE.SphereGeometry(0.14, 14, 14), new THREE.MeshBasicMaterial({ color: 0xff9ff3 }));
    bfgCore.position.z = -0.15;
    const bfgRing = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 8, 16), new THREE.MeshBasicMaterial({ color: 0x48dbfb }));
    bfgRing.position.z = -0.38;
    const bfgRing2 = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.025, 8, 16), new THREE.MeshBasicMaterial({ color: 0xfeca57 }));
    bfgRing2.position.z = -0.08;
    bfgRing2.rotation.y = Math.PI / 6;
    [-1, 1].forEach(side => {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.22, 0.4), new THREE.MeshLambertMaterial({ color: 0x576574 }));
      fin.position.set(side * 0.19, 0.02, 0.0);
      bfgGroup.add(fin);
      const vent = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.15, 0.3), new THREE.MeshBasicMaterial({ color: 0x48dbfb }));
      vent.position.set(side * 0.21, 0.02, 0.0);
      bfgGroup.add(vent);
    });
    for (let i = 0; i < 3; i++) {
      const light = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 6), new THREE.MeshBasicMaterial({ color: [0xff6b8b, 0xfeca57, 0x1dd1a1][i] }));
      light.position.set(-0.08 + i * 0.08, 0.15, 0.2);
      bfgGroup.add(light);
    }
    const bfgGrip = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.2, 0.1), bfgBodyMat);
    bfgGrip.position.set(0, -0.22, 0.2);
    bfgGrip.rotation.x = 0.2;
    bfgGroup.add(bfgBody, bfgCore, bfgRing, bfgRing2, bfgGrip);
    bfgGroup.add(this.createFPHand(0.05, -0.16, 0.2, false));
    bfgGroup.add(this.createFPHand(-0.05, -0.16, -0.15, true));
    bfgGroup.position.set(0.36, -0.3, -0.65);
    this.viewmodels.push(bfgGroup);

    // Add all to holder and show current
    this.viewmodels.forEach(vm => this.viewmodelHolder.add(vm));
    this.updateViewModelVisibility();
    this.updateHUDWeaponRibbon();
  }

  updateViewModelVisibility(isFirstPerson = true) {
    this.viewmodelHolder.visible = isFirstPerson;
    this.viewmodels.forEach((vm, index) => {
      vm.visible = isFirstPerson && (index === this.currentWeaponIndex);
    });
  }

  getCurrentWeapon() {
    return this.weapons[this.currentWeaponIndex];
  }

  selectWeapon(index) {
    if (index >= 0 && index < this.weapons.length && this.weapons[index].unlocked) {
      this.currentWeaponIndex = index;
      this.updateViewModelVisibility(this.viewmodelHolder.visible);
      window.soundEngine.playTone(550 + index * 80, 0.08, 'sine', 0.2);
      this.updateHUDWeaponRibbon();
      return true;
    }
    return false;
  }

  unlockWeapon(index) {
    if (index >= 0 && index < this.weapons.length) {
      this.weapons[index].unlocked = true;
      this.selectWeapon(index);
      this.updateHUDWeaponRibbon();
    }
  }

  updateHUDWeaponRibbon() {
    const slots = document.querySelectorAll('.weapon-slot');
    slots.forEach((slot, idx) => {
      if (this.weapons[idx].unlocked) {
        slot.classList.add('unlocked');
      } else {
        slot.classList.remove('unlocked');
      }
      if (idx === this.currentWeaponIndex) {
        slot.classList.add('active');
      } else {
        slot.classList.remove('active');
      }
    });
  }

  // ==================== FIRING MECHANICS ====================
  fire(player, enemiesManager, mapManager) {
    const weapon = this.getCurrentWeapon();
    const now = performance.now() / 1000;

    if (now - this.lastFireTime < weapon.fireRate) return false;
    if (player.ammo < weapon.ammoCost) {
      window.soundEngine.playTone(150, 0.1, 'sawtooth', 0.2); // Click empty sound
      return false;
    }

    // Deduct ammo
    player.ammo -= weapon.ammoCost;
    this.lastFireTime = now;

    // Viewmodel recoil kick
    this.recoil.z = 0.15;
    this.recoil.y = 0.05;

    // Get shooting ray in camera aim direction
    const origin = new THREE.Vector3();
    this.camera.getWorldPosition(origin);
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);

    switch (weapon.type) {
      case 'melee':
        this.fireMelee(origin, dir, weapon, enemiesManager, mapManager);
        break;
      case 'projectile':
        this.fireBlaster(origin, dir, weapon);
        break;
      case 'shotgun':
        this.fireShotgun(origin, dir, weapon, mapManager);
        break;
      case 'rapid':
        this.fireChaingun(origin, dir, weapon);
        break;
      case 'rocket':
        this.fireRocket(origin, dir, weapon);
        break;
      case 'bfg':
        this.fireBFG(origin, dir, weapon);
        break;
    }

    return true;
  }

  // 1. Magic Horn Melee
  fireMelee(origin, dir, weapon, enemiesManager, mapManager) {
    window.soundEngine.playTone(700, 0.15, 'triangle', 0.4);
    this.particles.spawnConfettiBurst(origin.clone().addScaledVector(dir, 1.5), 8);

    // Hit check in cone
    enemiesManager.checkMeleeHit(origin, dir, 3.2, weapon.damage, 'melee');

    // Check destructible wall in melee range
    mapManager.checkWallHit(origin, dir, 3.0, 50);
  }

  // 2. Star Blaster
  fireBlaster(origin, dir, weapon) {
    window.soundEngine.playLaser(750, 0.12, 'sawtooth');

    const geom = new THREE.SphereGeometry(0.12, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color: 0xfeca57 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(origin).addScaledVector(dir, 0.8);
    this.scene.add(mesh);

    this.projectiles.push({
      mesh: mesh,
      dir: dir.clone(),
      speed: 48.0,
      damage: weapon.damage,
      life: 2.0,
      type: 'blaster',
      canBreakWalls: false
    });
  }

  // 3. Sprinkle Super-Shotgun (SSG)
  fireShotgun(origin, dir, weapon, mapManager) {
    window.soundEngine.playShotgun();

    // Spawn 10 spread pellets
    for (let i = 0; i < weapon.pellets; i++) {
      const spreadDir = dir.clone().add(new THREE.Vector3(
        (Math.random() - 0.5) * 0.16,
        (Math.random() - 0.5) * 0.16,
        (Math.random() - 0.5) * 0.16
      )).normalize();

      const geom = new THREE.CylinderGeometry(0.03, 0.03, 0.18, 5);
      const col = this.particles.sprinkleColors[i % this.particles.sprinkleColors.length];
      const mat = new THREE.MeshBasicMaterial({ color: col });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.copy(origin).addScaledVector(spreadDir, 0.6);
      this.scene.add(mesh);

      this.projectiles.push({
        mesh: mesh,
        dir: spreadDir,
        speed: 55.0,
        damage: weapon.damage,
        life: 0.8,
        type: 'sprinkle',
        canBreakWalls: true // SSG shatters fragile candy walls!
      });
    }

    // Heavy direct wall demolition check in close range
    mapManager.checkWallHit(origin, dir, 4.0, 100);
  }

  // 4. Bubble Chaingun
  fireChaingun(origin, dir, weapon) {
    window.soundEngine.playChaingun();

    const spreadDir = dir.clone().add(new THREE.Vector3(
      (Math.random() - 0.5) * 0.05,
      (Math.random() - 0.5) * 0.05,
      (Math.random() - 0.5) * 0.05
    )).normalize();

    const geom = new THREE.SphereGeometry(0.14, 8, 8);
    const isPink = Math.random() > 0.5;
    const mat = new THREE.MeshLambertMaterial({
      color: isPink ? 0xff6b8b : 0x00d2d3,
      emissive: isPink ? 0x9b59b6 : 0x00d2d3,
      emissiveIntensity: 0.5
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(origin).addScaledVector(spreadDir, 0.7);
    this.scene.add(mesh);

    this.projectiles.push({
      mesh: mesh,
      dir: spreadDir,
      speed: 60.0,
      damage: weapon.damage,
      life: 1.5,
      type: 'bubble',
      canBreakWalls: false
    });
  }

  // 5. Cupcake Rocket Launcher
  fireRocket(origin, dir, weapon) {
    window.soundEngine.playRocketFire();

    // 3D Cupcake Projectile
    const cupcakeGroup = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.14, 0.25, 8), new THREE.MeshLambertMaterial({ color: 0x5c2c16 }));
    const frosting = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    frosting.position.y = 0.15;
    cupcakeGroup.add(base, frosting);
    cupcakeGroup.position.copy(origin).addScaledVector(dir, 1.0);
    this.scene.add(cupcakeGroup);

    this.projectiles.push({
      mesh: cupcakeGroup,
      dir: dir.clone(),
      speed: 32.0,
      damage: weapon.damage,
      radius: weapon.radius,
      life: 4.0,
      type: 'rocket',
      canBreakWalls: true
    });
  }

  // 6. RAINBOW-9999 (BFG)
  fireBFG(origin, dir, weapon) {
    window.soundEngine.playBFG();

    const orbGeom = new THREE.SphereGeometry(0.65, 16, 16);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const orb = new THREE.Mesh(orbGeom, orbMat);
    orb.position.copy(origin).addScaledVector(dir, 1.2);
    this.scene.add(orb);

    this.projectiles.push({
      mesh: orb,
      dir: dir.clone(),
      speed: 18.0,
      damage: weapon.damage,
      radius: weapon.radius,
      life: 6.0,
      type: 'bfg',
      canBreakWalls: true,
      lastZapTime: 0
    });
  }

  // ==================== PROJECTILE UPDATES & COLLISION ====================
  update(delta, player, enemiesManager, mapManager) {
    // Viewmodel idle bobbing & recoil recovery — slow, gentle sway when standing still,
    // a touch more pronounced while walking, and every frame eased toward its target
    // instead of snapping straight to it. The old version oscillated at ~6-12Hz even at
    // rest, which read as a constant jittery tremor rather than a calm idle sway.
    if (this.viewmodelHolder.visible) {
      this.recoil.z = THREE.MathUtils.lerp(this.recoil.z, 0, delta * 12);
      this.recoil.y = THREE.MathUtils.lerp(this.recoil.y, 0, delta * 12);

      const speed = player.velocity ? player.velocity.length() : 0;
      const isMoving = speed > 0.5;
      this.bobTime = (this.bobTime || 0) + delta * (isMoving ? 3.2 : 0.9);
      const amp = isMoving ? 0.014 : 0.005;
      const bobX = Math.sin(this.bobTime) * amp;
      const bobY = Math.abs(Math.sin(this.bobTime * 2)) * amp * (isMoving ? 0.8 : 0.5);

      const targetX = bobX;
      const targetY = bobY - this.recoil.y;
      const targetZ = this.recoil.z;
      const ease = Math.min(1, delta * 9);
      this.viewmodelHolder.position.x = THREE.MathUtils.lerp(this.viewmodelHolder.position.x, targetX, ease);
      this.viewmodelHolder.position.y = THREE.MathUtils.lerp(this.viewmodelHolder.position.y, targetY, ease);
      this.viewmodelHolder.position.z = THREE.MathUtils.lerp(this.viewmodelHolder.position.z, targetZ, ease);
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= delta;

      if (p.life <= 0) {
        this.destroyProjectile(i);
        continue;
      }

      // Move projectile forward
      const prevPos = p.mesh.position.clone();
      p.mesh.position.addScaledVector(p.dir, p.speed * delta);

      // Visual spin for rockets and bubbles
      if (p.type === 'rocket' || p.type === 'sprinkle') {
        p.mesh.rotation.x += 10.0 * delta;
        p.mesh.rotation.y += 8.0 * delta;
      }

      // BFG zap tendrils to all visible enemies along path
      if (p.type === 'bfg') {
        const nowSec = performance.now() / 1000;
        if (nowSec - p.lastZapTime > 0.15) {
          p.lastZapTime = nowSec;
          enemiesManager.zapNearbyEnemies(p.mesh.position, 12.0, 45, 'bfg');
          this.particles.spawnConfettiBurst(p.mesh.position, 6);
        }
      }

      // 1. Collision check against Enemies
      const hitEnemy = enemiesManager.checkProjectileHit(prevPos, p.mesh.position, p.damage, p.type);
      if (hitEnemy) {
        this.handleProjectileImpact(p, p.mesh.position, enemiesManager, mapManager);
        this.destroyProjectile(i);
        continue;
      }

      // 2. Collision check against Destructible Walls & Map Colliders
      const wallHit = mapManager.checkProjectileCollision(prevPos, p.mesh.position, p.damage, p.canBreakWalls);
      if (wallHit.hit) {
        this.handleProjectileImpact(p, wallHit.point, enemiesManager, mapManager, wallHit.normal);
        this.destroyProjectile(i);
        continue;
      }
    }
  }

  handleProjectileImpact(projectile, hitPoint, enemiesManager, mapManager, normal = new THREE.Vector3(0, 1, 0)) {
    if (projectile.type === 'blaster') {
      this.particles.spawnHitSparks(hitPoint, normal, 0xfeca57);
      window.soundEngine.playTone(350, 0.05, 'triangle', 0.2);
    } else if (projectile.type === 'sprinkle') {
      this.particles.spawnHitSparks(hitPoint, normal, 0xff6b8b);
    } else if (projectile.type === 'bubble') {
      this.particles.spawnHitSparks(hitPoint, normal, 0x00d2d3);
      window.soundEngine.playTone(200, 0.08, 'sine', 0.25);
    } else if (projectile.type === 'rocket') {
      window.soundEngine.playExplosion();
      this.particles.spawnExplosion(hitPoint, projectile.radius);
      enemiesManager.dealSplashDamage(hitPoint, projectile.radius, projectile.damage, 'rocket');
      mapManager.breakNearbyWalls(hitPoint, projectile.radius);
    } else if (projectile.type === 'bfg') {
      window.soundEngine.playExplosion();
      this.particles.spawnExplosion(hitPoint, projectile.radius);
      this.particles.spawnEnemyDefeat(hitPoint); // Massive chocolate & sprinkle cataclysm
      enemiesManager.dealSplashDamage(hitPoint, projectile.radius, projectile.damage, 'bfg');
      mapManager.breakNearbyWalls(hitPoint, projectile.radius * 1.2);
    }
  }

  destroyProjectile(index) {
    const p = this.projectiles[index];
    this.scene.remove(p.mesh);
    if (p.mesh.geometry) p.mesh.geometry.dispose();
    if (p.mesh.material) p.mesh.material.dispose();
    this.projectiles.splice(index, 1);
  }

  clearAll() {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      this.destroyProjectile(i);
    }
    // Reset weapon unlocks back to their starting state. Chifre/Pistola/Espingarda/
    // Metralhadora are always available; Lança-Cupcake and RAINBOW-9999 must be found again —
    // this reset was missing entirely, so once found they stayed unlocked forever even
    // after dying, while their ground pickups respawned fresh (inconsistent with everything else).
    this.weapons.forEach((w, i) => {
      w.unlocked = i < 4;
    });
    this.selectWeapon(1);
    this.updateHUDWeaponRibbon();
  }
}
