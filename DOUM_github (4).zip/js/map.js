// DOUM - 3D Level Architecture, Props, Keys, Doors, Destructible Walls & Secrets
// Theme: "O Santuário de Algodão-Doce e Arco-Íris"

class MapManager {
  constructor(scene, particleSystem) {
    this.scene = scene;
    this.particles = particleSystem;

    this.colliders = []; // Static obstacle bounding boxes
    this.destructibleWalls = []; // Walls that can be broken
    this.doors = []; // Key-locked or switch-activated doors
    this.switches = []; // Interactive buttons
    this.elevators = []; // Moving platforms
    this.teleporters = []; // Teleport pads
    this.pickups = []; // Health, Armor, Ammo, Keys, Weapons
    this.exitPortals = []; // Level goals / teleporters

    // Map exploration tracking
    this.visitedSectors = new Set();
    this.totalSectors = 6; // Courtyard, Donut Hall, Inverted Vault, Secret Armory, Rainbow Chasm, Boss Arena
    this.secretsTotal = 3;
    this.secretsFound = 0;
    this.itemsTotal = 0;
    this.itemsCollected = 0;

    this.buildMap();
  }

  buildMap() {
    this.createSkyAndAtmosphere();
    this.createCourtyard();
    this.createDonutHall();
    this.createInvertedGravityVault();
    this.createSecretArmoryAndLabyrinth();
    this.createRainbowBridgeChasm();
    this.createBossSanctuary();
    this.createFrozenCrystalTower();
    this.createAuroraBridge();
    this.spawnPickupsAndKeys();
  }

  // ==================== SKY, LIGHTING & AMBIENCE ====================
  createSkyAndAtmosphere() {
    // Soft pastel starry fog & background
    this.scene.background = new THREE.Color(0x1a0f2e);
    this.scene.fog = new THREE.FogExp2(0x1a0f2e, 0.012);

    // Cheerful vibrant lighting
    const hemiLight = new THREE.HemisphereLight(0xffb8d2, 0x48dbfb, 0.7);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xfff1cf, 0.9);
    dirLight.position.set(30, 50, 20);
    this.scene.add(dirLight);

    // Decorative floating giant rainbow arch across the sky
    const rainbowArch = this.createRainbowArch(new THREE.Vector3(0, 0, 0), 45, 1.2);
    this.scene.add(rainbowArch);
  }

  createRainbowArch(center, radius, width) {
    const group = new THREE.Group();
    const colors = [0xff6b8b, 0xff9f43, 0xfeca57, 0x1dd1a1, 0x48dbfb, 0x9b59b6];
    
    colors.forEach((col, idx) => {
      const r = radius + idx * width;
      const geom = new THREE.TorusGeometry(r, width * 0.45, 8, 32, Math.PI);
      const mat = new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.rotation.z = Math.PI;
      group.add(mesh);
    });

    group.position.copy(center);
    return group;
  }

  // ==================== AREA 1: COURTYARD / PÁTIO INICIAL ====================
  createCourtyard() {
    // Checkered candy floor
    const floorMat = new THREE.MeshLambertMaterial({ color: 0x3d1b54 });
    const floor = new THREE.Mesh(new THREE.BoxGeometry(36, 1, 36), floorMat);
    floor.position.set(0, -0.5, 0);
    this.scene.add(floor);

    // Ornate Center Carpet
    const carpet = new THREE.Mesh(new THREE.BoxGeometry(16, 0.05, 16), new THREE.MeshLambertMaterial({ color: 0x54236e }));
    carpet.position.set(0, 0.02, 0);
    this.scene.add(carpet);

    // Outer boundary walls with glowing neon trim
    this.addWall(0, 4, -18, 36, 8, 1, 0x54236e); // North
    // West wall split in two so it doesn't swallow the Secret 2 destructible gap (z:[7,13])
    this.addWall(-18, 4, -5.5, 1, 8, 25, 0x54236e); // West (north segment) z:[-18,7]
    this.addWall(-18, 4, 15.5, 1, 8, 5, 0x54236e);  // West (south segment) z:[13,18]
    this.addWall(18, 4, 0, 1, 8, 36, 0x54236e);  // East
    this.addWall(-10, 4, 18, 16, 8, 1, 0x54236e); // South Left
    this.addWall(10, 4, 18, 16, 8, 1, 0x54236e);  // South Right

    // Corridor walls sealing the flanks between Courtyard and Donut Hall (z:[18,22])
    this.addWall(-11, 5, 20, 18, 10, 4, 0x4a1d63);
    this.addWall(11, 5, 20, 18, 10, 4, 0x4a1d63);
    // Corridor CEILING (was missing — this is the "hole in the sky" bug!)
    this.createCeiling(0, 10.5, 20, 40, 1, 4, 0x351a52);
    // Corridor FLOOR (was also missing — visible gap between the two rooms' floors!)
    const corridorFloor1 = new THREE.Mesh(new THREE.BoxGeometry(40, 1, 4), new THREE.MeshLambertMaterial({ color: 0x2e1442 }));
    corridorFloor1.position.set(0, -0.5, 20);
    this.scene.add(corridorFloor1);

    // SOLID ROOF / CEILING WITH CHANDELIERS (Walkable with Gravity Boots!)
    this.createCeiling(0, 8.5, 0, 36, 1, 36, 0x2e1442, [
      [-8, 8.2, -8], [8, 8.2, -8], [-8, 8.2, 8], [8, 8.2, 8]
    ]);

    // Candy Cane Spiral Columns at corners supporting the ceiling
    this.createCandyCanePillar(-16, 0, -16, 8);
    this.createCandyCanePillar(16, 0, -16, 8);
    this.createCandyCanePillar(-16, 0, 16, 8);
    this.createCandyCanePillar(16, 0, 16, 8);

    // Wall Torches / Sconces with glowing star crystals
    this.createWallTorch(-17.3, 3.5, 0, new THREE.Vector3(1, 0, 0), 0xff6b8b);
    this.createWallTorch(17.3, 3.5, 0, new THREE.Vector3(-1, 0, 0), 0x48dbfb);
    this.createWallTorch(0, 3.5, -17.3, new THREE.Vector3(0, 0, 1), 0xfeca57);

    // Whimsical Lollipop trees
    this.createLollipopTree(-12, 0, -12, 0xff6b8b);
    this.createLollipopTree(12, 0, -12, 0x48dbfb);
    this.createLollipopTree(-12, 0, 10, 0x1dd1a1);
    this.createLollipopTree(12, 0, 10, 0xfeca57);

    // Decorative sparkling candy fountain in center
    const fountainBase = new THREE.Mesh(new THREE.CylinderGeometry(3, 3.5, 0.8, 16), new THREE.MeshLambertMaterial({ color: 0xff9ff3 }));
    fountainBase.position.set(0, 0.4, 0);
    this.scene.add(fountainBase);
    this.addCollider(new THREE.Box3().setFromObject(fountainBase));

    const water = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 0.2, 16), new THREE.MeshBasicMaterial({ color: 0x48dbfb }));
    water.position.set(0, 0.85, 0);
    this.scene.add(water);

    // Passage South Door leading to Donut Hall
    this.createDoor(0, 2.5, 18, 4, 5, 1, 0xff6b8b, null, "Porta do Pátio", 'courtyard');
    // Header above the door up to the wall's full height (8) — otherwise gravity boots let you
    // walk along the ceiling and drop through the open space above the door.
    this.addWall(0, 6.5, 18, 4, 3, 1, 0x54236e);
  }

  createLollipopTree(x, y, z, color) {
    const group = new THREE.Group();
    // Stick
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 4, 8), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    stick.position.y = 2;
    // Candy Spiral Head
    const head = new THREE.Mesh(new THREE.TorusGeometry(1.2, 0.5, 12, 24), new THREE.MeshLambertMaterial({ color: color }));
    head.position.y = 4.2;
    head.rotation.x = Math.PI / 2;
    group.add(stick, head);
    group.position.set(x, y, z);
    this.scene.add(group);

    this.addCollider(new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(x, y + 2, z), new THREE.Vector3(1, 4, 1)));
  }

  // ==================== AREA 2: DONUT HALL (SALÃO DAS ROSQUINHAS) ====================
  createDonutHall() {
    // Floor
    const floor = new THREE.Mesh(new THREE.BoxGeometry(40, 1, 40), new THREE.MeshLambertMaterial({ color: 0x2b1040 }));
    floor.position.set(0, -0.5, 42);
    this.scene.add(floor);

    // Walls
    // West wall split in two so it doesn't swallow the Secret 1 destructible gap (z:[39,45])
    this.addWall(-20, 5, 30.5, 1, 10, 17, 0x682282); // West (north segment) z:[22,39]
    this.addWall(-20, 5, 53.5, 1, 10, 17, 0x682282); // West (south segment) z:[45,62]
    this.addWall(20, 5, 42, 1, 10, 40, 0x682282);  // East
    // South walls now aligned exactly to the Rainbow Door opening (x:[-2,2]) - no more open slivers!
    this.addWall(-11, 5, 62, 18, 10, 1, 0x682282); // South Left  x:[-20,-2]
    this.addWall(11, 5, 62, 18, 10, 1, 0x682282);  // South Right x:[2,20]

    // Corridor walls sealing the flanks between Donut Hall and Inverted Gravity Vault (z:[62,64])
    this.addWall(-11, 6, 63, 18, 12, 2, 0x30144a);
    this.addWall(11, 6, 63, 18, 12, 2, 0x30144a);
    // Corridor CEILING (was missing — this is the "hole in the sky" bug!)
    this.createCeiling(0, 12.5, 63, 40, 1, 2, 0x2a1245);
    // Corridor FLOOR (was also missing — visible gap between the two rooms' floors!)
    const corridorFloor2 = new THREE.Mesh(new THREE.BoxGeometry(40, 1, 2), new THREE.MeshLambertMaterial({ color: 0x240e3b }));
    corridorFloor2.position.set(0, -0.5, 63);
    this.scene.add(corridorFloor2);

    // SOLID ROOF / CEILING WITH CHANDELIERS & BEAMS (Walkable with Gravity Boots!)
    this.createCeiling(0, 10.5, 42, 40, 1, 40, 0x240e3b, [
      [-10, 10.2, 32], [10, 10.2, 32], [-10, 10.2, 52], [10, 10.2, 52]
    ]);

    // Candy Cane Pillars along the hall
    this.createCandyCanePillar(-18, 0, 30, 10);
    this.createCandyCanePillar(18, 0, 30, 10);
    this.createCandyCanePillar(-18, 0, 54, 10);
    this.createCandyCanePillar(18, 0, 54, 10);

    // Wall sconces with star lights
    this.createWallTorch(-19.3, 4.0, 42, new THREE.Vector3(1, 0, 0), 0xfeca57);
    this.createWallTorch(19.3, 4.0, 42, new THREE.Vector3(-1, 0, 0), 0xff9ff3);

    // Upper Catwalk Platforms
    const catwalk = new THREE.Mesh(new THREE.BoxGeometry(36, 0.8, 6), new THREE.MeshLambertMaterial({ color: 0xfeca57 }));
    catwalk.position.set(0, 4.5, 54);
    this.scene.add(catwalk);
    this.addCollider(new THREE.Box3().setFromObject(catwalk));

    // Elevator platform connecting floor to catwalk
    this.createElevator(new THREE.Vector3(-14, 0.2, 54), new THREE.Vector3(4, 0.5, 4), 0.2, 4.5, 0x1dd1a1);

    // Large Donut Arch in center
    const donut = new THREE.Mesh(new THREE.TorusGeometry(3.5, 1.2, 12, 24), new THREE.MeshLambertMaterial({ color: 0xff9f43 }));
    donut.position.set(0, 4.5, 38);
    this.scene.add(donut);

    // Locked RAINBOW DOOR leading to Inverted Gravity Vault
    this.createDoor(0, 2.5, 62, 4, 5, 1, 0xff9ff3, 'rainbow', "Porta Arco-Íris", 'donutHall');
    // Header above the door up to the wall's full height (10)
    this.addWall(0, 7.5, 62, 4, 5, 1, 0x682282);
  }

  // ==================== AREA 3: THE INVERTED GRAVITY VAULT ====================
  // Designed specifically for the GRAVITY BOOTS mechanic!
  // Features a ceiling floor, ceiling platforms, and an upside-down switch!
  createInvertedGravityVault() {
    // Room dimensions: x: [-20, 20], z: [64, 104], height: 14 units
    // Normal Floor
    const floor = new THREE.Mesh(new THREE.BoxGeometry(40, 1, 40), new THREE.MeshLambertMaterial({ color: 0x190d2e }));
    floor.position.set(0, -0.5, 84);
    this.scene.add(floor);

    // CEILING FLOOR (Walkable with Gravity Boots!)
    const ceiling = new THREE.Mesh(new THREE.BoxGeometry(40, 1, 40), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    ceiling.position.set(0, 14.5, 84);
    this.scene.add(ceiling);
    this.addCollider(new THREE.Box3().setFromObject(ceiling)); // Solid ceiling collider

    // Boundary walls
    // West wall split so it doesn't swallow the Secret 3 destructible gap (z:[81,87])
    this.addWall(-20, 7, 72.5, 1, 14, 17, 0x411863); // West (north segment) z:[64,81]
    this.addWall(-20, 7, 95.5, 1, 14, 17, 0x411863); // West (south segment) z:[87,104]
    // East wall split so it doesn't permanently seal the Star Door (z:[82,86])
    this.addWall(20, 7, 73, 1, 14, 18, 0x411863);   // East (north segment) z:[64,82]
    this.addWall(20, 7, 95, 1, 14, 18, 0x411863);   // East (south segment) z:[86,104]
    this.addWall(0, 7, 104, 40, 14, 1, 0x411863);  // South Wall

    // Massive connecting pillars extending from floor to ceiling
    this.createPillar(-10, 84, 14);
    this.createPillar(10, 84, 14);

    // INVERTED CEILING PLATFORMS & CEILING SWITCH
    // Lowered from the original y:12 — there wasn't enough vertical clearance between the
    // platform top and the real ceiling (y:14) to fit the player's full height, so anyone
    // teleported up here got stuck clipping into the ceiling.
    const ceilPlat = new THREE.Mesh(new THREE.BoxGeometry(10, 0.6, 10), new THREE.MeshLambertMaterial({ color: 0xfeca57 }));
    ceilPlat.position.set(0, 10.3, 84);
    this.scene.add(ceilPlat);
    this.addCollider(new THREE.Box3().setFromObject(ceilPlat));

    // Interactive Switch on the Ceiling! (Requires using Gravity Boots to reach)
    this.createSwitch(new THREE.Vector3(0, 12.5, 84), new THREE.Vector3(0, -1, 0), "Abrir Porta Estelar", () => {
      window.soundEngine.playSecretFound();
      window.game.showMessage("🌟 Mecanismo Gravitacional Ativado! A Porta Estelar se abriu!");
      const starDoor = this.doors.find(d => d.keyRequired === 'star');
      if (starDoor) starDoor.open();
    });

    // Teleporter pad on the ground that helps players reach the ceiling quickly — destination
    // now sits comfortably above the (lowered) platform with clear headroom below the ceiling.
    this.createTeleporter(new THREE.Vector3(14, 0.2, 90), new THREE.Vector3(0, 11.8, 84), 0x00d2d3);

    // Locked STAR DOOR leading to Rainbow Bridge
    this.createDoor(20, 2.5, 84, 1, 5, 4, 0xfeca57, 'star', "Porta Estelar", 'vault');
    // Header above the door up to the wall's full height (14)
    this.addWall(20, 9.5, 84, 1, 9, 4, 0x411863);
  }

  createPillar(x, z, height) {
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, height, 12), new THREE.MeshLambertMaterial({ color: 0x9b59b6 }));
    pillar.position.set(x, height / 2, z);
    this.scene.add(pillar);
    this.addCollider(new THREE.Box3().setFromObject(pillar));
  }

  // ==================== AREA 4: SECRET ARMORY & DESTRUCTIBLE WALLS ====================
  createSecretArmoryAndLabyrinth() {
    // Secret Room located West of Donut Hall: x: [-38, -20], z: [30, 54]
    const secretFloor = new THREE.Mesh(new THREE.BoxGeometry(18, 1, 24), new THREE.MeshLambertMaterial({ color: 0x110820 }));
    secretFloor.position.set(-29, -0.5, 42);
    this.scene.add(secretFloor);

    // Secret Room Outer Walls
    this.addWall(-38, 5, 42, 1, 10, 24, 0x381248);
    this.addWall(-29, 5, 30, 18, 10, 1, 0x381248);
    this.addWall(-29, 5, 54, 18, 10, 1, 0x381248);

    // SOLID ROOF OVER SECRET ARMORY (Walkable with Gravity Boots!)
    this.createCeiling(-29, 10.5, 42, 18, 1, 24, 0x1f0b33, [[-29, 10.2, 42]]);

    // DESTRUCTIBLE WALL 1 (Hides Secret 1: Armory with BFG RAINBOW-9999!)
    this.createDestructibleWall(
      new THREE.Vector3(-20, 3, 42),
      new THREE.Vector3(1, 6, 6),
      "Secret 1: Santuário Bélico Secreto"
    );

    // DESTRUCTIBLE WALL 2 (Now leads to a real secret room in the Courtyard — the very
    // first area — holding the Gravity Boots pickup, as requested!)
    this.createDestructibleWall(
      new THREE.Vector3(-18, 3, 10),
      new THREE.Vector3(1, 6, 6),
      "Secret 2: Câmara das Botas Celestes"
    );

    // Fully-enclosed secret room behind Secret 2: x:[-30,-18], z:[4,16]
    const bootsRoomFloor = new THREE.Mesh(new THREE.BoxGeometry(12, 1, 12), new THREE.MeshLambertMaterial({ color: 0x2a1245 }));
    bootsRoomFloor.position.set(-24, -0.5, 10);
    this.scene.add(bootsRoomFloor);

    this.addWall(-30, 4, 10, 1, 8, 12, 0x4a1d63); // West
    this.addWall(-24, 4, 4, 12, 8, 1, 0x4a1d63);  // North
    this.addWall(-24, 4, 16, 12, 8, 1, 0x4a1d63); // South
    this.createCeiling(-24, 8.5, 10, 12, 1, 12, 0x2e1442, [[-24, 8.2, 10]]);
    // Gravity Boots pickup itself is spawned from spawnPickupsAndKeys() below, so it
    // correctly respawns on every resetProgress() call too (e.g. after the player dies).

    // DESTRUCTIBLE WALL 3 (Hidden alcove in Inverted Vault with Mega-Cake, Shields & Gravity Boots!)
    // Fully-enclosed alcove: x:[-32,-20], z:[78,90] — only entrance is the destructible wall below.
    const alcoveFloor = new THREE.Mesh(new THREE.BoxGeometry(12, 1, 12), new THREE.MeshLambertMaterial({ color: 0x110820 }));
    alcoveFloor.position.set(-26, -0.5, 84);
    this.scene.add(alcoveFloor);

    this.addWall(-32, 4, 84, 1, 8, 12, 0x381248); // West
    this.addWall(-26, 4, 78, 12, 8, 1, 0x381248); // North
    this.addWall(-26, 4, 90, 12, 8, 1, 0x381248); // South
    this.createCeiling(-26, 8.5, 84, 12, 1, 12, 0x1f0b33, [[-26, 8.2, 84]]);
    this.createDestructibleWall(
      new THREE.Vector3(-20, 3, 84),
      new THREE.Vector3(1, 6, 6),
      "Secret 3: Tesouro das Botas Celestes"
    );
  }

  createDestructibleWall(pos, size, secretName) {
    // Candy crystal block with cracked pattern
    const wallGeom = new THREE.BoxGeometry(size.x, size.y, size.z);
    const wallMat = new THREE.MeshLambertMaterial({
      color: 0xff9ff3,
      emissive: 0x54a0ff,
      emissiveIntensity: 0.35
    });
    const mesh = new THREE.Mesh(wallGeom, wallMat);
    mesh.position.copy(pos);
    this.scene.add(mesh);

    // Glowing cracked neon borders to clearly signal breakability to player!
    const edges = new THREE.EdgesGeometry(wallGeom);
    const lineMat = new THREE.LineBasicMaterial({ color: 0xfeca57, linewidth: 2 });
    const wire = new THREE.LineSegments(edges, lineMat);
    mesh.add(wire);

    const colliderBox = new THREE.Box3().setFromObject(mesh);
    this.addCollider(colliderBox);

    const destrObj = {
      mesh: mesh,
      collider: colliderBox,
      health: 80,
      maxHealth: 80,
      size: size,
      secretName: secretName,
      destroyed: false
    };

    this.destructibleWalls.push(destrObj);
    return destrObj;
  }

  // ==================== AREA 5: RAINBOW BRIDGE CHASM ====================
  createRainbowBridgeChasm() {
    // East side beyond Star Door: x: [20, 70], z: [74, 94]
    // Bridge now sits at normal floor level (top surface at y:0, same as every other room)
    // instead of floating 2.5 units up — that mismatch was the "ponte muito alta" bug.
    const bridgeGeom = new THREE.BoxGeometry(36, 0.6, 6);
    const bridgeMat = new THREE.MeshLambertMaterial({
      color: 0x48dbfb,
      transparent: true,
      opacity: 0.85
    });
    const bridge = new THREE.Mesh(bridgeGeom, bridgeMat);
    bridge.position.set(40, -0.3, 84);
    this.scene.add(bridge);
    // No collider on the bridge slab: its top sits at exactly y:0, the same height as the
    // player's feet on the ground, and that "touching" overlap was treated as a wall —
    // blocking you from walking onto the bridge / reaching the Porta Rosquinha. The ground
    // plane already supports the player here and the side barriers keep you from falling off.

    // OVERHEAD RAINBOW CRYSTAL CANOPY (decorative, matches the bridge width exactly)
    this.createRainbowCanopy(40, 8, 84, 36, 6);

    // FULL CEILING + SIDE WALLS enclosing the whole chasm room (was open sky/void before —
    // you could walk off the sides of the bridge into empty space with nothing around you).
    // Extended all the way to x:74 (matching the Boss Arena entrance corridor exactly) so
    // there's no unwalled gap at the seam between the two — that was the "buraco do lado
    // da ponte" bug. Room footprint: x:[18,74], z:[76,92], height up to y:12.
    this.createCeiling(46, 12.5, 84, 56, 1, 16, 0x1a0d2e);
    this.addWall(46, 6, 76, 56, 12, 1, 0x2a1245); // North wall
    this.addWall(46, 6, 92, 56, 12, 1, 0x2a1245); // South wall

    // Rainbow rails (visible rail + real invisible force-field colliders so you can't fall
    // off the immediate bridge edges before reaching the outer walls above)
    [-2.8, 2.8].forEach(offsetZ => {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 36, 8), new THREE.MeshBasicMaterial({ color: 0xff6b8b }));
      rail.rotation.z = Math.PI / 2;
      rail.position.set(40, 0.9, 84 + offsetZ);
      this.scene.add(rail);
      this.addInvisibleBarrier(40, 2, 84 + offsetZ, 36, 8, 0.4);
    });

    // Cotton candy clouds below (purely decorative, inside the now-enclosed room)
    for (let c = 0; c < 8; c++) {
      const cloud = new THREE.Mesh(new THREE.SphereGeometry(4 + Math.random() * 3, 8, 8), new THREE.MeshLambertMaterial({ color: 0xff9ff3, transparent: true, opacity: 0.7 }));
      cloud.position.set(25 + c * 5, -4, 84 + (Math.random() - 0.5) * 10);
      this.scene.add(cloud);
    }

    // Locked DONUT DOOR leading to Final Arena
    this.createDoor(60, 3, 84, 1, 6, 6, 0xff9f43, 'donut', "Porta Rosquinha", 'bridge');
    // Header above the door up to the wall's full height (12)
    this.addWall(60, 9, 84, 1, 6, 6, 0x2a1245);
  }

  // ==================== AREA 6: BOSS / GUARDIAN ARENA & EXIT PORTAL ====================
  createBossSanctuary() {
    // Large circular/octagonal arena: center at (85, 0, 84), radius 22
    const arenaFloor = new THREE.Mesh(new THREE.CylinderGeometry(24, 24, 1, 24), new THREE.MeshLambertMaterial({ color: 0x3d1b54 }));
    arenaFloor.position.set(88, -0.5, 84);
    this.scene.add(arenaFloor);

    // GRAND CELESTIAL DOME ROOF OVER BOSS ARENA
    this.createDomeCeiling(88, 13.5, 84, 24);

    // Arena pillars — index 4 (due west, angle 180°) is skipped: that's exactly where the
    // Donut Door connects from the Rainbow Bridge, so a real corridor goes there instead
    // (see below) rather than a pillar blocking the only way in.
    const ENTRANCE_INDEX = 4;
    const pillarPositions = [];
    for (let a = 0; a < 8; a++) {
      const ang = (a / 8) * Math.PI * 2;
      const px = 88 + Math.cos(ang) * 20;
      const pz = 84 + Math.sin(ang) * 20;
      pillarPositions.push({ x: px, z: pz });
      if (a !== ENTRANCE_INDEX) {
        this.createPillar(px, pz, 12);
      }
    }

    // Octagonal wall connecting every OTHER pillar pair (was completely open before — you
    // could just walk out between any two pillars into the empty void beyond the dome!).
    // The two segments touching the entrance pillar are skipped here and replaced by the
    // straight entrance wall + corridor below.
    for (let a = 0; a < pillarPositions.length; a++) {
      if (a === ENTRANCE_INDEX || a === (ENTRANCE_INDEX - 1 + 8) % 8) continue;
      const p1 = pillarPositions[a];
      const p2 = pillarPositions[(a + 1) % pillarPositions.length];
      const dx = p2.x - p1.x;
      const dz = p2.z - p1.z;
      const segLen = Math.sqrt(dx * dx + dz * dz);
      const midX = (p1.x + p2.x) / 2;
      const midZ = (p1.z + p2.z) / 2;
      const angle = Math.atan2(-dz, dx);
      this.addAngledWall(midX, 6, midZ, segLen, 12, 1, angle, 0x3d1b54);
    }

    // Straight entrance wall (pillars 3 & 5 share the same x=~74) with an 8-unit gap in the
    // middle — this is the real doorway the Donut Door corridor connects into.
    this.addWall(74, 6, 93, 1, 12, 10, 0x3d1b54); // above the gap
    this.addWall(74, 6, 75, 1, 12, 10, 0x3d1b54); // below the gap

    // Corridor connecting the Donut Door (x:60) to the arena entrance (x:74) — the outer
    // walls/ceiling above already fully enclose this stretch (see createRainbowBridgeChasm).

    // Jump pads in arena corners
    this.createJumpPad(new THREE.Vector3(78, 1.2, 74));
    this.createJumpPad(new THREE.Vector3(78, 1.2, 94));

    // Golden Exit Portal — now teleports into the new Frozen Crystal Tower phase!
    this.createExitPortal(new THREE.Vector3(96, 2.0, 84), new THREE.Vector3(140, 0.95, 84));
  }

  createJumpPad(pos) {
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.8, 0.3, 12), new THREE.MeshLambertMaterial({ color: 0x1dd1a1, emissive: 0x10ac84, emissiveIntensity: 0.6 }));
    pad.position.copy(pos);
    this.scene.add(pad);
    this.addCollider(new THREE.Box3().setFromObject(pad));

    // Jump pad trigger
    pad.userData = { isJumpPad: true, boostY: 18 };
  }

  createExitPortal(pos, teleportTo = null) {
    const group = new THREE.Group();

    // Pedestal
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 3.0, 1.0, 16), new THREE.MeshLambertMaterial({ color: 0xfeca57 }));
    base.position.y = 0.5;

    // Glowing Rainbow Portal Vortex
    const vortex = new THREE.Mesh(new THREE.TorusGeometry(1.8, 0.25, 12, 24), new THREE.MeshBasicMaterial({ color: 0xff9ff3 }));
    vortex.position.y = 2.8;

    // Golden Unicorn Horn Trophy
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.8, 8), new THREE.MeshLambertMaterial({ color: 0xffd700, emissive: 0xffaa00, emissiveIntensity: 0.8 }));
    horn.position.y = 2.8;

    group.add(base, vortex, horn);
    group.position.copy(pos);
    this.scene.add(group);

    this.exitPortals.push({
      group: group,
      vortex: vortex,
      horn: horn,
      position: pos.clone().add(new THREE.Vector3(0, 1.5, 0)),
      radius: 2.5,
      teleportTo: teleportTo, // Vector3 -> teleports instead of ending the game; null -> real victory
      cooldown: 0
    });
  }

  // ==================== AREA 7: FROZEN CRYSTAL TOWER (Bonus Phase!) ====================
  // Reached via the Boss Arena's portal. Same design language as the rest of the game —
  // three connected rooms with real doors between them, tougher enemies (+20% HP), its
  // own pickups, and a portal onward to the Aurora Bridge (Area 8).
  //
  // Whole footprint is x:[120,260], z:[64,104] — ONE continuous North wall, South wall,
  // floor and ceiling the entire way (the lesson from the seam bug earlier this session:
  // stitching separate per-room pieces at slightly different extents leaves gaps). The
  // three rooms are formed purely by internal divider walls at x:155 and x:225, each
  // split around an 8-unit door gap.
  createFrozenCrystalTower() {
    const iceWall = 0x4a90c2;
    const iceCrystal = 0xaeeeff;
    const caveDark = 0x0a1c2c;

    // Floor & Ceiling — one continuous slab across all 3 rooms
    const floor = new THREE.Mesh(new THREE.BoxGeometry(140, 1, 40), new THREE.MeshLambertMaterial({ color: 0x1a3a52 }));
    floor.position.set(190, -0.5, 84);
    this.scene.add(floor);
    this.createCeiling(190, 12.5, 84, 140, 1, 40, caveDark, [[138, 12.2, 84], [190, 12.2, 84], [242, 12.2, 84]]);

    // Outer boundary: continuous North & South walls, dead-end West & East walls
    this.addWall(190, 6, 64, 140, 12, 1, iceWall);  // North
    this.addWall(190, 6, 104, 140, 12, 1, iceWall); // South
    this.addWall(120, 6, 84, 1, 12, 40, iceWall);   // West (Ice Hall entrance side)
    this.addWall(260, 6, 84, 1, 12, 40, iceWall);   // East (behind the Throne)

    // Door 1: Ice Hall -> Ice Cavern, at x:155 (split around the z:[80,88] doorway)
    this.addWall(155, 6, 72, 1, 12, 16, iceWall);
    this.addWall(155, 6, 96, 1, 12, 16, iceWall);
    this.createDoor(155, 3, 84, 1, 6, 8, 0x48dbfb, null, "Portão de Gelo", 'iceHall');
    // Header above the door up to the wall's full height (12)
    this.addWall(155, 9, 84, 1, 6, 8, iceWall);

    // Door 2: Ice Cavern -> Crystal Throne, at x:225 (split around the z:[80,88] doorway)
    this.addWall(225, 6, 72, 1, 12, 16, iceWall);
    this.addWall(225, 6, 96, 1, 12, 16, iceWall);
    this.createDoor(225, 3, 84, 1, 6, 8, 0xaeeeff, null, "Portão de Cristal", 'iceCavern');
    // Header above the door up to the wall's full height (12)
    this.addWall(225, 9, 84, 1, 6, 8, iceWall);

    // ---- ROOM 1: Salão de Gelo (Ice Hall) — x:[120,155] ----
    for (let i = 0; i < 8; i++) {
      const cx = 124 + Math.random() * 27;
      const cz = 68 + Math.random() * 32;
      this.spawnIceSpike(cx, cz, 0);
    }

    // ---- ROOM 2: Caverna de Cristal (big, rich middle cavern) — x:[160,220] ----
    // Speleothems: stalagmites rising from the floor AND stalactites hanging from the
    // ceiling, scattered generously through this much bigger central room.
    for (let i = 0; i < 22; i++) {
      const cx = 162 + Math.random() * 56;
      const cz = 67 + Math.random() * 34;
      if (Math.abs(cx - 190) < 7 && Math.abs(cz - 84) < 7) continue; // keep the statue's plinth clear
      this.spawnIceSpike(cx, cz, 0); // stalagmite (floor)
    }
    for (let i = 0; i < 16; i++) {
      const cx = 162 + Math.random() * 56;
      const cz = 67 + Math.random() * 34;
      this.spawnIceSpike(cx, cz, 12, true); // stalactite (ceiling, pointing down)
    }

    // Grand Unicorn Statue centerpiece
    this.createUnicornStatue(190, 84);

    // ---- ROOM 3: Trono de Cristal (Crystal Throne) — x:[230,260] ----
    for (let i = 0; i < 7; i++) {
      const cx = 232 + Math.random() * 24;
      const cz = 68 + Math.random() * 32;
      this.spawnIceSpike(cx, cz, 0);
    }

    const throneDeco = new THREE.Mesh(new THREE.CylinderGeometry(3, 4, 1, 8), new THREE.MeshLambertMaterial({ color: iceCrystal }));
    throneDeco.position.set(248, 0.5, 84);
    this.scene.add(throneDeco);

    // Portal onward to the Aurora Bridge (Area 8) — destination is clear of the bridge's
    // own west wall (x:280), not sitting exactly inside it.
    this.createExitPortal(new THREE.Vector3(248, 2.0, 84), new THREE.Vector3(285, 0.95, 84));
  }

  // Decorative ice spike — stalagmite (rising from the floor) or, when hanging=true, a
  // stalactite (pointing down from the ceiling at the given y).
  spawnIceSpike(x, z, y, hanging = false) {
    const spike = new THREE.Mesh(
      new THREE.ConeGeometry(0.5 + Math.random() * 0.9, 2 + Math.random() * 3.5, 6),
      new THREE.MeshLambertMaterial({ color: 0xaeeeff, transparent: true, opacity: 0.78 })
    );
    if (hanging) {
      spike.rotation.x = Math.PI;
      spike.position.set(x, y - 0.2, z);
    } else {
      spike.position.set(x, y + 1, z);
    }
    this.scene.add(spike);
  }

  // Big static stone unicorn statue — a grand centerpiece, not an enemy (no AI, no collider
  // needed beyond its pedestal so players can walk right up to it).
  createUnicornStatue(x, z) {
    const group = new THREE.Group();
    const stone = new THREE.MeshLambertMaterial({ color: 0xd8d8e0 });

    const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 3.2, 1.4, 16), new THREE.MeshLambertMaterial({ color: 0x5a5a68 }));
    pedestal.position.y = 0.7;
    group.add(pedestal);

    const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.8, 3.4), stone);
    body.position.y = 2.6;
    group.add(body);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 1.8, 8), stone);
    neck.position.set(0, 3.8, 1.4);
    neck.rotation.x = -0.4;
    group.add(neck);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.85, 1.5), stone);
    head.position.set(0, 4.75, 2.3);
    group.add(head);

    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.15, 1.1, 8), new THREE.MeshLambertMaterial({ color: 0xffd700, emissive: 0xffaa00, emissiveIntensity: 0.5 }));
    horn.position.set(0, 5.5, 2.7);
    horn.rotation.x = -0.3;
    group.add(horn);

    [-0.75, 0.75].forEach(lx => {
      [1.1, -1.1].forEach(lz => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.24, 2.4, 8), stone);
        leg.position.set(lx, 1.4, lz);
        group.add(leg);
      });
    });

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1.6, 8), stone);
    tail.position.set(0, 2.6, -1.9);
    tail.rotation.x = Math.PI / 2.2;
    group.add(tail);

    // Soft glow ring at the base
    const ring = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.08, 8, 24), new THREE.MeshBasicMaterial({ color: 0xaeeeff }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.05;
    group.add(ring);

    group.position.set(x, 0, z);
    this.scene.add(group);
    this.addCollider(new THREE.Box3().setFromObject(pedestal).translate(new THREE.Vector3(x, 0, z)));
  }

  // ==================== AREA 8: AURORA BRIDGE (New chasm-crossing phase!) ====================
  createAuroraBridge() {
    const bridgeMat = new THREE.MeshLambertMaterial({ color: 0x2ecc71, transparent: true, opacity: 0.85 });
    const wallColor = 0x123a24;

    // Floor (top surface at y:0, matching convention) — fully walkable, with a glowing
    // narrower strip down the middle purely for the "crossing a bridge" visual feel.
    const floor = new THREE.Mesh(new THREE.BoxGeometry(60, 1, 40), new THREE.MeshLambertMaterial({ color: 0x0e2b1c }));
    floor.position.set(310, -0.5, 84);
    this.scene.add(floor);

    const strip = new THREE.Mesh(new THREE.BoxGeometry(56, 0.1, 8), bridgeMat);
    strip.position.set(310, 0.05, 84);
    this.scene.add(strip);

    this.createCeiling(310, 12.5, 84, 60, 1, 40, 0x081f14, [[290, 12.2, 84], [330, 12.2, 84]]);
    this.addWall(310, 6, 64, 60, 12, 1, wallColor);  // North
    this.addWall(310, 6, 104, 60, 12, 1, wallColor); // South
    this.addWall(280, 6, 84, 1, 12, 40, wallColor);  // West (entrance)
    this.addWall(340, 6, 84, 1, 12, 40, wallColor);  // East (dead end)

    [-4, 4].forEach(offsetZ => {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 56, 8), new THREE.MeshBasicMaterial({ color: 0x2ecc71 }));
      rail.rotation.z = Math.PI / 2;
      rail.position.set(310, 1.0, 84 + offsetZ);
      this.scene.add(rail);
    });

    const auroraColors = [0x2ecc71, 0x1abc9c, 0x7bed9f];
    for (let i = 0; i < 6; i++) {
      const ribbon = new THREE.Mesh(
        new THREE.TorusGeometry(3, 0.15, 8, 20),
        new THREE.MeshBasicMaterial({ color: auroraColors[i % 3], transparent: true, opacity: 0.6 })
      );
      ribbon.position.set(285 + i * 9, 6 + Math.sin(i) * 2, 84 + (Math.random() - 0.5) * 20);
      ribbon.rotation.x = Math.PI / 2;
      this.scene.add(ribbon);
    }

    // The REAL Exit Portal — reaching here actually ends the game
    this.createExitPortal(new THREE.Vector3(334, 2.0, 84), null);
  }

  createCeiling(x, y, z, sx, sy, sz, color, lanternPositions = []) {
    // Solid Ceiling Slab (Walkable with Gravity Boots!)
    const ceiling = new THREE.Mesh(
      new THREE.BoxGeometry(sx, 0.8, sz),
      new THREE.MeshLambertMaterial({ color: color })
    );
    ceiling.position.set(x, y, z);
    this.scene.add(ceiling);
    this.addCollider(new THREE.Box3().setFromObject(ceiling));

    // Decorative Coffered Ceiling Beams
    const beamMat = new THREE.MeshLambertMaterial({ color: 0x54236e });
    const beamX = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.4, 1.2), beamMat);
    beamX.position.set(x, y - 0.4, z);
    const beamZ = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.4, sz), beamMat);
    beamZ.position.set(x, y - 0.4, z);
    this.scene.add(beamX, beamZ);

    // Stained Glass Central Skylight
    const skylight = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(sx * 0.35, 8), 0.1, Math.min(sz * 0.35, 8)),
      new THREE.MeshBasicMaterial({ color: 0xff9ff3, transparent: true, opacity: 0.85 })
    );
    skylight.position.set(x, y - 0.1, z);
    this.scene.add(skylight);

    // Hanging Chandeliers
    lanternPositions.forEach(pos => {
      this.createHangingChandelier(pos[0], pos[1], pos[2]);
    });
  }

  createCandyCanePillar(x, y, z, height) {
    const group = new THREE.Group();
    const pillar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.5, height, 12),
      new THREE.MeshLambertMaterial({ color: 0xffffff })
    );
    pillar.position.y = height / 2;

    // Spiral Red/Pink Rings
    const ringCount = Math.floor(height * 1.5);
    for (let r = 0; r < ringCount; r++) {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(0.52, 0.08, 6, 12),
        new THREE.MeshLambertMaterial({ color: r % 2 === 0 ? 0xff4757 : 0xff6b8b })
      );
      ring.rotation.x = Math.PI / 2 + 0.15;
      ring.position.y = 0.5 + r * 0.65;
      group.add(ring);
    }

    group.add(pillar);
    group.position.set(x, y, z);
    this.scene.add(group);
    this.addCollider(new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(x, y + height / 2, z),
      new THREE.Vector3(1.1, height, 1.1)
    ));
  }

  createWallTorch(x, y, z, normal, color = 0xfeca57) {
    const group = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.5, 0.2), new THREE.MeshLambertMaterial({ color: 0x333333 }));
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.22),
      new THREE.MeshBasicMaterial({ color: color })
    );
    crystal.position.set(0, 0.25, 0.2);
    group.add(base, crystal);
    group.position.set(x, y, z);
    group.lookAt(new THREE.Vector3(x, y, z).add(normal));
    this.scene.add(group);
  }

  createHangingChandelier(x, y, z, color = 0xfeca57) {
    const group = new THREE.Group();
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.6, 6), new THREE.MeshLambertMaterial({ color: 0xcccccc }));
    cord.position.y = -0.8;
    const star = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.45),
      new THREE.MeshBasicMaterial({ color: color })
    );
    star.position.y = -1.6;
    group.add(cord, star);
    group.position.set(x, y, z);
    this.scene.add(group);
  }

  createRainbowCanopy(x, y, z, length, width) {
    const colors = [0xff6b8b, 0xff9f43, 0xfeca57, 0x1dd1a1, 0x48dbfb, 0x9b59b6];
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(length, 0.4, width),
      new THREE.MeshLambertMaterial({ color: 0x48dbfb, transparent: true, opacity: 0.85 })
    );
    slab.position.set(x, y, z);
    this.scene.add(slab);
    this.addCollider(new THREE.Box3().setFromObject(slab));

    for (let i = 0; i < 7; i++) {
      const rx = (x - length / 2) + (i / 6) * length;
      const arch = new THREE.Mesh(
        new THREE.TorusGeometry(width * 0.65, 0.15, 8, 16, Math.PI),
        new THREE.MeshBasicMaterial({ color: colors[i % colors.length] })
      );
      arch.rotation.y = Math.PI / 2;
      arch.position.set(rx, y, z);
      this.scene.add(arch);
    }
  }

  createDomeCeiling(x, y, z, radius) {
    const ceiling = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, 1.0, 24),
      new THREE.MeshLambertMaterial({ color: 0x2e1442 })
    );
    ceiling.position.set(x, y, z);
    this.scene.add(ceiling);
    this.addCollider(new THREE.Box3().setFromObject(ceiling));

    const star = new THREE.Mesh(
      new THREE.DodecahedronGeometry(1.6),
      new THREE.MeshBasicMaterial({ color: 0xffd700 })
    );
    star.position.set(x, y - 1.8, z);
    this.scene.add(star);
  }

  // ==================== INTERACTIVE PROPS: DOORS, SWITCHES, ELEVATORS ====================
  createDoor(x, y, z, sx, sy, sz, color, keyRequired = null, label = "Porta", clearArea = null) {
    const doorGroup = new THREE.Group();
    const mat = new THREE.MeshLambertMaterial({ color: color });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat);
    doorGroup.add(mesh);
    doorGroup.position.set(x, y, z);
    this.scene.add(doorGroup);

    // Keycard symbol on door
    if (keyRequired) {
      const symGeom = new THREE.SphereGeometry(0.35, 8, 8);
      const symMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const sym = new THREE.Mesh(symGeom, symMat);
      sym.position.set(0, 0, sz * 0.55);
      doorGroup.add(sym);
    }

    const box = new THREE.Box3().setFromObject(doorGroup);
    this.addCollider(box);

    const doorObj = {
      group: doorGroup,
      mesh: mesh,
      collider: box,
      initialY: y,
      targetY: y,
      isOpen: false,
      keyRequired: keyRequired,
      clearArea: clearArea, // set once every enemy tagged with this area is dead, this door force-opens
      label: label,
      open: () => {
        if (!doorObj.isOpen) {
          doorObj.isOpen = true;
          doorObj.targetY = doorObj.initialY + sy; // Slides up
          window.soundEngine.playTone(400, 0.2, 'triangle', 0.4);
          setTimeout(() => {
            window.soundEngine.playTone(600, 0.3, 'sine', 0.4);
          }, 150);
          // This is the final door leading from the Rainbow Bridge into the Boss Arena —
          // the Chocolate Boss stays completely dormant (no attacks at all) until it opens.
          if (clearArea === 'bridge' && window.enemiesManager && window.enemiesManager.activateBoss) {
            window.enemiesManager.activateBoss();
          }
        }
      }
    };

    this.doors.push(doorObj);
    return doorObj;
  }

  createSwitch(pos, normal, promptText, onActivate) {
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.2), new THREE.MeshLambertMaterial({ color: 0x333333 }));
    const button = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.3, 12), new THREE.MeshLambertMaterial({ color: 0xff6b8b, emissive: 0xff6b8b, emissiveIntensity: 0.5 }));
    button.rotation.x = Math.PI / 2;
    button.position.z = 0.15;

    const group = new THREE.Group();
    group.add(base, button);
    group.position.copy(pos);
    group.lookAt(pos.clone().add(normal));
    this.scene.add(group);

    this.switches.push({
      group: group,
      button: button,
      position: pos,
      promptText: promptText,
      activated: false,
      activate: () => {
        button.material.color.setHex(0x1dd1a1);
        button.material.emissive.setHex(0x1dd1a1);
        onActivate();
      }
    });
  }

  createElevator(pos, size, minY, maxY, color) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(size.x, size.y, size.z), new THREE.MeshLambertMaterial({ color: color }));
    mesh.position.copy(pos);
    this.scene.add(mesh);

    const collider = new THREE.Box3().setFromObject(mesh);
    this.addCollider(collider);

    this.elevators.push({
      mesh: mesh,
      collider: collider,
      minY: minY,
      maxY: maxY,
      speed: 2.2,
      direction: 1
    });
  }

  createTeleporter(pos, destination, color = 0x00d2d3) {
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.8, 0.3, 16), new THREE.MeshLambertMaterial({ color: color }));
    pad.position.copy(pos);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.2, 0.08, 8, 16), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.3;
    pad.add(ring);

    this.scene.add(pad);

    this.teleporters.push({
      mesh: pad,
      ring: ring,
      pos: pos,
      destination: destination,
      radius: 1.5
    });
  }

  // ==================== PICKUPS & KEYS INVENTORY ====================
  spawnPickupsAndKeys() {
    // 1. Keys
    this.spawnKey(new THREE.Vector3(0, 1.2, 54), 'rainbow', 'Chave Arco-Íris', 0xff9ff3);
    this.spawnKey(new THREE.Vector3(0, 11.2, 84), 'star', 'Chave Estelar', 0xfeca57); // In Inverted Vault ceiling!
    this.spawnKey(new THREE.Vector3(50, 3.8, 84), 'donut', 'Chave Rosquinha', 0xff9f43);

    // 2. Weapons
    // Chaingun in Donut Hall
    this.spawnWeaponPickup(new THREE.Vector3(12, 1.2, 38), 3, "Metralhadora de Goma");
    // Rocket Launcher on Catwalk
    this.spawnWeaponPickup(new THREE.Vector3(0, 5.8, 54), 4, "Lança-Cupcake");
    // RAINBOW-9999 in Secret Armory (Behind Destructible Wall 1)
    this.spawnWeaponPickup(new THREE.Vector3(-29, 1.2, 42), 5, "RAINBOW-9999");

    // 3. Health (Cupcakes) & Armor (Shields)
    const hpLocations = [
      [-6, 0.8, -6], [6, 0.8, -6], [-8, 0.8, 30], [8, 0.8, 30],
      [-29, 0.8, 36], [-29, 0.8, 48], // In Secret Armory
      [-10, 0.8, 76], [10, 0.8, 76],
      [78, 1.5, 78], [78, 1.5, 90],
      // Frozen Crystal Tower (Ice Hall, Cavern, Throne)
      [130, 0.8, 96], [180, 0.8, 70], [210, 0.8, 96], [244, 0.8, 94],
      // Aurora Bridge
      [292, 0.8, 84], [326, 0.8, 84]
    ];
    hpLocations.forEach(p => this.spawnHealthPickup(new THREE.Vector3(p[0], p[1], p[2]), 25));

    // Mega-Cake (+100 HP) in Secret 3
    this.spawnHealthPickup(new THREE.Vector3(-26, 1.2, 84), 100, true);

    // GRAVITY BOOTS! Hidden in the Secret 2 room in the very first area (Courtyard).
    this.spawnGravityBootsPickup(new THREE.Vector3(-24, 1.2, 10));

    const armorLocations = [
      [-4, 0.8, 8], [4, 0.8, 8], [0, 5.5, 42],
      [-10, 0.8, 92], [10, 0.8, 92], [88, 1.5, 70],
      // Frozen Crystal Tower
      [140, 0.8, 94], [200, 0.8, 74], [238, 0.8, 70],
      // Aurora Bridge
      [310, 0.8, 90]
    ];
    armorLocations.forEach(p => this.spawnArmorPickup(new THREE.Vector3(p[0], p[1], p[2]), 25));

    // Prism Armor (+100 AP) in Secret 3
    this.spawnArmorPickup(new THREE.Vector3(-26, 1.2, 88), 100, true);

    // 4. Ammo Packs
    const ammoLocations = [
      [-8, 0.8, 0], [8, 0.8, 0], [-12, 0.8, 48], [12, 0.8, 48],
      [36, 3.5, 84], [44, 3.5, 84],
      // Boss Arena — extra ammo since the Chocolate Boss fight burns through it fast
      [88, 1.5, 98], [78, 1.2, 74], [78, 1.2, 94], [100, 1.2, 84],
      // Frozen Crystal Tower
      [132, 1.2, 68], [178, 1.2, 100], [212, 1.2, 72], [250, 1.2, 100],
      // Aurora Bridge
      [286, 1.2, 70], [334, 1.2, 96]
    ];
    ammoLocations.forEach(p => this.spawnAmmoPickup(new THREE.Vector3(p[0], p[1], p[2]), 35));

    this.itemsTotal = this.pickups.length;
  }

  spawnKey(pos, keyType, name, color) {
    const geom = new THREE.TorusGeometry(0.35, 0.1, 8, 16);
    const mat = new THREE.MeshLambertMaterial({ color: color, emissive: color, emissiveIntensity: 0.6 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(pos);
    this.scene.add(mesh);

    this.pickups.push({
      mesh: mesh,
      type: 'key',
      keyType: keyType,
      name: name,
      pos: pos,
      initialY: pos.y
    });
  }

  spawnWeaponPickup(pos, weaponIndex, name) {
    let mesh;

    if (weaponIndex === 5) {
      // a glowing rainbow-striped orb with an orbiting ring, floating over a pedestal.
      mesh = new THREE.Group();

      const core = new THREE.Mesh(
        new THREE.SphereGeometry(0.42, 16, 16),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      mesh.add(core);

      const stripeColors = [0xff6b8b, 0xff9f43, 0xfeca57, 0x1dd1a1, 0x48dbfb, 0x9b59b6];
      stripeColors.forEach((color, i) => {
        const stripe = new THREE.Mesh(
          new THREE.TorusGeometry(0.5, 0.07, 8, 20),
          new THREE.MeshBasicMaterial({ color })
        );
        stripe.rotation.x = Math.PI / 2;
        stripe.rotation.z = (i / stripeColors.length) * Math.PI;
        mesh.add(stripe);
      });

      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(0.75, 0.05, 8, 24),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 })
      );
      mesh.add(ring);
      mesh.userData.spinRing = ring;

      const pedestal = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.6, 0.4, 12),
        new THREE.MeshLambertMaterial({ color: 0x2a1245 })
      );
      pedestal.position.y = -0.65;
      mesh.add(pedestal);

      mesh.scale.set(1.2, 1.2, 1.2);
    } else if (weaponIndex === 4) {
      // Lança-Cupcake — an actual cupcake: pleated wrapper, frosting swirl and a cherry.
      mesh = new THREE.Group();

      const wrapper = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.3, 0.28, 12),
        new THREE.MeshLambertMaterial({ color: 0xfeca57 })
      );
      wrapper.position.y = -0.15;
      mesh.add(wrapper);

      const frosting = new THREE.Mesh(
        new THREE.SphereGeometry(0.27, 14, 10, 0, Math.PI * 2, 0, Math.PI / 1.5),
        new THREE.MeshLambertMaterial({ color: 0xff9ff3 })
      );
      frosting.position.y = 0.1;
      mesh.add(frosting);

      const cherry = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 10, 10),
        new THREE.MeshLambertMaterial({ color: 0xff4757, emissive: 0xff4757, emissiveIntensity: 0.3 })
      );
      cherry.position.y = 0.38;
      mesh.add(cherry);

      mesh.scale.set(1.3, 1.3, 1.3);
    } else {
      const geom = new THREE.BoxGeometry(0.6, 0.4, 0.8);
      const mat = new THREE.MeshLambertMaterial({ color: 0xff6b8b, emissive: 0xfeca57, emissiveIntensity: 0.5 });
      mesh = new THREE.Mesh(geom, mat);
    }

    mesh.position.copy(pos);
    this.scene.add(mesh);

    this.pickups.push({
      mesh: mesh,
      type: 'weapon',
      weaponIndex: weaponIndex,
      name: name,
      pos: pos,
      initialY: pos.y
    });
  }

  spawnHealthPickup(pos, amount, isMega = false) {
    // Real lollipop-candy model instead of a plain cylinder
    const group = new THREE.Group();
    const scale = isMega ? 1.5 : 1;
    const color = isMega ? 0xff0055 : 0xff6b8b;

    const candy = new THREE.Mesh(
      new THREE.SphereGeometry(0.3 * scale, 12, 12),
      new THREE.MeshLambertMaterial({ color })
    );
    candy.position.y = 0.18 * scale;
    group.add(candy);

    for (let i = 0; i < 3; i++) {
      const swirl = new THREE.Mesh(
        new THREE.TorusGeometry(0.3 * scale, 0.045 * scale, 6, 16),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      swirl.position.y = 0.18 * scale;
      swirl.rotation.x = Math.PI / 2;
      swirl.rotation.z = (i / 3) * Math.PI;
      group.add(swirl);
    }

    const stick = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045 * scale, 0.045 * scale, 0.4 * scale, 6),
      new THREE.MeshLambertMaterial({ color: 0xffffff })
    );
    stick.position.y = -0.2 * scale;
    group.add(stick);

    group.position.copy(pos);
    this.scene.add(group);

    this.pickups.push({
      mesh: group,
      type: 'health',
      amount: amount,
      pos: pos,
      initialY: pos.y
    });
  }

  spawnArmorPickup(pos, amount, isMega = false) {
    // Real sprinkle-shield model instead of a plain torus
    const group = new THREE.Group();
    const scale = isMega ? 1.4 : 1;
    const color = isMega ? 0x00ffff : 0x00d2d3;

    const shieldGeom = new THREE.OctahedronGeometry(0.4 * scale, 0);
    shieldGeom.scale(0.85, 1.15, 0.4);
    const shield = new THREE.Mesh(shieldGeom, new THREE.MeshLambertMaterial({ color }));
    group.add(shield);

    const rim = new THREE.Mesh(
      new THREE.TorusGeometry(0.3 * scale, 0.04 * scale, 6, 16),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    group.add(rim);

    const sprinkleColors = [0xff6b8b, 0xfeca57, 0x1dd1a1, 0xff9ff3];
    for (let i = 0; i < 6; i++) {
      const sprinkle = new THREE.Mesh(
        new THREE.CylinderGeometry(0.02 * scale, 0.02 * scale, 0.13 * scale, 4),
        new THREE.MeshBasicMaterial({ color: sprinkleColors[i % sprinkleColors.length] })
      );
      const ang = (i / 6) * Math.PI * 2;
      sprinkle.position.set(Math.cos(ang) * 0.16 * scale, Math.sin(ang) * 0.16 * scale, 0.06 * scale);
      sprinkle.rotation.z = ang;
      sprinkle.rotation.x = Math.PI / 2.3;
      group.add(sprinkle);
    }

    group.position.copy(pos);
    this.scene.add(group);

    this.pickups.push({
      mesh: group,
      type: 'armor',
      amount: amount,
      pos: pos,
      initialY: pos.y
    });
  }

  spawnGravityBootsPickup(pos) {
    const group = new THREE.Group();

    // Stone pedestal so it reads as a "treasure on display", not a floating prop
    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.65, 0.5, 12),
      new THREE.MeshLambertMaterial({ color: 0x2a1245 })
    );
    pedestal.position.y = -0.75;
    group.add(pedestal);

    // Big, unmistakable glowing boots (scaled way up from a normal worn boot)
    const bootMat = new THREE.MeshLambertMaterial({ color: 0x00d2d3, emissive: 0x00d2d3, emissiveIntensity: 0.85 });
    const soleMat = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x48dbfb, emissiveIntensity: 0.6 });
    const makeBoot = () => {
      const boot = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.42, 0.62), bootMat);
      body.position.y = 0.1;
      const sole = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.1, 0.7), soleMat);
      sole.position.y = -0.16;
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.22, 0.3, 8), bootMat);
      cuff.position.set(0, 0.42, -0.12);
      boot.add(body, sole, cuff);
      return boot;
    };
    const bootL = makeBoot();
    const bootR = makeBoot();
    bootL.position.set(-0.22, 0, 0);
    bootR.position.set(0.22, 0, 0);
    group.add(bootL, bootR);

    // Glowing ring at the base
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.65, 0.06, 8, 24), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.48;
    group.add(ring);

    // Vertical beam of light shooting up — visible from across the whole room
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.12, 8, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })
    );
    beam.position.y = 4;
    group.add(beam);

    group.scale.set(1.4, 1.4, 1.4);
    group.position.copy(pos);
    this.scene.add(group);

    this.pickups.push({
      mesh: group,
      type: 'gravityboots',
      name: "Botas de Gravidade",
      pos: pos,
      initialY: pos.y,
      beam: beam
    });
  }

  spawnAmmoPickup(pos, amount) {
    const geom = new THREE.BoxGeometry(0.4, 0.35, 0.4);
    const mat = new THREE.MeshLambertMaterial({ color: 0xfeca57 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(pos);
    this.scene.add(mesh);

    this.pickups.push({
      mesh: mesh,
      type: 'ammo',
      amount: amount,
      pos: pos,
      initialY: pos.y
    });
  }

  // ==================== COLLISION & HIT TESTS ====================
  addWall(x, y, z, sx, sy, sz, color) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), new THREE.MeshLambertMaterial({ color: color }));
    wall.position.set(x, y, z);
    this.scene.add(wall);
    this.addCollider(new THREE.Box3().setFromObject(wall));
    return wall;
  }

  // Like addWall, but rotated around Y — used for angled segments (e.g. the octagonal
  // Boss Arena wall) that don't align with the world X/Z axes.
  addAngledWall(x, y, z, length, height, thickness, angleY, color) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(length, height, thickness), new THREE.MeshLambertMaterial({ color: color }));
    wall.position.set(x, y, z);
    wall.rotation.y = angleY;
    this.scene.add(wall);
    this.addCollider(new THREE.Box3().setFromObject(wall));
    return wall;
  }

  addCollider(box) {
    this.colliders.push(box);
  }

  // Invisible solid barrier (force-field): blocks movement without adding visible geometry.
  // Used to seal chasm edges/ledges where a visible wall would ruin the view.
  addInvisibleBarrier(x, y, z, sx, sy, sz) {
    const box = new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(x, y, z),
      new THREE.Vector3(sx, sy, sz)
    );
    this.addCollider(box);
    return box;
  }

  removeCollider(box) {
    const idx = this.colliders.indexOf(box);
    if (idx !== -1) this.colliders.splice(idx, 1);
  }

  checkCollision(box) {
    for (let c of this.colliders) {
      if (box.intersectsBox(c)) return true;
    }
    return false;
  }

  checkProjectileCollision(startPos, endPos, damage, canBreakWalls) {
    const ray = new THREE.Ray(startPos, endPos.clone().sub(startPos).normalize());
    const dist = startPos.distanceTo(endPos);

    // 1. Check Destructible walls first
    for (let dw of this.destructibleWalls) {
      if (dw.destroyed) continue;
      const hitPoint = new THREE.Vector3();
      if (ray.intersectBox(dw.collider, hitPoint)) {
        if (startPos.distanceTo(hitPoint) <= dist) {
          // Damage wall
          if (canBreakWalls) {
            this.damageDestructibleWall(dw, damage);
          } else {
            this.damageDestructibleWall(dw, damage * 0.25);
          }
          return { hit: true, point: hitPoint, normal: new THREE.Vector3(0, 0, 1) };
        }
      }
    }

    // 2. Check Static Colliders
    for (let c of this.colliders) {
      const hitPoint = new THREE.Vector3();
      if (ray.intersectBox(c, hitPoint)) {
        if (startPos.distanceTo(hitPoint) <= dist) {
          return { hit: true, point: hitPoint, normal: new THREE.Vector3(0, 1, 0) };
        }
      }
    }

    return { hit: false };
  }

  checkWallHit(origin, dir, maxDist, damage) {
    const ray = new THREE.Ray(origin, dir);
    for (let dw of this.destructibleWalls) {
      if (dw.destroyed) continue;
      const hit = new THREE.Vector3();
      if (ray.intersectBox(dw.collider, hit)) {
        if (origin.distanceTo(hit) <= maxDist) {
          this.damageDestructibleWall(dw, damage);
          return true;
        }
      }
    }
    return false;
  }

  breakNearbyWalls(center, radius) {
    for (let dw of this.destructibleWalls) {
      if (dw.destroyed) continue;
      if (dw.mesh.position.distanceTo(center) <= radius + 2.0) {
        this.damageDestructibleWall(dw, 200);
      }
    }
  }

  damageDestructibleWall(dw, damage) {
    dw.health -= damage;
    window.soundEngine.playWallCrack();
    this.particles.spawnHitSparks(dw.mesh.position, new THREE.Vector3(0, 1, 0), 0xff9ff3);

    // Visual crack intensity
    const hpRatio = Math.max(0, dw.health / dw.maxHealth);
    dw.mesh.material.color.setHex(hpRatio < 0.5 ? 0xff4757 : 0xff9ff3);

    if (dw.health <= 0) {
      this.breakWall(dw);
    }
  }

  breakWall(dw) {
    dw.destroyed = true;
    this.removeCollider(dw.collider);
    this.scene.remove(dw.mesh);

    window.soundEngine.playWallCrack();
    // Big chunky fragments matching the wall's own shape, flying apart with real physics —
    // plus the smaller sparkle debris burst, layered together for a satisfying shatter.
    this.particles.spawnWallShatter(dw.mesh.position, dw.size, 0xff9ff3);
    this.particles.spawnWallBreak(dw.mesh.position);

    // Secret discovered reward!
    this.secretsFound++;
    window.soundEngine.playSecretFound();
    window.game.showMessage(`🎉 SEGREDO ENCONTRADO! [${dw.secretName}]`, 'secret');
  }

  // ==================== UPDATE ANIMATIONS & INTERACTION ====================
  update(delta, player) {
    const time = performance.now() * 0.003;

    // 1. Pickups bobbing & rotation
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.mesh.rotation.y += 2.5 * delta;
      p.mesh.position.y = p.initialY + Math.sin(time * 3 + p.initialY) * 0.15;
      if (p.mesh.userData.spinRing) {
        p.mesh.userData.spinRing.rotation.x += delta * 3;
      }

      // Pickup collision with player
      if (player.position.distanceTo(p.mesh.position) < 1.6) {
        this.collectPickup(p, i, player);
      }
    }

    // 2. Door opening animation
    this.doors.forEach(d => {
      if (d.isOpen && d.group.position.y < d.targetY) {
        d.group.position.y += 3.0 * delta;
        d.collider.setFromObject(d.group);
      }
    });

    // 3. Elevators moving smoothly
    this.elevators.forEach(el => {
      el.mesh.position.y += el.speed * el.direction * delta;
      if (el.mesh.position.y >= el.maxY) {
        el.mesh.position.y = el.maxY;
        el.direction = -1;
      } else if (el.mesh.position.y <= el.minY) {
        el.mesh.position.y = el.minY;
        el.direction = 1;
      }
      el.collider.setFromObject(el.mesh);
    });

    // 4. Teleporters spin & trigger
    this.teleporters.forEach(tp => {
      tp.ring.rotation.z += 4.0 * delta;
      if (player.position.distanceTo(tp.pos) < tp.radius) {
        player.position.copy(tp.destination);
        window.soundEngine.playTone(800, 0.25, 'sine', 0.4);
        window.game.showMessage("🌀 Teletransportado!");
      }
    });

    // 5. Exit Portal animation & Trigger
    this.exitPortals.forEach(portal => {
      portal.vortex.rotation.z += 2.0 * delta;
      portal.horn.rotation.y += 3.0 * delta;
      if (portal.cooldown > 0) portal.cooldown -= delta;
      // Horizontal-only distance: the portal's trigger point sits well above eye height
      // (it's a tall pedestal + trophy), so a full 3D distance check was mathematically
      // impossible to satisfy at normal standing height — this fixes every portal in the
      // game, including the original victory one.
      const dx = player.position.x - portal.position.x;
      const dz = player.position.z - portal.position.z;
      const horizDist = Math.sqrt(dx * dx + dz * dz);
      if (portal.cooldown <= 0 && horizDist < portal.radius) {
        if (portal.teleportTo) {
          player.position.copy(portal.teleportTo);
          player.velocity.set(0, 0, 0);
          portal.cooldown = 2.0;
          window.soundEngine.playSecretFound();
          window.game.showMessage("🌀 Portal! Uma nova fase se abre à sua frente!");
        } else {
          window.game.triggerVictory();
        }
      }
    });

    // Update map sector exploration percentage
    this.updateExploration(player.position);
  }

  collectPickup(p, index, player) {
    let collected = false;

    if (p.type === 'key') {
      player.keys[p.keyType] = true;
      window.soundEngine.playPickup('key');
      window.game.showMessage(`🔑 Você pegou a ${p.name}!`);
      document.getElementById(`key-${p.keyType}`).classList.add('active');
      collected = true;
    } else if (p.type === 'weapon') {
      window.weapons.unlockWeapon(p.weaponIndex);
      window.soundEngine.playPickup('weapon');
      window.game.showMessage(`🔫 Nova Arma: ${p.name}!`);
      collected = true;
    } else if (p.type === 'health') {
      // Always collectible now — previously stayed on the ground forever (looking "stuck"/
      // uncollectable) if the player was already at full health.
      player.health = Math.min(player.maxHealth, player.health + p.amount);
      window.soundEngine.playPickup('health');
      window.game.showMessage(`💖 Doce Regenerativo +${p.amount} Vida!`);
      collected = true;
    } else if (p.type === 'armor') {
      player.armor = Math.min(player.maxArmor, player.armor + p.amount);
      window.soundEngine.playPickup('armor');
      window.game.showMessage(`🛡️ Escudo de Confeito +${p.amount} Armadura!`);
      collected = true;
    } else if (p.type === 'ammo') {
      player.ammo = Math.min(player.maxAmmo, player.ammo + p.amount);
      window.soundEngine.playPickup('ammo');
      window.game.showMessage(`🍬 Pacote de Goma +${p.amount} Munição!`);
      collected = true;
    } else if (p.type === 'gravityboots') {
      player.unlockGravityBoots();
      collected = true;
    }

    if (collected) {
      this.itemsCollected++;
      this.scene.remove(p.mesh);
      if (p.mesh.geometry) p.mesh.geometry.dispose();
      if (p.mesh.material) p.mesh.material.dispose();
      this.pickups.splice(index, 1);
    }
  }

  updateExploration(pos) {
    if (pos.z < 20) this.visitedSectors.add(0); // Courtyard
    else if (pos.z >= 20 && pos.z < 64 && pos.x > -20) this.visitedSectors.add(1); // Donut Hall
    else if (pos.z >= 64 && pos.x < 20 && pos.x > -20) this.visitedSectors.add(2); // Inverted Vault
    else if (pos.x <= -20) this.visitedSectors.add(3); // Secret Labyrinth
    else if (pos.x >= 20 && pos.x < 70) this.visitedSectors.add(4); // Rainbow Bridge
    else if (pos.x >= 70) this.visitedSectors.add(5); // Boss Sanctuary
  }

  getExplorationPercentage() {
    return Math.round((this.visitedSectors.size / this.totalSectors) * 100);
  }

  // Called on player death/restart: puts every pickup, door and destructible wall back
  // to its original untouched state so a fresh life is actually fresh (previously only
  // enemies respawned — every pickup you'd already grabbed, including the Gravity Boots,
  // stayed gone forever).
  resetProgress() {
    // 1. Wipe & respawn all pickups (health, armor, ammo, weapons, keys, gravity boots...)
    this.pickups.forEach(p => this.scene.remove(p.mesh));
    this.pickups = [];
    this.itemsCollected = 0;
    this.secretsFound = 0;
    this.visitedSectors.clear();
    this.spawnPickupsAndKeys();
    this.itemsTotal = this.pickups.length;

    // 2. Snap every door back to closed
    this.doors.forEach(d => {
      d.isOpen = false;
      d.targetY = d.initialY;
      d.group.position.y = d.initialY;
      d.collider.setFromObject(d.group);
    });

    // 3. Repair every destructible wall (re-adds mesh + collider if it was broken)
    this.destructibleWalls.forEach(dw => {
      if (dw.destroyed) {
        dw.destroyed = false;
        dw.health = dw.maxHealth;
        dw.mesh.material.color.setHex(0xff9ff3);
        this.scene.add(dw.mesh);
        this.addCollider(dw.collider);
      }
    });

    // 4. Reset switches
    this.switches.forEach(s => {
      s.activated = false;
      s.button.material.color.setHex(0xff6b8b);
      s.button.material.emissive.setHex(0xff6b8b);
    });
  }

  // Interactive check when pressing [E]
  interact(player) {
    // 1. Check Doors nearby
    for (let d of this.doors) {
      if (!d.isOpen && player.position.distanceTo(d.group.position) < 4.0) {
        const areaClear = !d.clearArea || (window.enemiesManager && window.enemiesManager.isAreaCleared(d.clearArea));
        const hasKey = !d.keyRequired || player.keys[d.keyRequired];
        if (areaClear && hasKey) {
          d.open();
          window.game.showMessage(`🔓 ${d.label} aberta!`);
        } else if (!areaClear) {
          window.soundEngine.playTone(180, 0.15, 'sawtooth', 0.3);
          window.game.showMessage(`🔒 Derrote todos os inimigos desta área para abrir a ${d.label}!`);
        } else {
          window.soundEngine.playTone(180, 0.15, 'sawtooth', 0.3);
          window.game.showMessage(`🔒 Trancada! Requer ${d.label}.`);
        }
        return;
      }
    }

    // 2. Check Switches
    for (let s of this.switches) {
      if (!s.activated && player.position.distanceTo(s.position) < 3.5) {
        s.activated = true;
        s.activate();
        return;
      }
    }
  }

  // Called by EnemiesManager the moment the last enemy of an area dies.
  // Force-opens any door gating that area, regardless of keys/switches.
  onAreaCleared(area) {
    let opened = false;
    this.doors.forEach(d => {
      if (d.clearArea === area && !d.isOpen) {
        d.open();
        opened = true;
      }
    });
    if (opened) {
      window.soundEngine.playSecretFound();
      window.game.showMessage(`🎉 Área limpa! A porta se abriu!`);
    }
  }
}
