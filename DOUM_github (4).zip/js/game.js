// DOUM - Main Game Engine, HUD Updates, Minimap & Statistics
// Ties together Audio, Particles, Weapons, Map, Enemies and Player subsystems.

class GameEngine {
  constructor() {
    this.container = document.getElementById('canvas-container');
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.clock = new THREE.Clock();

    // Game state
    this.isRunning = false;
    this.isPaused = false;
    this.isGameOver = false;
    this.isVictory = false;
    this.startTime = 0;
    this.elapsedTime = 0;

    // Minimap canvas
    this.minimapCanvas = document.getElementById('minimap');
    this.minimapCtx = this.minimapCanvas.getContext('2d');

    // Message log timer
    this.messageTimeout = null;

    this.initScene();
    this.setupUIEvents();
  }

  initScene() {
    // 1. Three.js Scene
    this.scene = new THREE.Scene();

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    // The camera MUST be part of the scene graph, or anything parented to it (like the
    // first-person weapon viewmodels) never gets traversed by renderer.render() and never
    // actually renders — this was true even before any weapon model changes.
    this.scene.add(this.camera);

    // 3. Renderer with antialiasing and tone mapping
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.container.appendChild(this.renderer.domElement);

    // 4. Subsystems
    window.particleSystem = new ParticleSystem(this.scene);
    window.weapons = new WeaponSystem(this.scene, this.camera, window.particleSystem);
    window.mapManager = new MapManager(this.scene, window.particleSystem);
    window.enemiesManager = new EnemiesManager(this.scene, window.particleSystem, this.camera);
    window.player = new PlayerController(this.camera, this.scene, this.renderer.domElement);

    // Responsive resize
    window.addEventListener('resize', () => this.onWindowResize());
  }

  setupUIEvents() {
    // Start Button
    const startBtn = document.getElementById('btn-start-game');
    startBtn.addEventListener('click', () => {
      document.getElementById('start-modal').classList.add('hidden');
      window.soundEngine.init();
      this.startGame();
    });

    // HUD Pause Button
    const hudPauseBtn = document.getElementById('btn-hud-pause');
    if (hudPauseBtn) {
      hudPauseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (this.isRunning && !this.isGameOver && !this.isVictory) {
          this.togglePause();
        }
      });
    }

    // Pause Key [Escape] or [P]
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (this.isRunning && !this.isGameOver && !this.isVictory) {
          this.togglePause();
        }
      }
    });

    // Pause Menu Buttons
    document.getElementById('btn-resume-game').addEventListener('click', () => {
      this.togglePause();
    });

    const restartPauseBtn = document.getElementById('btn-pause-restart');
    if (restartPauseBtn) {
      restartPauseBtn.addEventListener('click', () => {
        this.togglePause();
        this.restartGame();
      });
    }

    // Camera Sensitivity Slider
    const sensSlider = document.getElementById('slider-sensitivity');
    const sensDisplay = document.getElementById('sensitivity-display');
    if (sensSlider && sensDisplay) {
      sensSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        sensDisplay.textContent = `${val.toFixed(1)}x`;
        if (window.player) {
          window.player.setSensitivity(val);
        }
      });
    }

    const musicBtn = document.getElementById('btn-toggle-music');
    musicBtn.addEventListener('click', () => {
      const active = window.soundEngine.toggleMusic();
      musicBtn.textContent = active ? "🎵 MÚSICA: LIGADA" : "🎵 MÚSICA: DESLIGADA";
    });

    // Retry / Replay
    document.getElementById('btn-retry-game').addEventListener('click', () => {
      this.restartGame();
    });

    document.getElementById('btn-replay-level').addEventListener('click', () => {
      this.restartGame();
    });

    // Weapon slots click on HUD ribbon
    document.querySelectorAll('.weapon-slot').forEach(slot => {
      slot.addEventListener('click', () => {
        const slotIdx = parseInt(slot.getAttribute('data-slot')) - 1;
        window.weapons.selectWeapon(slotIdx);
      });
    });
  }

  startGame() {
    this.isRunning = true;
    this.isPaused = false;
    this.isGameOver = false;
    this.isVictory = false;
    this.startTime = performance.now();
    this.clock.start();

    // Lock cursor
    this.renderer.domElement.requestPointerLock();

    this.showMessage("🦄 DOUM INICIADO! Derrote as criaturas mágicas e ache o Portal!");
    if (!this.isLooping) {
      this.isLooping = true;
      this.animate();
    }
  }

  togglePause() {
    this.isPaused = !this.isPaused;
    const pauseModal = document.getElementById('pause-modal');
    if (this.isPaused) {
      pauseModal.classList.remove('hidden');
      document.exitPointerLock();
    } else {
      pauseModal.classList.add('hidden');
      this.renderer.domElement.requestPointerLock();
      this.clock.getDelta(); // flush delta
    }
  }

  restartGame() {
    // Hide modals
    document.getElementById('gameover-modal').classList.add('hidden');
    document.getElementById('victory-modal').classList.add('hidden');

    // Clean up scene
    window.particleSystem.clearAll();
    window.weapons.clearAll();
    window.enemiesManager.clearAll();
    window.mapManager.resetProgress(); // Respawns all pickups (incl. Gravity Boots), closes doors, repairs walls

    // Reset player
    window.player.position.set(0, 0.95, -10);
    window.player.velocity.set(0, 0, 0);
    window.player.health = 100;
    window.player.armor = 50;
    window.player.ammo = 100;
    window.player.keys = { rainbow: false, star: false, donut: false };
    if (window.player.gravityMode === 'ceiling') {
      window.player.gravityMode = 'floor';
      window.player.gravityUp.set(0, 1, 0);
      window.player.targetCameraUp.set(0, 1, 0);
    }

    // Reset Gravity Boots back to "not found yet"
    window.player.hasGravityBoots = false;
    const gravBtn = document.getElementById('btn-gravity-toggle');
    if (gravBtn) {
      gravBtn.classList.add('locked');
      gravBtn.classList.remove('gravity-active');
      gravBtn.title = "Botas de Gravidade — ainda não encontradas!";
    }
    const gravText = document.getElementById('gravity-mode-text');
    if (gravText) gravText.textContent = "BLOQUEADO";
    const u = window.player.avatarModel && window.player.avatarModel.userData;
    if (u && u.bootL) {
      [u.bootL, u.bootR].forEach(b => {
        b.material.color.setHex(0x888888);
        b.material.emissive.setHex(0x888888);
        b.material.emissiveIntensity = 0.15;
      });
    }

    // Reset HUD keys
    ['rainbow', 'star', 'donut'].forEach(k => {
      const el = document.getElementById(`key-${k}`);
      if (el) el.classList.remove('active');
    });

    // Respawn enemies
    window.enemiesManager.killsCount = 0;
    window.enemiesManager.totalSpawned = 0;
    window.enemiesManager.spawnAllEnemies();

    // Start fresh
    this.startGame();
  }

  onWindowResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // ==================== MAIN GAME LOOP ====================
  animate() {
    if (!this.isRunning) {
      this.isLooping = false;
      return;
    }
    requestAnimationFrame(() => this.animate());

    if (this.isPaused) return;

    const delta = Math.min(this.clock.getDelta(), 0.1);
    this.elapsedTime = (performance.now() - this.startTime) / 1000;

    // 1. Update Subsystems
    window.player.update(delta, window.mapManager);
    window.weapons.update(delta, window.player, window.enemiesManager, window.mapManager);
    window.enemiesManager.update(delta, window.player, window.mapManager);
    window.mapManager.update(delta, window.player);
    window.particleSystem.update(delta);

    // 2. Render 3D Scene
    this.renderer.render(this.scene, this.camera);

    // 3. Update HUD & Minimap
    this.updateHUD();
    this.drawMinimap();
  }

  // ==================== HUD UPDATES ====================
  updateHUD() {
    // Stats
    document.getElementById('stat-health').textContent = `${Math.max(0, Math.round(window.player.health))}%`;
    document.getElementById('stat-armor').textContent = `${Math.max(0, Math.round(window.player.armor))}%`;
    document.getElementById('stat-ammo').textContent = `${window.player.ammo}`;

    // Low HP alert
    const hpElem = document.getElementById('stat-health');
    if (window.player.health < 30) {
      hpElem.style.color = '#ff4757';
    } else {
      hpElem.style.color = '#ff6b8b';
    }
  }

  showMessage(text, type = 'normal') {
    const log = document.getElementById('message-log');
    const msg = document.createElement('div');
    msg.className = `hud-msg ${type}`;
    msg.textContent = text;
    log.appendChild(msg);

    setTimeout(() => {
      msg.style.opacity = '0';
      msg.style.transform = 'translateX(-30px)';
      setTimeout(() => msg.remove(), 400);
    }, 3500);
  }

  onEnemyHit() {
    // Crosshair hit-marker flash
    const ch = document.getElementById('crosshair');
    ch.classList.add('hit');
    setTimeout(() => ch.classList.remove('hit'), 120);

    // Human hero confident smile
    const mug = document.getElementById('hero-mugshot');
    mug.textContent = '😎';
    setTimeout(() => {
      if (window.player.health > 25) mug.textContent = '🧑‍🎤';
    }, 500);
  }

  onEnemyDefeated(enemyName) {
    this.showMessage(`💥 Derrotou ${enemyName}! (+Chuva de Chocolate & Confeitos!)`);
    const mug = document.getElementById('hero-mugshot');
    mug.textContent = '🤩';
    setTimeout(() => {
      if (window.player.health > 25) mug.textContent = '🧑‍🎤';
    }, 700);
  }

  onPlayerHurt() {
    // Soft candy screen damage flash
    const overlay = document.getElementById('damage-overlay');
    overlay.classList.add('flash');
    setTimeout(() => overlay.classList.remove('flash'), 180);

    // Human hero grimace reaction
    const mug = document.getElementById('hero-mugshot');
    mug.textContent = '😣';
    setTimeout(() => {
      if (window.player.health > 0) mug.textContent = window.player.health < 30 ? '😵' : '🧑‍🎤';
    }, 600);
  }

  // ==================== MINIMAP RADAR ====================
  drawMinimap() {
    const ctx = this.minimapCtx;
    const w = this.minimapCanvas.width;
    const h = this.minimapCanvas.height;
    const pPos = window.player.position;

    // Clear
    ctx.fillStyle = '#0f0a1c';
    ctx.fillRect(0, 0, w, h);

    // Center is player
    const cx = w / 2;
    const cy = h / 2;
    const scale = 1.4; // 1 unit in world = 1.4 pixels

    // Draw static walls / colliders nearby
    ctx.fillStyle = 'rgba(104, 34, 130, 0.6)';
    window.mapManager.colliders.forEach(c => {
      const minX = cx + (c.min.x - pPos.x) * scale;
      const minZ = cy + (c.min.z - pPos.z) * scale;
      const bw = (c.max.x - c.min.x) * scale;
      const bh = (c.max.z - c.min.z) * scale;
      ctx.fillRect(minX, minZ, bw, bh);
    });

    // Draw Destructible Walls (Yellow/Pink)
    window.mapManager.destructibleWalls.forEach(dw => {
      if (!dw.destroyed) {
        ctx.fillStyle = '#feca57';
        const px = cx + (dw.mesh.position.x - pPos.x) * scale;
        const pz = cy + (dw.mesh.position.z - pPos.z) * scale;
        ctx.fillRect(px - 3, pz - 3, 6, 6);
      }
    });

    // Draw Pickups (Cyan dots)
    ctx.fillStyle = '#00d2d3';
    window.mapManager.pickups.forEach(p => {
      const px = cx + (p.mesh.position.x - pPos.x) * scale;
      const pz = cy + (p.mesh.position.z - pPos.z) * scale;
      ctx.beginPath();
      ctx.arc(px, pz, 2.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Enemies (Hot Pink dots)
    ctx.fillStyle = '#ff6b8b';
    window.enemiesManager.enemies.forEach(e => {
      if (e.alive) {
        const ex = cx + (e.pos.x - pPos.x) * scale;
        const ez = cy + (e.pos.z - pPos.z) * scale;
        ctx.beginPath();
        ctx.arc(ex, ez, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Draw Player Arrow
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-window.player.yaw);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4, 5);
    ctx.lineTo(-4, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // ==================== VICTORY & STATISTICS INTERMISSION ====================
  triggerVictory() {
    if (this.isVictory) return;
    this.isVictory = true;
    this.isRunning = false;
    document.exitPointerLock();

    window.soundEngine.playVictoryFanfare();

    // Compute Statistics
    const minutes = Math.floor(this.elapsedTime / 60);
    const seconds = Math.floor(this.elapsedTime % 60);
    const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    const kills = window.enemiesManager.killsCount;
    const totalEnemies = window.enemiesManager.totalSpawned;
    const killsPct = totalEnemies > 0 ? Math.round((kills / totalEnemies) * 100) : 100;

    const items = window.mapManager.itemsCollected;
    const totalItems = window.mapManager.itemsTotal;
    const itemsPct = totalItems > 0 ? Math.round((items / totalItems) * 100) : 100;

    const secrets = window.mapManager.secretsFound;
    const totalSecrets = window.mapManager.secretsTotal;
    const secretsPct = Math.round((secrets / totalSecrets) * 100);

    const mapPct = window.mapManager.getExplorationPercentage();

    // Populate HUD
    document.getElementById('stat-victory-time').textContent = timeStr;
    document.getElementById('stat-victory-kills').textContent = `${kills} / ${totalEnemies} (${killsPct}%)`;
    document.getElementById('stat-victory-items').textContent = `${items} / ${totalItems} (${itemsPct}%)`;
    document.getElementById('stat-victory-secrets').textContent = `${secrets} / ${totalSecrets} (${secretsPct}%)`;
    document.getElementById('stat-victory-map').textContent = `${mapPct}%`;

    // Compute Rank
    let rank = 'B';
    const totalScore = (killsPct * 0.4) + (secretsPct * 0.3) + (itemsPct * 0.2) + (mapPct * 0.1);
    if (totalScore >= 95) rank = 'SSS';
    else if (totalScore >= 85) rank = 'SS';
    else if (totalScore >= 75) rank = 'S';
    else if (totalScore >= 60) rank = 'A';

    document.getElementById('stat-victory-rank').textContent = rank;

    // Show Intermission screen
    document.getElementById('victory-modal').classList.remove('hidden');
  }

  triggerGameOver() {
    this.isGameOver = true;
    this.isRunning = false;
    document.exitPointerLock();
    document.getElementById('gameover-modal').classList.remove('hidden');
  }
}

// Instantiate on window load
window.addEventListener('DOMContentLoaded', () => {
  window.game = new GameEngine();
});
