﻿# 🦄 DOUM — Frenetic Rainbow & Furry FPS

> Um jogo de tiro em primeira pessoa (FPS) rápido e dinâmico, inspirado na estrutura de gameplay do DOOM clássico, mas com identidade visual própria: unicórnios, personagens furry, pirulitos, donuts e explosões de chocolate sem gore!

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![Three.js](https://img.shields.io/badge/Three.js-000000?style=for-the-badge&logo=three.js&logoColor=white)
![Zero Dependencies](https://img.shields.io/badge/Zero%20Build%20Tools-%E2%9C%93-1dd1a1?style=for-the-badge)

---

## 🎮 Como Jogar

### Opção 1 — GitHub Pages
Acesse: **`https://[SEU_USUARIO].github.io/doum/`**

### Opção 2 — Servidor local

```bash
# Python 3 (qualquer OS)
python -m http.server 8080
# Abra: http://localhost:8080/
```

**Windows — use o script incluso:**
```batch
start_game.bat
```

> ⚠️ O jogo precisa de um servidor HTTP (local ou Pages). Abrir o index.html diretamente não funciona por causa do Pointer Lock e CORS.

---

## 🕹️ Controles

| Tecla | Ação |
|-------|------|
| `W A S D` | Mover |
| `Mouse` | Mirar |
| `Clique Esquerdo` | Atirar |
| `Clique Direito / V` | 1ª ↔ 3ª Pessoa |
| `Espaço` | Pular / Pulo duplo |
| `1 – 6` | Selecionar arma |
| `E` | Interagir (portas/botões) |
| `P / ESC` | Pausar |

---

## ✨ Features

- 🎯 Combate FPS frenético estilo DOOM
- 📷 Câmera 1ª/3ª pessoa instantânea  
- 🥾 **Botas de Gravidade** — item escondido atrás de paredes destrutíveis; ande no teto!
- 🧱 Paredes de cristal destrutíveis com segredos
- 🔑 3 tipos de chaves: Arco-Íris, Estelar e Rosquinha
- 🦄 4 inimigos com modelos 3D únicos (Gato Origami, Unicórnio Voxel, Urso de Mel, Pégaso)
- 🍫 Explosão de chocolate e confeitos na derrota (sem gore!)
- 🎵 Trilha Happy-Hardcore procedural via Web Audio API
- 🗺️ Minimapa / Radar Mágico sempre visível
- 📊 Tela de estatísticas estilo DOOM (Kills %, Itens %, Segredos %, Ranking)

---

## 🗂️ Estrutura

```
doum/
├── index.html          # Entrada principal + HUD
├── css/
│   └── style.css       # Estilos HUD e modais
└── js/
    ├── three.min.js    # Three.js r152 (bundled)
    ├── audio.js        # Música + SFX (Web Audio API)
    ├── particles.js    # Partículas de chocolate e confeitos
    ├── weapons.js      # 6 armas com viewmodels 3D
    ├── map.js          # 6 ambientes: pátio, salão, vault, segredo, ponte, arena
    ├── enemies.js      # IA + modelos 3D + hitbox capsule sweep
    ├── player.js       # Física, câmera, botas de gravidade
    └── game.js         # Engine: loop, HUD, minimapa, stats
```

---

## 🌍 Deploy no GitHub Pages

1. Faça push do repositório para o GitHub
2. Vá em **Settings → Pages**
3. Em **Source**, selecione `main` e pasta `/` (root)
4. Salve — em ~1 minuto o jogo estará online em:  
   `https://[SEU_USUARIO].github.io/[NOME_DO_REPO]/`

---

## 🛠️ Tecnologias

- **Three.js r152** — 3D (bundled, sem CDN externo)
- **Web Audio API** — áudio procedural
- **HTML5 Canvas** — minimapa
- **Pointer Lock API** — mouse FPS
- **Zero build tools** — sem npm, webpack ou bundler!

---

*Feito com 🦄 e muitos confeitos.*
