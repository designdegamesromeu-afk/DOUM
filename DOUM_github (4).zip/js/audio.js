// DOUM - Web Audio API Procedural Music & Sound FX Engine
// Generates energetic DOOM-inspired happy-hardcore soundtrack and punchy cartoon sound effects.

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.isMusicPlaying = false;
    this.musicInterval = null;
    this.tempo = 145; // Fast energetic BPM
    this.currentStep = 0;
    this.musicEnabled = true;
    this.initialized = false;
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);

      this.initialized = true;
      this.startMusic();
    } catch (e) {
      console.warn("AudioContext init error:", e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // ==================== PROCEDURAL SOUND FX ====================

  playLaser(freq = 880, dur = 0.12, type = 'sawtooth') {
    if (!this.initialized) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + dur);

    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + dur);
  }

  playShotgun() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    
    // Low punch
    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 0.25);
    oscGain.gain.setValueAtTime(0.8, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(oscGain);
    oscGain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.25);

    // Noise blast for candy scatter
    this.playNoise(0.2, 0.5, 800);
  }

  playChaingun() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    const pitch = 350 + Math.random() * 120;
    osc.frequency.setValueAtTime(pitch, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.08);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.08);
  }

  playRocketFire() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(600, now + 0.2);

    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  playExplosion() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    
    // Sub bass boom
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(120, now);
    sub.frequency.exponentialRampToValueAtTime(20, now + 0.5);
    subGain.gain.setValueAtTime(1.0, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    sub.connect(subGain);
    subGain.connect(this.sfxGain);
    sub.start(now);
    sub.stop(now + 0.5);

    // Pop noise
    this.playNoise(0.4, 0.7, 400);
  }

  playBFG() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    
    // Charge sweep
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(100, now);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.5);

    gain.gain.setValueAtTime(0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.6);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.6);

    // Rainbow chime chord
    setTimeout(() => {
      [523.25, 659.25, 783.99, 1046.50].forEach((f, i) => {
        this.playTone(f, 0.4, 'triangle', 0.2 + i * 0.05);
      });
      this.playExplosion();
    }, 450);
  }

  // Cartoon chocolate splat + sprinkles scatter when an enemy is defeated
  // Short "impact" blip when a hit lands on an enemy (was completely missing before —
  // every single hit call crashed here since this method never existed, which silently
  // prevented the death-check and HP bar update code right after it from ever running!)
  playEnemyHit() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.07);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.08);
  }

  playEnemyDefeat() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;

    // 1. Comic cartoon pop
    const pop = this.ctx.createOscillator();
    const popGain = this.ctx.createGain();
    pop.type = 'sine';
    pop.frequency.setValueAtTime(300, now);
    pop.frequency.exponentialRampToValueAtTime(900, now + 0.1);
    popGain.gain.setValueAtTime(0.5, now);
    popGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
    pop.connect(popGain);
    popGain.connect(this.sfxGain);
    pop.start(now);
    pop.stop(now + 0.1);

    // 2. Wet chocolate squish sound (filtered low noise + pitch drop)
    setTimeout(() => {
      const squish = this.ctx.createOscillator();
      const squishGain = this.ctx.createGain();
      squish.type = 'triangle';
      squish.frequency.setValueAtTime(220, this.ctx.currentTime);
      squish.frequency.exponentialRampToValueAtTime(45, this.ctx.currentTime + 0.2);
      squishGain.gain.setValueAtTime(0.6, this.ctx.currentTime);
      squishGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
      squish.connect(squishGain);
      squishGain.connect(this.sfxGain);
      squish.start();
      squish.stop(this.ctx.currentTime + 0.2);
    }, 60);

    // 3. High sprinkle twinkle/rattle
    for (let i = 0; i < 4; i++) {
      setTimeout(() => {
        const f = 1400 + Math.random() * 800;
        this.playTone(f, 0.08, 'square', 0.15);
      }, 50 + i * 40);
    }
  }

  // Wall cracking / candy block breaking sound
  playWallCrack() {
    if (!this.initialized) return;
    this.playNoise(0.25, 0.6, 1200);
    this.playTone(180, 0.2, 'triangle', 0.4);
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        this.playTone(400 + Math.random() * 400, 0.05, 'sawtooth', 0.2);
      }, i * 30);
    }
  }

  // Gravity boots activation whoosh
  playGravityShift(isInverted = false) {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    const startF = isInverted ? 600 : 200;
    const endF = isInverted ? 200 : 600;
    osc.frequency.setValueAtTime(startF, now);
    osc.frequency.exponentialRampToValueAtTime(endF, now + 0.35);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.35);

    // Sci-fi sub pulse
    this.playTone(90, 0.3, 'sawtooth', 0.25);
  }

  playPickup(type = 'health') {
    if (!this.initialized) return;
    if (type === 'key') {
      // Grand magical arpeggio
      [523.25, 659.25, 783.99, 1046.50].forEach((f, i) => {
        setTimeout(() => this.playTone(f, 0.18, 'triangle', 0.35), i * 70);
      });
    } else if (type === 'weapon') {
      [440, 554.37, 659.25, 880].forEach((f, i) => {
        setTimeout(() => this.playTone(f, 0.15, 'sawtooth', 0.3), i * 60);
      });
    } else {
      // Sweet candy chime
      this.playTone(660, 0.1, 'sine', 0.3);
      setTimeout(() => this.playTone(880, 0.15, 'sine', 0.35), 80);
    }
  }

  playSecretFound() {
    if (!this.initialized) return;
    const notes = [392, 523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => {
      setTimeout(() => this.playTone(f, 0.25, 'triangle', 0.4), i * 90);
    });
  }

  playVictoryFanfare() {
    if (!this.initialized) return;
    const fanfare = [
      { f: 523.25, d: 0.15, delay: 0 },
      { f: 523.25, d: 0.15, delay: 160 },
      { f: 523.25, d: 0.15, delay: 320 },
      { f: 659.25, d: 0.45, delay: 480 },
      { f: 587.33, d: 0.20, delay: 800 },
      { f: 659.25, d: 0.60, delay: 1000 }
    ];
    fanfare.forEach(n => {
      setTimeout(() => this.playTone(n.f, n.d, 'square', 0.35), n.delay);
    });
  }

  playHurt() {
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(250, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.15);
    gain.gain.setValueAtTime(0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  playTone(freq, duration = 0.1, type = 'sine', vol = 0.3) {
    if (!this.initialized) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + duration);
  }

  playNoise(duration = 0.2, vol = 0.3, cutoff = 1000) {
    if (!this.initialized) return;
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoff, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start();
  }

  // ==================== PROCEDURAL SOUNDTRACK ====================
  // Fast, punchy Happy-Hardcore / DOOM Chiptune fusion loop
  startMusic() {
    if (this.isMusicPlaying) return;
    this.isMusicPlaying = true;
    const stepDuration = (60 / this.tempo) / 4; // 16th notes
    
    // Bass chord progression in A minor: Am - F - C - G
    const chords = [
      [110, 220], // A
      [87.31, 174.61], // F
      [130.81, 261.63], // C
      [98.00, 196.00]  // G
    ];

    // Melodic arpeggio patterns
    const melodies = [
      [440, 523.25, 659.25, 880, 659.25, 523.25, 440, 523.25],
      [349.23, 440, 523.25, 698.46, 523.25, 440, 349.23, 440],
      [523.25, 659.25, 783.99, 1046.5, 783.99, 659.25, 523.25, 659.25],
      [392, 493.88, 587.33, 783.99, 587.33, 493.88, 392, 493.88]
    ];

    this.musicInterval = setInterval(() => {
      if (!this.musicEnabled || !this.initialized) return;

      const chordIdx = Math.floor(this.currentStep / 16) % 4;
      const stepInChord = this.currentStep % 16;
      const now = this.ctx.currentTime;

      // 1. Kick Drum (Beats 0, 4, 8, 12 - Four on the floor)
      if (stepInChord % 4 === 0) {
        const kick = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kick.frequency.setValueAtTime(140, now);
        kick.frequency.exponentialRampToValueAtTime(35, now + 0.12);
        kickGain.gain.setValueAtTime(0.55, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        kick.connect(kickGain);
        kickGain.connect(this.musicGain);
        kick.start(now);
        kick.stop(now + 0.12);
      }

      // 2. Snare on beats 4 and 12
      if (stepInChord === 4 || stepInChord === 12) {
        const snareNoise = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.1, this.ctx.sampleRate);
        const output = snareNoise.getChannelData(0);
        for (let i = 0; i < output.length; i++) output[i] = Math.random() * 2 - 1;
        const src = this.ctx.createBufferSource();
        src.buffer = snareNoise;
        const sFilter = this.ctx.createBiquadFilter();
        sFilter.frequency.setValueAtTime(1500, now);
        const sGain = this.ctx.createGain();
        sGain.gain.setValueAtTime(0.3, now);
        sGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        src.connect(sFilter);
        sFilter.connect(sGain);
        sGain.connect(this.musicGain);
        src.start(now);
      }

      // 3. Fast 16th-note Chugging Bass (DOOM style)
      if (stepInChord % 2 === 0 || stepInChord % 4 === 3) {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        const currentChord = chords[chordIdx];
        const bassPitch = currentChord[0];
        bassOsc.type = 'sawtooth';
        bassOsc.frequency.setValueAtTime(bassPitch, now);
        
        bassGain.gain.setValueAtTime(0.32, now);
        bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        
        bassOsc.connect(bassGain);
        bassGain.connect(this.musicGain);
        bassOsc.start(now);
        bassOsc.stop(now + 0.1);
      }

      // 4. Energetic Melody / Arpeggio
      if (stepInChord % 2 === 0) {
        const melNotes = melodies[chordIdx];
        const note = melNotes[(stepInChord / 2) % melNotes.length];
        const lead = this.ctx.createOscillator();
        const leadGain = this.ctx.createGain();
        lead.type = 'square';
        lead.frequency.setValueAtTime(note, now);
        leadGain.gain.setValueAtTime(0.12, now);
        leadGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        lead.connect(leadGain);
        leadGain.connect(this.musicGain);
        lead.start(now);
        lead.stop(now + 0.15);
      }

      this.currentStep = (this.currentStep + 1) % 64;
    }, stepDuration * 1000);
  }

  stopMusic() {
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.isMusicPlaying = false;
  }

  toggleMusic() {
    this.musicEnabled = !this.musicEnabled;
    return this.musicEnabled;
  }
}

// Global Sound instance
window.soundEngine = new SoundEngine();
