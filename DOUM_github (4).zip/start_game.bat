@echo off
title DOUM - Frenetic Rainbow & Furry FPS
echo ========================================================
echo               DOUM - ACTION FPS 3D
echo       Reino Fantastico de Unicornios e Furries
echo ========================================================
echo.
echo Iniciando servidor local e abrindo navegador...
powershell -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
if %ERRORLEVEL% NEQ 0 (
    echo Iniciando diretamente no navegador...
    start "" "%~dp0index.html"
)
pause
