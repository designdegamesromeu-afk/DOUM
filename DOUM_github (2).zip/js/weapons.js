// DOUM - Weapons Arsenal & Projectile Engine
// Features 6 colorful fantasy weapons, 1st-person viewmodels, projectile physics,
// recoil animations, and wall-piercing/demolition mechanics.

class WeaponSystem {
  constructor(scene, camera, particleSystem) {
    this.scene = scene;
    this.camera = camera;
    this.particles = particleSystem;

    this.weapons = [
      {
        id: 1,
        name: "Chifre Mágico",
        type: "melee",
        damage: 50,
        fireRate: 0.3,
        ammoCost: 0,
        unlocked: true,
        icon: "🦄"
      },
      {
        id: 2,
        name: "Pistola Estelar",
        type: "projectile",
        damage: 20,
        fireRate: 0.18,
        ammoCost: 1,
        unlocked: true,
        icon: "⭐"
      },
      {
        id: 3,
        name: "Espingarda Confeitos",
        type: "shotgun",
        damage: 4, // 10 pellets x 4 = 40 total damage se todas acertarem
        pellets: 10,
        fireRate: 0.65,
        ammoCost: 2,
        unlocked: true,
        canBreakWalls: true,
        icon: "🍧"
      },
      {
        id: 4,
        name: "Metralhadora Goma",
        type: "rapid",
        damage: 10,
        fireRate: 0.08,
        ammoCost: 1,
        unlocked: true,
        icon: "🍬"
      },
      {
        id: 5,
        name: "Lança-Cupcake",
        type: "rocket",
        damage: 450,
        radius: 5.5,
        fireRate: 0.8,
        ammoCost: 5,
        unlocked: false,
        canBreakWalls: true,
        icon: "🧁"
      },
      {
        id: 6,
        name: "RAINBOW-9999",
        type: "bfg",
        damage: 1000,
        radius: 9.0,
        fireRate: 1.4,
        ammoCost: 20,
        unlocked: false,
        canBreakWalls: true,
        icon: "🌈"
      }
    ];

    this.currentWeaponIndex = 1; // Start with Star Blaster
    this.lastFireTime = 0;
    this.projectiles = [];
    this.recoil = { x: 0, y: 0, z: 0 };

    // Viewmodel container attached to camera
    this.viewmodelHolder = new THREE.Group();
    this.camera.add(this.viewmodelHolder);
    this.viewmodels = [];

    this.initViewModels();
  }

  // ==================== PROCEDURAL 3D VIEWMODELS ====================
  initViewModels() {
    // 1. Magic Horn
    const hornGroup = new THREE.Group();
    const hornGeom = new THREE.ConeGeometry(0.12, 0.7, 8);
    const hornMat = new THREE.MeshLambertMaterial({ color: 0xfeca57, emissive: 0xff9f43, emissiveIntensity: 0.4 });
    const hornMesh = new THREE.Mesh(hornGeom, hornMat);
    hornMesh.rotation.x = Math.PI / 3;
    hornMesh.position.set(0.3, -0.3, -0.6);
    hornGroup.add(hornMesh);
    this.viewmodels.push(hornGroup);

    // 2. Star Blaster
    const pistolGroup = new THREE.Group();
    const pBodyGeom = new THREE.BoxGeometry(0.14, 0.22, 0.45);
    const pBodyMat = new THREE.MeshLambertMaterial({ color: 0xff6b8b });
    const pBody = new THREE.Mesh(pBodyGeom, pBodyMat);
    const pBarrelGeom = new THREE.CylinderGeometry(0.06, 0.06, 0.35, 8);
    const pBarrelMat = new THREE.MeshLambertMaterial({ color: 0x48dbfb });
    const pBarrel = new THREE.Mesh(pBarrelGeom, pBarrelMat);
    pBarrel.rotation.x = Math.PI / 2;
    pBarrel.position.set(0, 0.05, -0.3);
    pistolGroup.add(pBody, pBarrel);
    pistolGroup.position.set(0.32, -0.28, -0.55);
    this.viewmodels.push(pistolGroup);

    // 3. Sprinkle Super-Shotgun (SSG)
    const ssgGroup = new THREE.Group();
    const ssgBody = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.5), new THREE.MeshLambertMaterial({ color: 0x9b59b6 }));
    const b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.5, 8), new THREE.MeshLambertMaterial({ color: 0xfeca57 }));
    const b2 = b1.clone();
    b1.rotation.x = Math.PI / 2;
    b2.rotation.x = Math.PI / 2;
    b1.position.set(-0.06, 0.04, -0.35);
    b2.position.set(0.06, 0.04, -0.35);
    ssgGroup.add(ssgBody, b1, b2);
    ssgGroup.position.set(0.35, -0.3, -0.6);
    this.viewmodels.push(ssgGroup);

    // 4. Bubble Chaingun
    const chainGroup = new THREE.Group();
    const cBody = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.45, 12), new THREE.MeshLambertMaterial({ color: 0x00d2d3 }));
    cBody.rotation.x = Math.PI / 2;
    const rotor = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.55, 6), new THREE.MeshLambertMaterial({ color: 0xff9ff3 }));
    rotor.rotation.x = Math.PI / 2;
    rotor.position.z = -0.3;
    chainGroup.add(cBody, rotor);
    chainGroup.position.set(0.35, -0.32, -0.6);
    this.viewmodels.push(chainGroup);

    // 5. Cupcake Rocket Launcher
    const rocketGroup = new THREE.Group();
    const rTube = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.8, 12), new THREE.MeshLambertMaterial({ color: 0xff9f43 }));
    rTube.rotation.x = Math.PI / 2;
    const rRing = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.04, 8, 16), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    rRing.position.z = -0.25;
    rocketGroup.add(rTube, rRing);
    rocketGroup.position.set(0.38, -0.26, -0.65);
    this.viewmodels.push(rocketGroup);

    // 6. RAINBOW-9999
    const bfgGroup = new THREE.Group();
    const bfgBody = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.35, 0.7), new THREE.MeshLambertMaterial({ color: 0x222f3e }));
    const bfgCore = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 12), new THREE.MeshBasicMaterial({ color: 0xff9ff3 }));
    bfgCore.position.z = -0.15;
    const bfgRing = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 8, 16), new THREE.MeshBasicMaterial({ color: 0x48dbfb }));
    bfgRing.position.z = -0.38;
    bfgGroup.add(bfgBody, bfgCore, bfgRing);
    bfgGroup.position.set(0.36, -0.3, -0.7);
    this.viewmodels.push(bfgGroup);

    // Add all to holder and show current
    this.viewmodels.forEach(vm => this.viewmodelHolder.add(vm));
    this.updateViewModelVisibility();
    this.updateHUDWeaponRibbon();
  }

  updateViewModelVisibility(isFirstPerson = true) {
    this.viewmodelHolder.visible = isFirstPerson;
    this.viewmodels.forEach((vm, index) => {
      vm.visible = isFirstPerson && (index === this.currentWeaponIndex);
    });
  }

  getCurrentWeapon() {
    return this.weapons[this.currentWeaponIndex];
  }

  selectWeapon(index) {
    if (index >= 0 && index < this.weapons.length && this.weapons[index].unlocked) {
      this.currentWeaponIndex = index;
      this.updateViewModelVisibility(this.viewmodelHolder.visible);
      window.soundEngine.playTone(550 + index * 80, 0.08, 'sine', 0.2);
      this.updateHUDWeaponRibbon();
      return true;
    }
    return false;
  }

  unlockWeapon(index) {
    if (index >= 0 && index < this.weapons.length) {
      this.weapons[index].unlocked = true;
      this.selectWeapon(index);
      this.updateHUDWeaponRibbon();
    }
  }

  updateHUDWeaponRibbon() {
    const slots = document.querySelectorAll('.weapon-slot');
    slots.forEach((slot, idx) => {
      if (this.weapons[idx].unlocked) {
        slot.classList.add('unlocked');
      } else {
        slot.classList.remove('unlocked');
      }
      if (idx === this.currentWeaponIndex) {
        slot.classList.add('active');
      } else {
        slot.classList.remove('active');
      }
    });
  }

  // ==================== FIRING MECHANICS ====================
  fire(player, enemiesManager, mapManager) {
    const weapon = this.getCurrentWeapon();
    const now = performance.now() / 1000;

    if (now - this.lastFireTime < weapon.fireRate) return false;
    if (player.ammo < weapon.ammoCost) {
      window.soundEngine.playTone(150, 0.1, 'sawtooth', 0.2); // Click empty sound
      return false;
    }

    // Deduct ammo
    player.ammo -= weapon.ammoCost;
    this.lastFireTime = now;

    // Viewmodel recoil kick
    this.recoil.z = 0.15;
    this.recoil.y = 0.05;

    // Get shooting ray in camera aim direction
    const origin = new THREE.Vector3();
    this.camera.getWorldPosition(origin);
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);

    switch (weapon.type) {
      case 'melee':
        this.fireMelee(origin, dir, weapon, enemiesManager, mapManager);
        break;
      case 'projectile':
        this.fireBlaster(origin, dir, weapon);
        break;
      case 'shotgun':
        this.fireShotgun(origin, dir, weapon, mapManager);
        break;
      case 'rapid':
        this.fireChaingun(origin, dir, weapon);
        break;
      case 'rocket':
        this.fireRocket(origin, dir, weapon);
        break;
      case 'bfg':
        this.fireBFG(origin, dir, weapon);
        break;
    }

    return true;
  }

  // 1. Magic Horn Melee
  fireMelee(origin, dir, weapon, enemiesManager, mapManager) {
    window.soundEngine.playTone(700, 0.15, 'triangle', 0.4);
    this.particles.spawnConfettiBurst(origin.clone().addScaledVector(dir, 1.5), 8);

    // Hit check in cone
    enemiesManager.checkMeleeHit(origin, dir, 3.2, weapon.damage);

    // Check destructible wall in melee range
    mapManager.checkWallHit(origin, dir, 3.0, 50);
  }

  // 2. Star Blaster
  fireBlaster(origin, dir, weapon) {
    window.soundEngine.playLaser(750, 0.12, 'sawtooth');

    const geom = new THREE.SphereGeometry(0.12, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color: 0xfeca57 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(origin).addScaledVector(dir, 0.8);
    this.scene.add(mesh);

    this.projectiles.push({
      mesh: mesh,
      dir: dir.clone(),
      speed: 48.0,
      damage: weapon.damage,
      life: 2.0,
      type: 'blaster',
      canBreakWalls: false
    });
  }

  // 3. Sprinkle Super-Shotgun (SSG)
  fireShotgun(origin, dir, weapon, mapManager) {
    window.soundEngine.playShotgun();

    // Spawn 10 spread pellets
    for (let i = 0; i < weapon.pellets; i++) {
      const spreadDir = dir.clone().add(new THREE.Vector3(
        (Math.random() - 0.5) * 0.16,
        (Math.random() - 0.5) * 0.16,
        (Math.random() - 0.5) * 0.16
      )).normalize();

      const geom = new THREE.CylinderGeometry(0.03, 0.03, 0.18, 5);
      const col = this.particles.sprinkleColors[i % this.particles.sprinkleColors.length];
      const mat = new THREE.MeshBasicMaterial({ color: col });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.copy(origin).addScaledVector(spreadDir, 0.6);
      this.scene.add(mesh);

      this.projectiles.push({
        mesh: mesh,
        dir: spreadDir,
        speed: 55.0,
        damage: weapon.damage,
        life: 0.8,
        type: 'sprinkle',
        canBreakWalls: true // SSG shatters fragile candy walls!
      });
    }

    // Heavy direct wall demolition check in close range
    mapManager.checkWallHit(origin, dir, 4.0, 100);
  }

  // 4. Bubble Chaingun
  fireChaingun(origin, dir, weapon) {
    window.soundEngine.playChaingun();

    const spreadDir = dir.clone().add(new THREE.Vector3(
      (Math.random() - 0.5) * 0.05,
      (Math.random() - 0.5) * 0.05,
      (Math.random() - 0.5) * 0.05
    )).normalize();

    const geom = new THREE.SphereGeometry(0.14, 8, 8);
    const isPink = Math.random() > 0.5;
    const mat = new THREE.MeshLambertMaterial({
      color: isPink ? 0xff6b8b : 0x00d2d3,
      emissive: isPink ? 0x9b59b6 : 0x00d2d3,
      emissiveIntensity: 0.5
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.copy(origin).addScaledVector(spreadDir, 0.7);
    this.scene.add(mesh);

    this.projectiles.push({
      mesh: mesh,
      dir: spreadDir,
      speed: 60.0,
      damage: weapon.damage,
      life: 1.5,
      type: 'bubble',
      canBreakWalls: false
    });
  }

  // 5. Cupcake Rocket Launcher
  fireRocket(origin, dir, weapon) {
    window.soundEngine.playRocketFire();

    // 3D Cupcake Projectile
    const cupcakeGroup = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.14, 0.25, 8), new THREE.MeshLambertMaterial({ color: 0x5c2c16 }));
    const frosting = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshLambertMaterial({ color: 0xff6b8b }));
    frosting.position.y = 0.15;
    cupcakeGroup.add(base, frosting);
    cupcakeGroup.position.copy(origin).addScaledVector(dir, 1.0);
    this.scene.add(cupcakeGroup);

    this.projectiles.push({
      mesh: cupcakeGroup,
      dir: dir.clone(),
      speed: 32.0,
      damage: weapon.damage,
      radius: weapon.radius,
      life: 4.0,
      type: 'rocket',
      canBreakWalls: true
    });
  }

  // 6. RAINBOW-9999 (BFG)
  fireBFG(origin, dir, weapon) {
    window.soundEngine.playBFG();

    const orbGeom = new THREE.SphereGeometry(0.65, 16, 16);
    const orbMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const orb = new THREE.Mesh(orbGeom, orbMat);
    orb.position.copy(origin).addScaledVector(dir, 1.2);
    this.scene.add(orb);

    this.projectiles.push({
      mesh: orb,
      dir: dir.clone(),
      speed: 18.0,
      damage: weapon.damage,
      radius: weapon.radius,
      life: 6.0,
      type: 'bfg',
      canBreakWalls: true,
      lastZapTime: 0
    });
  }

  // ==================== PROJECTILE UPDATES & COLLISION ====================
  update(delta, player, enemiesManager, mapManager) {
    // Viewmodel idle bobbing & recoil recovery
    if (this.viewmodelHolder.visible) {
      this.recoil.z = THREE.MathUtils.lerp(this.recoil.z, 0, delta * 12);
      this.recoil.y = THREE.MathUtils.lerp(this.recoil.y, 0, delta * 12);
      
      const speed = player.velocity ? player.velocity.length() : 0;
      const t = performance.now() * 0.005;
      const bobX = Math.sin(t * 8) * (speed > 0.5 ? 0.02 : 0.004);
      const bobY = Math.cos(t * 16) * (speed > 0.5 ? 0.02 : 0.004);

      this.viewmodelHolder.position.set(bobX, bobY - this.recoil.y, this.recoil.z);
    }

    // Update projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= delta;

      if (p.life <= 0) {
        this.destroyProjectile(i);
        continue;
      }

      // Move projectile forward
      const prevPos = p.mesh.position.clone();
      p.mesh.position.addScaledVector(p.dir, p.speed * delta);

      // Visual spin for rockets and bubbles
      if (p.type === 'rocket' || p.type === 'sprinkle') {
        p.mesh.rotation.x += 10.0 * delta;
        p.mesh.rotation.y += 8.0 * delta;
      }

      // BFG zap tendrils to all visible enemies along path
      if (p.type === 'bfg') {
        const nowSec = performance.now() / 1000;
        if (nowSec - p.lastZapTime > 0.15) {
          p.lastZapTime = nowSec;
          enemiesManager.zapNearbyEnemies(p.mesh.position, 12.0, 45);
          this.particles.spawnConfettiBurst(p.mesh.position, 6);
        }
      }

      // 1. Collision check against Enemies
      const hitEnemy = enemiesManager.checkProjectileHit(prevPos, p.mesh.position, p.damage);
      if (hitEnemy) {
        this.handleProjectileImpact(p, p.mesh.position, enemiesManager, mapManager);
        this.destroyProjectile(i);
        continue;
      }

      // 2. Collision check against Destructible Walls & Map Colliders
      const wallHit = mapManager.checkProjectileCollision(prevPos, p.mesh.position, p.damage, p.canBreakWalls);
      if (wallHit.hit) {
        this.handleProjectileImpact(p, wallHit.point, enemiesManager, mapManager, wallHit.normal);
        this.destroyProjectile(i);
        continue;
      }
    }
  }

  handleProjectileImpact(projectile, hitPoint, enemiesManager, mapManager, normal = new THREE.Vector3(0, 1, 0)) {
    if (projectile.type === 'blaster') {
      this.particles.spawnHitSparks(hitPoint, normal, 0xfeca57);
      window.soundEngine.playTone(350, 0.05, 'triangle', 0.2);
    } else if (projectile.type === 'sprinkle') {
      this.particles.spawnHitSparks(hitPoint, normal, 0xff6b8b);
    } else if (projectile.type === 'bubble') {
      this.particles.spawnHitSparks(hitPoint, normal, 0x00d2d3);
      window.soundEngine.playTone(200, 0.08, 'sine', 0.25);
    } else if (projectile.type === 'rocket') {
      window.soundEngine.playExplosion();
      this.particles.spawnExplosion(hitPoint, projectile.radius);
      enemiesManager.dealSplashDamage(hitPoint, projectile.radius, projectile.damage);
      mapManager.breakNearbyWalls(hitPoint, projectile.radius);
    } else if (projectile.type === 'bfg') {
      window.soundEngine.playExplosion();
      this.particles.spawnExplosion(hitPoint, projectile.radius);
      this.particles.spawnEnemyDefeat(hitPoint); // Massive chocolate & sprinkle cataclysm
      enemiesManager.dealSplashDamage(hitPoint, projectile.radius, projectile.damage);
      mapManager.breakNearbyWalls(hitPoint, projectile.radius * 1.2);
    }
  }

  destroyProjectile(index) {
    const p = this.projectiles[index];
    this.scene.remove(p.mesh);
    if (p.mesh.geometry) p.mesh.geometry.dispose();
    if (p.mesh.material) p.mesh.material.dispose();
    this.projectiles.splice(index, 1);
  }

  clearAll() {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      this.destroyProjectile(i);
    }
  }
}
